/**
 * ALME Engine (Adaptive Learning Mission Engine)
 * Menganalisis hasil asesmen diagnostik, keterampilan saintifik, numerasi, literasi, dan data sensor
 * untuk menghasilkan rekomendasi misi adaptif dan sisipan pembelajaran berupa:
 * 1. Remedial (Penguatan Konsep Dasar & Bimbingan Terstruktur)
 * 2. Pengayaan (HOTS, Analisis Mendalam & Tantangan STEM Lanjut)
 * 3. Soal Literasi (Pemahaman Wacana Ilmiah & Interpretasi Kasus)
 * 4. Soal Numerasi (Kalkulasi Matematis, Grafik Bivariat & Analisis Data)
 * 5. Latihan Soal (Drill Mandiri & Evaluasi Pemahaman)
 */

import {
  AlmeRecommendation,
  PortfolioEvidence,
  AlmeInterventionType,
  AlmeInterventionContent,
} from '../../types';

export interface AlmeAnalysisInput {
  assessmentResult?: number;
  assessmentResultScore?: number;
  literacy?: number;
  literacyScore?: number;
  numeracy?: number;
  numeracyScore?: number;
  reasoning?: number;
  reasoningScore?: number;
  quizScore?: number;
  experimentResult?: number;
  experimentResultScore?: number;
  practiceScore?: number;
  missionProgress?: number;
  portfolioEvidence?: PortfolioEvidence;
  hintLevelReached?: number;
  currentDifficulty?: number;
}

export class AlmeEngine {
  /**
   * Mengambil paket konten sisipan pembelajaran ALME berdasarkan tipe intervensi, mata pelajaran, dan tujuan pembelajaran
   */
  public static getInterventionContent(
    type: AlmeInterventionType,
    subjectName = 'Fisika',
    tp?: { id?: string; code?: string; title?: string; description?: string } | null
  ): AlmeInterventionContent {
    const sName = subjectName || 'Fisika';
    const cleanSubject = sName.toLowerCase();
    const tpTitle = tp?.title ? tp.title.trim() : `Penguasaan Konsep Esensial ${sName}`;
    const tpCodeStr = tp?.code ? `[${tp.code}] ` : '';

    const isMath = cleanSubject.includes('matematika') || cleanSubject.includes('kalkulus') || cleanSubject.includes('aljabar');
    const isKimia = cleanSubject.includes('kimia');
    const isBiologi = cleanSubject.includes('biologi');

    // 1. KONTEN MATA PELAJARAN MATEMATIKA / MATEMATIKA TINGKAT LANJUT
    if (isMath) {
      switch (type) {
        case 'remedial':
          return {
            type: 'remedial',
            title: 'MISI PENGUATAN ALME',
            summary: `Bimbingan terstruktur langkah demi langkah untuk menguatkan pemahaman konsep dasar aljabar, persamaan fungsi, dan pemecahan masalah sistematis sesuai Tujuan Pembelajaran: "${tpTitle}".`,
            instructions: `Pelajari rangkuman prinsip dasar matematika berikut, kemudian jawab pertanyaan pemahaman bertahap untuk memulihkan fondasi konsep sebelum melanjutkan ke misi utama.`,
            questions: [
              {
                question: 'Sebuah fungsi kuadrat didefinisikan sebagai f(x) = x² - 6x + 8. Berapakah koordinat titik puncak (ekstrem) dari kurva parabola tersebut?',
                options: ['(3, -1)', '(3, 1)', '(-3, -1)', '(6, 8)'],
                correctAnswer: '(3, -1)',
                explanation: 'Gunakan rumus absis titik puncak x_p = -b / (2a) = -(-6) / (2 × 1) = 3. Kemudian substitusikan ke f(x): f(3) = (3)² - 6(3) + 8 = 9 - 18 + 8 = -1. Jadi titik puncaknya adalah (3, -1).',
              },
              {
                question: 'Manakah pernyataan yang paling tepat mengenai pengertian gradien (kemiringan garis m) pada persamaan linear y = mx + c?',
                options: [
                  'Gradien menyatakan titik potong garis terhadap sumbu Y',
                  'Gradien adalah rasio perubahan nilai ordinat (Δy) terhadap perubahan absis (Δx)',
                  'Gradien selalu bernilai positif pada setiap kuadran kartesius',
                  'Gradien menyatakan luas daerah di bawah kurva linear',
                ],
                correctAnswer: 'Gradien adalah rasio perubahan nilai ordinat (Δy) terhadap perubahan absis (Δx)',
                explanation: 'Secara matematis, gradien m = Δy / Δx mengukur laju perubahan vertikal terhadap horizontal dari suatu garis lurus.',
              },
            ],
          };

        case 'pengayaan':
          return {
            type: 'pengayaan',
            title: 'MISI PENGUATAN ALME',
            summary: `Tantangan eksplorasi mendalam tingkat lanjut mengintegrasikan optimasi matematis dan pemodelan analitik untuk Tujuan Pembelajaran: "${tpTitle}".`,
            instructions: `Analisis skenario pemodelan optimasi matematika tingkat lanjut di bawah ini dan pilihlah solusi berbasis penalaran deduktif yang presisi.`,
            questions: [
              {
                question: 'Sebuah wadah tanpa tutup dirancang dari selembar karton persegi berukuran 24 cm × 24 cm dengan memotong bujur sangkar bersisi x cm pada setiap sudutnya dan melipat sisi-sisinya ke atas. Berapakah nilai x agar volume wadah tersebut maksimum?',
                options: ['4 cm', '6 cm', '8 cm', '3 cm'],
                correctAnswer: '4 cm',
                explanation: 'Volume V(x) = (24 - 2x)² · x = (576 - 96x + 4x²)x = 4x³ - 96x² + 576x. Turunan pertama V\'(x) = 12x² - 192x + 576 = 0. Dibagi 12: x² - 16x + 48 = 0 → (x - 4)(x - 12) = 0. Karena batas fisik 0 < x < 12, maka nilai optimal adalah x = 4 cm.',
              },
              {
                question: 'Model pertumbuhan eksponensial suatu populasi dinyatakan dengan P(t) = 500 · e^(0.04t), di mana t dalam satuan jam. Berapakah perkiraan waktu (doubling time) yang dibutuhkan hingga populasi menjadi dua kali lipat (1.000 individu)?',
                options: ['≈ 17.3 jam', '≈ 25.0 jam', '≈ 12.5 jam', '≈ 50.0 jam'],
                correctAnswer: '≈ 17.3 jam',
                explanation: '2 = e^(0.04t) → ln(2) = 0.04t → t = ln(2) / 0.04 ≈ 0.6931 / 0.04 ≈ 17.33 jam.',
              },
            ],
          };

        case 'soal_literasi':
          return {
            type: 'soal_literasi',
            title: 'MISI PENGUATAN ALME',
            summary: `Penguatan kompetensi literasi numerik membaca teks kontekstual, menafsirkan grafik tren data, dan memvalidasi hipotesis matematika pada Tujuan Pembelajaran: "${tpTitle}".`,
            instructions: `Bacalah wacana pemodelan matematika kontekstual berikut dengan cermat, lalu jawab pertanyaan analisis berbasis penalaran kritis.`,
            questions: [
              {
                question: 'Teks Wacana: "Sebuah koperasi simpan pinjam desa menawarkan produk tabungan berjangka dengan bunga majemuk tahunan 6% yang dihitung bulanan. Di sisi lain, seorang wirausahawan muda membandingkan skema pinjaman modal usaha flat 8% per tahun. Berdasarkan studi literasi keuangan, skema bunga majemuk memiliki efek eksponensial terhadap akumulasi saldo tabungan jangka panjang."\n\nBerdasarkan wacana di atas, mengapa tabungan dengan skema bunga majemuk menghasilkan nilai akhir yang jauh lebih besar dalam rentang 10 tahun dibandingkan skema bunga tunggal dengan tingkat suku bunga yang sama?',
                options: [
                  'Karena pada bunga majemuk, pokok tabungan didepresiasi setiap akhir bulan',
                  'Karena bunga yang diperoleh pada setiap periode diakumulasikan kembali ke dalam modal pokok sehingga turut menghasilkan bunga di periode berikutnya',
                  'Karena suku bunga majemuk dijamin bebas risiko inflasi oleh bank sentral',
                  'Karena waktu simpanan dipotong setengahnya pada skema bunga majemuk',
                ],
                correctAnswer: 'Karena bunga yang diperoleh pada setiap periode diakumulasikan kembali ke dalam modal pokok sehingga turut menghasilkan bunga di periode berikutnya',
                explanation: 'Prinsip bunga majemuk A = P(1 + r/n)^(nt) menghitung bunga atas modal pokok ditambah akumulasi bunga sebelumnya, menghasilkan kurva pertumbuhan eksponensial.',
              },
              {
                question: 'Dari wacana pemodelan keuangan di atas, jika dirumuskan dalam fungsi matematika f(t) = P · (1 + r/n)^(n·t), maka variabel bebas (independen) dari fungsi tersebut adalah:',
                options: [
                  'Waktu penabungan (t)',
                  'Saldo akhir tabungan (f(t))',
                  'Modal awal (P)',
                  'Jumlah periode per tahun (n)',
                ],
                correctAnswer: 'Waktu penabungan (t)',
                explanation: 'Variabel bebas yang dapat berubah secara mandiri pada fungsi f(t) adalah waktu (t), sedangkan saldo akhir f(t) adalah variabel terikat.',
              },
            ],
          };

        case 'soal_numerasi':
          return {
            type: 'soal_numerasi',
            title: 'MISI PENGUATAN ALME',
            summary: `Penguatan kompetensi numerasi dalam menyelesaikan kalkulasi matematis, analisis persamaan garis lurus, dan statistika inferensial pada Tujuan Pembelajaran: "${tpTitle}".`,
            instructions: `Gunakan rumus dan perhitungan matematika yang sistematis untuk menjawab pertanyaan kuantitatif di bawah ini.`,
            questions: [
              {
                question: 'Dari survei waktu belajar harian (x jam) terhadap nilai ujian matematika (y poin), diperoleh persamaan garis tren regresi linear: y = 7.5x + 35. Jika seorang siswa menargetkan nilai minimal 80 poin, berapa jam belajar minimal per hari yang direkomendasikan?',
                options: ['6.0 jam', '5.0 jam', '4.5 jam', '7.0 jam'],
                correctAnswer: '6.0 jam',
                explanation: 'Substitusikan y = 80: 80 = 7.5x + 35 → 7.5x = 45 → x = 45 / 7.5 = 6 jam per hari.',
              },
              {
                question: 'Diberikan kumpulan data nilai ulangan matematika: 70, 75, 80, 85, 90. Berapakah nilai rata-rata (mean) dan simpangan rata-ratanya?',
                options: [
                  'Mean = 80, Simpangan Rata-rata = 6.0',
                  'Mean = 80, Simpangan Rata-rata = 8.0',
                  'Mean = 82, Simpangan Rata-rata = 5.5',
                  'Mean = 78, Simpangan Rata-rata = 6.0',
                ],
                correctAnswer: 'Mean = 80, Simpangan Rata-rata = 6.0',
                explanation: 'Mean = (70+75+80+85+90)/5 = 400/5 = 80. Deviasi mutlak: |70-80|=10, |75-80|=5, |80-80|=0, |85-80|=5, |90-80|=10. Simpangan rata-rata = (10+5+0+5+10)/5 = 30/5 = 6.0.',
              },
            ],
          };

        case 'latihan_soal':
        default:
          return {
            type: 'latihan_soal',
            title: 'MISI PENGUATAN ALME',
            summary: `Drill soal mandiri formatif terintegrasi untuk menguji kesiapan konsep, penalaran matematis, dan akurasi komputasi pada Tujuan Pembelajaran: "${tpTitle}".`,
            instructions: `Selesaikan soal latihan berikut secara mandiri dengan langkah yang runut dan teliti.`,
            questions: [
              {
                question: 'Diketahui suatu barisan aritmatika memiliki suku ke-4 bernilai 17 dan suku ke-9 bernilai 37. Berapakah suku pertama (a) dan beda (b) dari barisan tersebut?',
                options: ['a = 5 dan b = 4', 'a = 4 dan b = 5', 'a = 3 dan b = 4', 'a = 7 dan b = 3'],
                correctAnswer: 'a = 5 dan b = 4',
                explanation: 'U9 - U4 = (a + 8b) - (a + 3b) = 5b = 37 - 17 = 20 → b = 4. Suku ke-4: a + 3(4) = 17 → a + 12 = 17 → a = 5.',
              },
              {
                question: 'Himpunan penyelesaian dari pertidaksamaan linear 3x - 5 ≤ 7x + 11 untuk x bilangan bulat adalah:',
                options: ['x ≥ -4', 'x ≤ -4', 'x ≥ 4', 'x ≤ 4'],
                correctAnswer: 'x ≥ -4',
                explanation: '3x - 7x ≤ 11 + 5 → -4x ≤ 16. Membagi dengan bilangan negatif -4 membalik tanda ketidaksamaan: x ≥ -4.',
              },
            ],
          };
      }
    }

    // 2. KONTEN MATA PELAJARAN KIMIA
    if (isKimia) {
      switch (type) {
        case 'remedial':
          return {
            type: 'remedial',
            title: 'MISI PENGUATAN ALME',
            summary: `Bimbingan terstruktur konsep dasar stoikiometri, struktur atom, hukum dasar kimia, dan persamaan reaksi sesuai Tujuan Pembelajaran: "${tpTitle}".`,
            instructions: `Pahami prinsip dasar kimia berikut dan jawab pertanyaan bimbingan bertahap untuk memulihkan pemahaman konsep materi.`,
            questions: [
              {
                question: 'Berapakah jumlah mol dari 8.8 gram gas karbon dioksida (CO₂) jika diketahui massa atom relatif Ar C = 12 dan Ar O = 16?',
                options: ['0.20 mol', '0.44 mol', '0.10 mol', '2.00 mol'],
                correctAnswer: '0.20 mol',
                explanation: 'Massa molar Mr CO₂ = 12 + (2 × 16) = 44 g/mol. Jumlah mol n = massa / Mr = 8.8 / 44 = 0.20 mol.',
              },
              {
                question: 'Manakah pernyataan yang tepat mengenai Hukum Kekekalan Massa (Hukum Lavoisier)?',
                options: [
                  'Dalam sistem tertutup, massa zat sebelum dan sesudah reaksi selalu sama',
                  'Massa pereaksi selalu berkurang seiring terbentuknya gas',
                  'Volume gas hasil reaksi selalu dua kali volume pereaksi',
                  'Massa zat bergantung pada perubahan suhu lingkungan',
                ],
                correctAnswer: 'Dalam sistem tertutup, massa zat sebelum dan sesudah reaksi selalu sama',
                explanation: 'Hukum Lavoisier menyatakan bahwa dalam sistem tertutup, massa total zat sebelum reaksi sama dengan massa total zat hasil reaksi (massa kekal).',
              },
            ],
          };

        case 'pengayaan':
          return {
            type: 'pengayaan',
            title: 'MISI PENGUATAN ALME',
            summary: `Tantangan analisis termokimia lanjutan, kinetika reaksi, dan kesetimbangan dinamis kimia untuk Tujuan Pembelajaran: "${tpTitle}".`,
            instructions: `Analisis fenomena reaksi kimia dan pergeseran kesetimbangan berbasis asas Le Chatelier secara mendalam.`,
            questions: [
              {
                question: 'Pada reaksi kesetimbangan eksoterm pembuatan amonia: N₂(g) + 3H₂(g) ⇌ 2NH₃(g) (ΔH = -92 kJ). Perlakuan manakah yang paling tepat untuk menggeser kesetimbangan ke arah pembentukan produk NH₃ secara optimal?',
                options: [
                  'Menaikkan tekanan sistem dan menurunkan suhu reaksi dengan bantuan katalis',
                  'Menurunkan tekanan sistem dan menaikkan suhu reaksi',
                  'Memperbesar volume wadah dan mengurangi konsentrasi gas nitrogen',
                  'Menghilangkan katalis besi dan menaikkan suhu hingga di atas 1000°C',
                ],
                correctAnswer: 'Menaikkan tekanan sistem dan menurunkan suhu reaksi dengan bantuan katalis',
                explanation: 'Menaikkan tekanan menggeser kesetimbangan ke sisi koefisien gas lebih kecil (2 vs 4). Menurunkan suhu menggeser ke arah reaksi eksoterm (produk NH₃). Katalis membantu mempercepat tercapainya kesetimbangan pada suhu rendah.',
              },
              {
                question: 'Berapakah perkiraan perubahan entalpi pembakaran 1 mol gas metana CH₄(g) jika diketahui energi ikatan rata-rata: C-H = 413 kJ/mol, O=O = 495 kJ/mol, C=O = 799 kJ/mol, dan O-H = 463 kJ/mol?',
                options: ['-808 kJ/mol', '+808 kJ/mol', '-640 kJ/mol', '-1200 kJ/mol'],
                correctAnswer: '-808 kJ/mol',
                explanation: 'Reaksi: CH₄ + 2O₂ → CO₂ + 2H₂O. Pemutusan: 4(C-H) + 2(O=O) = 4(413) + 2(495) = 1652 + 990 = 2642 kJ. Pembentukan: 2(C=O) + 4(O-H) = 2(799) + 4(463) = 1598 + 1852 = 3450 kJ. ΔH = 2642 - 3450 = -808 kJ/mol (eksoterm).',
              },
            ],
          };

        case 'soal_literasi':
          return {
            type: 'soal_literasi',
            title: 'MISI PENGUATAN ALME',
            summary: `Penguatan literasi wacana kimia hijau (Green Chemistry), sintesis material ramah lingkungan, dan analisis dampak sains pada Tujuan Pembelajaran: "${tpTitle}".`,
            instructions: `Bacalah wacana saintifik kimia berikut, lalu analisis kesimpulan empiris berdasarkan prinsip kimia hijau.`,
            questions: [
              {
                question: 'Teks Wacana: "Prinsip Kimia Hijau menekankan pada ekonomi atom dan pencegahan timbulnya limbah beracun. Sintesis asam adipat secara konvensional menghasilkan produk samping berupa gas dinitrogen oksida (N₂O) yang merupakan gas rumah kaca pemicu penipisan ozon. Inovasi baru menggunakan katalis asam tungstat dan hidrogen peroksida 30% mampu mengubah sikloheksena menjadi asam adipat dengan produk samping hanya air (H₂O)."\n\nBerdasarkan wacana di atas, apa keunggulan utama dari metode katalitik baru tersebut ditinjau dari aspek lingkungan?',
                options: [
                  'Menghasilkan produk samping ramah lingkungan berupa air dan menghindari emisi gas dinitrogen oksida yang merusak ozon',
                  'Mengurangi biaya produksi hingga 100% tanpa menggunakan pelarut apa pun',
                  'Mempercepat reaksi tanpa memerlukan bahan baku sikloheksena',
                  'Menghasilkan asam adipat dengan kadar kemurnian rendah',
                ],
                correctAnswer: 'Menghasilkan produk samping ramah lingkungan berupa air dan menghindari emisi gas dinitrogen oksida yang merusak ozon',
                explanation: 'Metode baru memenuhi prinsip ekonomi atom dan pencegahan limbah berbahaya dengan mengganti emisi N₂O beracun menjadi H₂O murni.',
              },
              {
                question: 'Dari wacana di atas, fungsi hidrogen peroksida (H₂O₂) dalam reaksi sintesis tersebut adalah sebagai agen:',
                options: ['Oksidator', 'Reduktor', 'Katalisator homogen', 'Inhibitor reaksi'],
                correctAnswer: 'Oksidator',
                explanation: 'H₂O₂ bertindak sebagai zat pengoksidasi (oksidator) yang mengoksidasi ikatan rangkap sikloheksena menjadi gugus asam karboksilat.',
              },
            ],
          };

        case 'soal_numerasi':
          return {
            type: 'soal_numerasi',
            title: 'MISI PENGUATAN ALME',
            summary: `Penguatan kalkulasi stoikiometri molaritas larutan, pH asam-basa, dan perhitungan volume gas pada Tujuan Pembelajaran: "${tpTitle}".`,
            instructions: `Gunakan rumus perbandingan mol dan stoikiometri untuk menyelesaikan perhitungan numerik kimia berikut.`,
            questions: [
              {
                question: 'Sebanyak 5.4 gram serbuk logam aluminium (Ar Al = 27) direaksikan dengan larutan asam klorida encer berlebih sesuai persamaan: 2Al(s) + 6HCl(aq) → 2AlCl₃(aq) + 3H₂(g). Berapakah volume gas hidrogen (H₂) yang dihasilkan pada keadaan standar (STP)?',
                options: ['6.72 Liter', '4.48 Liter', '2.24 Liter', '11.20 Liter'],
                correctAnswer: '6.72 Liter',
                explanation: 'Mol Al = 5.4 / 27 = 0.2 mol. Berdasarkan koefisien reaksi, mol H₂ = (3/2) × mol Al = 1.5 × 0.2 = 0.3 mol. Pada kondisi STP: Volume = 0.3 × 22.4 = 6.72 Liter.',
              },
              {
                question: 'Berapakah nilai pH dari larutan asam sulfat (H₂SO₄) dengan konsentrasi 0.005 M jika diasumsikan terionisasi sempurna?',
                options: ['2', '1', '3', '2.3'],
                correctAnswer: '2',
                explanation: 'H₂SO₄ adalah asam diprotik kuat: [H⁺] = 2 × 0.005 = 0.01 M = 10⁻² M. Maka pH = -log(10⁻²) = 2.',
              },
            ],
          };

        case 'latihan_soal':
        default:
          return {
            type: 'latihan_soal',
            title: 'MISI PENGUATAN ALME',
            summary: `Drill latihan soal formatif kimia terpadu untuk mengevaluasi pemahaman konsep dan perhitungan larutan pada Tujuan Pembelajaran: "${tpTitle}".`,
            instructions: `Jawab pertanyaan latihan berikut secara mandiri untuk memantapkan pemahaman konsep kimia.`,
            questions: [
              {
                question: 'Larutan penyangga (buffer) dapat mempertahankan pH ketika ditambahkan sedikit asam maupun basa. Campuran manakah berikut ini yang dapat membentuk larutan penyangga asam?',
                options: [
                  'Asam asetat (CH₃COOH) dan natrium asetat (CH₃COONa)',
                  'Asam klorida (HCl) dan natrium klorida (NaCl)',
                  'Asam nitrat (HNO₃) dan amonium klorida (NH₄Cl)',
                  'Natrium hidroksida (NaOH) dan kalium hidroksida (KOH)',
                ],
                correctAnswer: 'Asam asetat (CH₃COOH) dan natrium asetat (CH₃COONa)',
                explanation: 'Larutan penyangga asam terdiri dari asam lemah (CH₃COOH) dan basa konjugasinya / garamnya (CH₃COO⁻ dari CH₃COONa).',
              },
              {
                question: 'Unsur klorin memiliki nomor atom 17. Konfigurasi elektron atom klorin pada keadaan dasar dan letak periodenya adalah:',
                options: [
                  '1s² 2s² 2p⁶ 3s² 3p⁵ (Periode 3, Golongan VIIA)',
                  '1s² 2s² 2p⁶ 3s² 3p⁴ (Periode 3, Golongan VIA)',
                  '1s² 2s² 2p⁶ 3s¹ 3p⁶ (Periode 2, Golongan VIIA)',
                  '1s² 2s² 2p⁶ 3s² 3d⁵ (Periode 4, Golongan VIIB)',
                ],
                correctAnswer: '1s² 2s² 2p⁶ 3s² 3p⁵ (Periode 3, Golongan VIIA)',
                explanation: 'Kulit terluar n = 3 (Periode 3) dengan elektron valensi 2 + 5 = 7 (Golongan VIIA / halogen).',
              },
            ],
          };
      }
    }

    // 3. KONTEN MATA PELAJARAN BIOLOGI
    if (isBiologi) {
      switch (type) {
        case 'remedial':
          return {
            type: 'remedial',
            title: 'MISI PENGUATAN ALME',
            summary: `Bimbingan terstruktur konsep dasar organisasi biologis, struktur dan fungsi organel sel, serta mekanisme bioproses sesuai Tujuan Pembelajaran: "${tpTitle}".`,
            instructions: `Pahami prinsip bioproses esensial berikut dan selesaikan pertanyaan pemahaman bertahap.`,
            questions: [
              {
                question: 'Organel sel yang berfungsi sebagai pusat pembangkit energi utama (sintesis molekul ATP) melalui proses respirasi aerobik seluler adalah:',
                options: ['Mitokondria', 'Badan Golgi', 'Ribosom', 'Retikulum Endoplasma Kasar'],
                correctAnswer: 'Mitokondria',
                explanation: 'Mitokondria merupakan "powerhouse of the cell" yang memproduksi mayoritas ATP melalui siklus Krebs dan rantai transpor elektron pada krista membran dalam.',
              },
              {
                question: 'Perpindahan molekul air melintasi membran semipermeabel dari larutan berkonsentrasi zat terlarut rendah (hipotonis) menuju konsentrasi tinggi (hipertonis) disebut:',
                options: ['Osmosis', 'Difusi terfasilitasi', 'Endositosis', 'Pompa ion natrium-kalium'],
                correctAnswer: 'Osmosis',
                explanation: 'Osmosis adalah peristiwa perpindahan pelarut (air) melintasi membran semipermeabel secara pasif menuruni gradien konsentrasi pelarut.',
              },
            ],
          };

        case 'pengayaan':
          return {
            type: 'pengayaan',
            title: 'MISI PENGUATAN ALME',
            summary: `Tantangan eksplorasi genetika molekuler, bioteknologi modern CRISPR, dan metabolisme tingkat lanjut untuk Tujuan Pembelajaran: "${tpTitle}".`,
            instructions: `Analisis studi kasus bioteknologi molekuler dan pilihlah pendekatan bioproses yang paling presisi.`,
            questions: [
              {
                question: 'Dalam teknologi DNA rekombinan untuk memproduksi insulin manusia oleh bakteri E. coli, mengapa plasmid bakteri dan gen pengkode insulin harus dipotong menggunakan enzim restriksi endonuklease yang sama?',
                options: [
                  'Agar menghasilkan ujung lengket (sticky ends) komplementer yang dapat disambungkan oleh enzim DNA ligase',
                  'Agar bakteri tidak mendegradasi plasmid rekombinan menjadi asam amino',
                  'Untuk menggandakan jumlah kromosom sirkular bakteri secara simultan',
                  'Agar dinding sel bakteri melarut saat proses transformasi termal',
                ],
                correctAnswer: 'Agar menghasilkan ujung lengket (sticky ends) komplementer yang dapat disambungkan oleh enzim DNA ligase',
                explanation: 'Pemotongan dengan enzim restriksi yang identik menghasilkan urutan basa ujung lengket yang berpasangan secara komplementer (A-T, G-C) sehingga ligase dapat membentuk ikatan fosfodiester dengan kuat.',
              },
              {
                question: 'Pada tahap fotofosforilasi non-siklik reaksi terang fotosintesis, elektron yang hilang dari klorofil pusat reaksi Fotosistem II (P680) digantikan oleh elektron yang berasal dari:',
                options: [
                  'Fotolisis molekul air (H₂O)',
                  'Siklus Calvin di stroma',
                  'Oksidasi molekul glukosa',
                  'Reduksi molekul NADP⁺ menjadi NADPH',
                ],
                correctAnswer: 'Fotolisis molekul air (H₂O)',
                explanation: 'Pemecahan molekul air (2H₂O → 4H⁺ + 4e⁻ + O₂) oleh enzim di Fotosistem II menyediakan elektron untuk menggantikan elektron tereksitasi di P680.',
              },
            ],
          };

        case 'soal_literasi':
          return {
            type: 'soal_literasi',
            title: 'MISI PENGUATAN ALME',
            summary: `Penguatan literasi wacana biosains, ekologi lingkungan, dan mekanisme adaptasi evolusioner pada Tujuan Pembelajaran: "${tpTitle}".`,
            instructions: `Bacalah artikel ilmiah singkat mengenai kesehatan dan evolusi patogen berikut, kemudian jawab pertanyaan literasi kritis.`,
            questions: [
              {
                question: 'Teks Wacana: "Penggunaan antibiotik spektrum luas yang tidak tuntas pada peternakan dan klinik medis memicu seleksi alam strain bakteri resisten superbug (MRSA). Bakteri yang memiliki mutasi spontan atau plasmid gen resistensi beta-laktamase bertahan hidup saat dosis subletal diberikan, lalu membelah diri dengan cepat dan mentransfer resistensinya melalui konjugasi horisontal ke bakteri lain."\n\nBerdasarkan wacana di atas, faktor utama yang mempercepat penyebaran resistensi antibiotik pada populasi bakteri adalah:',
                options: [
                  'Tekanan seleksi akibat paparan antibiotik yang tidak tuntas disertai transfer gen resistensi secara horisontal antar bakteri',
                  'Penurunan laju mutasi spontan bakteri akibat paparan disinfektan',
                  'Bakteri mengembangkan sistem imun adaptif mirip antibodi mamalia',
                  'Antibiotik mengubah struktur asam nukleat bakteri secara sengaja menjadi virulen',
                ],
                correctAnswer: 'Tekanan seleksi akibat paparan antibiotik yang tidak tuntas disertai transfer gen resistensi secara horisontal antar bakteri',
                explanation: 'Paparan dosis tidak tuntas membunuh bakteri sensitif tetapi membiarkan bakteri mutan resisten bertahan dan memperbanyak diri serta menyebarkan gen resistensi via konjugasi.',
              },
              {
                question: 'Mekanisme transfer gen resistensi antar sel bakteri melalui kontak jembatan sitoplasma pilus seks disebut:',
                options: ['Konjugasi', 'Transformasi', 'Transduksi', 'Transkripsi'],
                correctAnswer: 'Konjugasi',
                explanation: 'Konjugasi adalah transfer materi genetik (plasmid) antar sel bakteri secara langsung melalui kontak fisik pilus.',
              },
            ],
          };

        case 'soal_numerasi':
          return {
            type: 'soal_numerasi',
            title: 'MISI PENGUATAN ALME',
            summary: `Penguatan kalkulasi rasio genetika Mendel, hukum Hardy-Weinberg, dan biomassa ekologi pada Tujuan Pembelajaran: "${tpTitle}".`,
            instructions: `Gunakan prinsip probabilitas dan genetika kuantitatif untuk menjawab pertanyaan berikut.`,
            questions: [
              {
                question: 'Pada persilangan dihibrid tanaman kapri berbiji bulat kuning heterozigot (BbKk) dengan sesamanya, berapakah probabilitas persentase keturunan yang memiliki fenotipe berbiji keriput hijau (bbkk)?',
                options: ['6.25% (1/16)', '18.75% (3/16)', '25.00% (4/16)', '56.25% (9/16)'],
                correctAnswer: '6.25% (1/16)',
                explanation: 'Rasio fenotipe dihibrid Mendel adalah 9 : 3 : 3 : 1. Fenotipe resesif ganda (keriput hijau, bbkk) memiliki perbandingan 1/16 = 0.0625 atau 6.25%.',
              },
              {
                question: 'Dalam suatu populasi terisolasi yang memenuhi kesetimbangan Hardy-Weinberg, frekuensi alel resesif albino q adalah 0.2. Berapakah persentase individu yang berstatus pembawa (heterozigot, 2pq) dalam populasi tersebut?',
                options: ['32%', '64%', '16%', '4%'],
                correctAnswer: '32%',
                explanation: 'Jika q = 0.2, maka p = 1 - 0.2 = 0.8. Frekuensi heterozigot = 2pq = 2 × 0.8 × 0.2 = 0.32 atau 32%.',
              },
            ],
          };

        case 'latihan_soal':
        default:
          return {
            type: 'latihan_soal',
            title: 'MISI PENGUATAN ALME',
            summary: `Drill uji pemahaman biosains terpadu untuk mengukur ketuntasan kompetensi seluler dan fisiologis pada Tujuan Pembelajaran: "${tpTitle}".`,
            instructions: `Kerjakan soal-soal latihan berikut secara mandiri untuk mengukur ketuntasan belajar secara objektif.`,
            questions: [
              {
                question: 'Enzim katalase mempercepat penguraian racun hidrogen peroksida (2H₂O₂ → 2H₂O + O₂). Apabila larutan ekstrak hati yang mengandung katalase dipanaskan hingga 90°C, reaksi tidak lagi menghasilkan gelembung oksigen. Hal ini terjadi karena:',
                options: [
                  'Enzim mengalami denaturasi protein sehingga sisi aktifnya rusak permanen',
                  'Molekul H₂O₂ membeku pada suhu tinggi',
                  'Katalase berubah menjadi asam nukleat',
                  'Substrat bereaksi langsung dengan udara tanpa enzim',
                ],
                correctAnswer: 'Enzim mengalami denaturasi protein sehingga sisi aktifnya rusak permanen',
                explanation: 'Suhu tinggi merusak ikatan hidrogen dan struktur spasial protein enzim (denaturasi), mengakibatkan hilangnya fungsi katalitik sisi aktif.',
              },
              {
                question: 'Urutan tahapan sintesis protein yang benar di dalam sel eukariotik adalah:',
                options: [
                  'Transkripsi kode genetik DNA menjadi mRNA di nukleus → translasi mRNA oleh ribosom di sitoplasma',
                  'Translasi DNA menjadi tRNA di sitoplasma → transkripsi oleh ribosom',
                  'Replikasi tRNA di sitoplasma → pemotongan asam amino oleh enzim lisosom',
                  'Transkripsi ribosom menjadi mRNA → translasi di membran mitokondria',
                ],
                correctAnswer: 'Transkripsi kode genetik DNA menjadi mRNA di nukleus → translasi mRNA oleh ribosom di sitoplasma',
                explanation: 'Dogma sentral biologi molekuler menyatakan DNA ditranskripsi menjadi mRNA di dalam nukleus, kemudian ditranslasi menjadi untaian polipeptida oleh ribosom di sitoplasma.',
              },
            ],
          };
      }
    }

    // 4. KONTEN DEFAULT: FISIKA & MIPA UMUM (Disesuaikan dengan TP)
    switch (type) {
      case 'remedial':
        return {
          type: 'remedial',
          title: 'MISI PENGUATAN ALME',
          summary: `Bimbingan langkah demi langkah untuk menguatkan pemahaman konsep dasar kalor, suhu, perpindahan energi, dan formulasi matematis dasar sesuai Tujuan Pembelajaran: "${tpTitle}".`,
          instructions: `Pelajari rangkuman prinsip dasar berikut, kemudian jawab pertanyaan pemahaman bertahap untuk memulihkan pemahaman konsep sebelum melanjutkan ke misi utama.`,
          questions: [
            {
              question:
                'Sebuah zat cair bermassa 0.5 kg dipanaskan sehingga suhunya naik dari 25°C menjadi 45°C. Jika kalor jenis zat adalah 4.000 J/kg°C, berapakah kalor yang diserap zat tersebut?',
              options: [
                '20.000 Joule',
                '40.000 Joule',
                '80.000 Joule',
                '10.000 Joule',
              ],
              correctAnswer: '40.000 Joule',
              explanation:
                'Gunakan rumus Q = m · c · ΔT. Di sini: m = 0.5 kg, c = 4000 J/kg°C, ΔT = 45 - 25 = 20°C. Maka Q = 0.5 × 4000 × 20 = 40.000 Joule.',
            },
            {
              question:
                'Manakah pernyataan yang paling tepat mengenai perbedaan antara suhu dan kalor?',
              options: [
                'Suhu adalah energi yang berpindah, sedangkan kalor adalah derajat panas',
                'Suhu adalah derajat panas suatu benda, sedangkan kalor adalah energi panas yang berpindah karena perbedaan suhu',
                'Suhu dan kalor memiliki satuan yang sama yaitu Kelvin',
                'Kalor tidak bergantung pada massa benda, sedangkan suhu selalu berbanding lurus dengan massa',
              ],
              correctAnswer:
                'Suhu adalah derajat panas suatu benda, sedangkan kalor adalah energi panas yang berpindah karena perbedaan suhu',
              explanation:
                'Suhu menyatakan tingkat energi kinetik rata-rata partikel (derajat panas), sedangkan kalor adalah energi termal yang mengalir akibat perbedaan suhu.',
            },
          ],
        };

      case 'pengayaan':
        return {
          type: 'pengayaan',
          title: 'MISI PENGUATAN ALME',
          summary: `Tantangan eksplorasi mendalam untuk mengintegrasikan model termodinamika kompleks dengan efisiensi energi terbarukan pada Tujuan Pembelajaran: "${tpTitle}".`,
          instructions:
            'Analisis skenario rekayasa nyata tingkat lanjut di bawah ini dan pilihlah solusi berbasis efisiensi optimal.',
          questions: [
            {
              question:
                'Pada sistem panel fotovoltaik hibrida termal (PV/T), panas berlebih menurunkan efisiensi listrik sel surya sebesar 0.4% per 1°C kenaikan di atas 25°C. Jika suhu permukaan panel mencapai 65°C tanpa pendingin, berapa penurunan efisiensi totalnya dan strategi mitigasi apa yang paling tepat?',
              options: [
                'Turun 8%; menggunakan fluida pendingin sirkulasi pipa kalor tembaga terhubung kalorimeter',
                'Turun 16%; memasang penutup kaca tambahan agar radiasi inframerah terperangkap',
                'Turun 16%; menggunakan sirkulasi fluida pendingin air untuk menyerap kalor buangan sekaligus menghasilkan air panas',
                'Turun 40%; meningkatkan voltase inverter secara artifisial',
              ],
              correctAnswer:
                'Turun 16%; menggunakan sirkulasi fluida pendingin air untuk menyerap kalor buangan sekaligus menghasilkan air panas',
              explanation:
                'Kenaikan suhu ΔT = 65 - 25 = 40°C. Penurunan efisiensi = 40 × 0.4% = 16%. Solusi PV/T memanfaatkan fluida pendingin untuk mengambil energi termal buangan sehingga efisiensi sel pulih sekaligus menghasilkan air hangat.',
            },
            {
              question:
                'Dalam rancangan kalorimeter adiabatik presisi tinggi, dinding wadah dilapisi perak mengkilap di bagian dalam dan ruang vakum ganda. Prinsip fisika apa yang dimanfaatkan untuk meminimalkan kehilangan kalor?',
              options: [
                'Ruang vakum mencegah konveksi & konduksi; lapisan perak memantulkan radiasi termal',
                'Ruang vakum meningkatkan kapasitas kalor jenis bejana',
                'Lapisan perak meningkatkan konduksi termal ke lingkungan luar',
                'Ruang hampa mempercepat kesetimbangan termal dengan udara sekitar',
              ],
              correctAnswer:
                'Ruang vakum mencegah konveksi & konduksi; lapisan perak memantulkan radiasi termal',
              explanation:
                'Vakum menghilangkan partikel penghantar (mencegah konduksi dan konveksi), sedangkan permukaan perak mengkilap memiliki emisivitas sangat rendah dan reflektifitas tinggi sehingga memantulkan radiasi panas kembali ke dalam.',
            },
          ],
        };

      case 'soal_literasi':
        return {
          type: 'soal_literasi',
          title: 'MISI PENGUATAN ALME',
          summary: `Penguatan kompetensi literasi membaca teks saintifik, menafsirkan konteks fenomena, dan menarik kesimpulan berbasis bukti empiris pada Tujuan Pembelajaran: "${tpTitle}".`,
          instructions:
            'Bacalah wacana saintifik singkat berikut dengan saksama, kemudian jawab pertanyaan analisis literasi.',
          questions: [
            {
              question:
                'Teks Wacana: "Di daerah pesisir, tambak garam tradisional sangat bergantung pada penguapan air laut oleh radiasi matahari dan angin. Saat musim hujan tiba, kelembaban udara meningkat tajam (hingga 85%) dan sinar matahari berkurang. Seorang siswa MIPA merancang rumah kaca pengering garam berbahan plastik UV dengan sirkulasi udara paksa bertenaga surya untuk mempercepat laju evaporasi."\n\nBerdasarkan wacana di atas, mengapa inovasi rumah kaca plastik UV dengan sirkulasi udara dapat mempercepat kristalisasi garam saat musim hujan?',
              options: [
                'Plastik UV menjebak radiasi termal inframerah (efek rumah kaca) untuk menaikkan suhu, sementara sirkulasi paksa membuang uap air jenuh agar udara di atas garam tidak mencapai titik jenuh',
                'Plastik UV mendinginkan air laut agar garam langsung mengkristal pada suhu rendah',
                'Sirkulasi paksa menambah kadar air garam di dalam ruangan agar penguapan terjadi dua arah',
                'Rumah kaca berfungsi menghalangi semua jenis radiasi elektromagnetik masuk ke tambak',
              ],
              correctAnswer:
                'Plastik UV menjebak radiasi termal inframerah (efek rumah kaca) untuk menaikkan suhu, sementara sirkulasi paksa membuang uap air jenuh agar udara di atas garam tidak mencapai titik jenuh',
              explanation:
                'Analisis literasi: Penjebakan panas menaikkan suhu air (meningkatkan tekanan uap zat cair), sedangkan ventilasi paksa menurunkan kelembaban relatif di permukaan air dengan mengusir uap jenuh, memaksimalkan laju evaporasi netto.',
            },
            {
              question:
                'Dari wacana di atas, variabel bebas (manipulasi) dan variabel terikat (respon) dari rancangan penelitian siswa tersebut adalah:',
              options: [
                'Variabel bebas: Penggunaan rumah kaca bersirkulasi udara; Variabel terikat: Laju penguapan/kristalisasi garam',
                'Variabel bebas: Massa garam; Variabel terikat: Luas tambak garam',
                'Variabel bebas: Curah hujan; Variabel terikat: Warna plastik UV',
                'Variabel bebas: Arah angin; Variabel terikat: Jam terbit matahari',
              ],
              correctAnswer:
                'Variabel bebas: Penggunaan rumah kaca bersirkulasi udara; Variabel terikat: Laju penguapan/kristalisasi garam',
              explanation:
                'Variabel bebas adalah perlakuan yang sengaja diubah oleh peneliti (rumah kaca sirkulasi paksa), dan variabel terikat adalah akibat yang diamati/diukur (kecepatan evaporasi/kristalisasi).',
            },
          ],
        };

      case 'soal_numerasi':
        return {
          type: 'soal_numerasi',
          title: 'MISI PENGUATAN ALME',
          summary: `Penguatan kompetensi numerasi saintifik dalam membaca grafik regresi linear y = mx + c, menghitung gradien, dan estimasi nilai kuantitatif pada Tujuan Pembelajaran: "${tpTitle}".`,
          instructions:
            'Gunakan data numerik dan interpretasi rumus untuk menyelesaikan permasalahan perhitungan di bawah ini.',
          questions: [
            {
              question:
                'Diberikan data eksperimen pemanasan air: pada sumbu X adalah Waktu pemanasan (t dalam menit) dan sumbu Y adalah Kenaikan Suhu (ΔT dalam °C). Dari regresi linear diperoleh persamaan garis lurus: y = 2.5x + 0.4 dengan r² = 0.985.\n\nBerapakah perkiraan kenaikan suhu air setelah dipanaskan selama 12 menit?',
              options: [
                '30.4 °C',
                '24.8 °C',
                '32.0 °C',
                '28.5 °C',
              ],
              correctAnswer: '30.4 °C',
              explanation:
                'Substitusikan nilai x = 12 ke dalam persamaan: y = (2.5 × 12) + 0.4 = 30 + 0.4 = 30.4 °C.',
            },
            {
              question:
                'Dari persamaan y = 2.5x + 0.4 di atas, nilai gradien m = 2.5 °C/menit merepresentasikan makna fisis apa?',
              options: [
                'Suhu mula-mula air sebelum kompor dinyalakan',
                'Laju kenaikan suhu rata-rata air per satuan waktu pemanasan',
                'Jumlah kalor total yang terbuang ke lingkungan sekitar',
                'Waktu yang dibutuhkan air hingga mencapai titik didih 100°C',
              ],
              correctAnswer:
                'Laju kenaikan suhu rata-rata air per satuan waktu pemanasan',
              explanation:
                'Gradien (kemiringan) m = Δy/Δx = Δ(Suhu)/Δ(Waktu), yang secara fisis menyatakan laju perubahan suhu per satuan waktu (°C per menit).',
            },
          ],
        };

      case 'latihan_soal':
      default:
        return {
          type: 'latihan_soal',
          title: 'MISI PENGUATAN ALME',
          summary: `Drill soal latihan formatif terintegrasi untuk menguji kesiapan komprehensif konsep, penalaran, dan aplikasi saintifik pada Tujuan Pembelajaran: "${tpTitle}".`,
          instructions:
            'Jawablah soal-soal latihan berikut secara mandiri untuk mengukur ketuntasan belajar secara objektif.',
          questions: [
            {
              question:
                'Dua batang logam A dan B memiliki panjang dan luas penampang yang sama. Konduktivitas termal logam A adalah dua kali logam B (kA = 2·kB). Jika kedua batang disambungkan seri dan ujung-ujungnya diberi beda suhu, batang manakah yang memiliki penurunan suhu lebih tajam per satuan panjang?',
              options: [
                'Batang B (karena konduktivitas termal lebih rendah sehingga gradien suhu harus lebih curam)',
                'Batang A (karena konduktivitas termal lebih tinggi sehingga panas menumpuk)',
                'Kedua batang memiliki gradien penurunan suhu yang identik',
                'Tergantung pada massa jenis masing-masing logam',
              ],
              correctAnswer:
                'Batang B (karena konduktivitas termal lebih rendah sehingga gradien suhu harus lebih curam)',
              explanation:
                'Dalam sambungan seri, laju kalor H = k·A·(ΔT/L) sama besar pada kedua batang. Jika kA = 2·kB, maka untuk menghasilkan H yang sama, gradien suhu pada batang B (ΔT_B) harus 2 kali lebih besar daripada batang A.',
            },
            {
              question:
                'Sebuah kalorimeter berisi 200 gram air bersuhu 20°C. Kemudian ke dalamnya dimasukkan 100 gram logam bersuhu 80°C. Suhu akhir kesetimbangan termal adalah 25°C. Jika kalorimeter dianggap tidak menyerap kalor (c_air = 1 kal/g°C), berapakah kalor jenis logam tersebut?',
              options: [
                '0.18 kal/g°C',
                '0.25 kal/g°C',
                '0.33 kal/g°C',
                '0.08 kal/g°C',
              ],
              correctAnswer: '0.18 kal/g°C',
              explanation:
                'Berdasarkan Azas Black: Q_lepas = Q_terima.\nm_logam · c_logam · (80 - 25) = m_air · c_air · (25 - 20)\n100 · c_logam · 55 = 200 · 1 · 5\n5500 · c_logam = 1000\nc_logam = 1000 / 5500 ≈ 0.182 kal/g°C.',
            },
          ],
        };
    }
  }

  /**
   * Menentukan jenis sisipan pembelajaran ALME secara objektif berdasarkan skor input
   */
  public static determineInterventionType(
    diagnosticScore: number,
    litScore?: number,
    numScore?: number,
    reasScore?: number
  ): AlmeInterventionType {
    const lit = litScore ?? diagnosticScore;
    const num = numScore ?? diagnosticScore;
    const reas = reasScore ?? diagnosticScore;

    // 1. Jika skor diagnostik < 70 atau ada defisit ganda
    if (diagnosticScore < 70 || (lit < 68 && num < 68)) {
      return 'remedial';
    }

    // 2. Jika skor istimewa (>= 85)
    if (diagnosticScore >= 85 && lit >= 80 && num >= 80) {
      return 'pengayaan';
    }

    // 3. Jika defisit pada numerasi
    if (num < 72) {
      return 'soal_numerasi';
    }

    // 4. Jika defisit pada literasi
    if (lit < 72) {
      return 'soal_literasi';
    }

    // 5. Normal / penguatan mandiri
    return 'latihan_soal';
  }

  /**
   * Analisis komprehensif ALME
   */
  public static analyze(input: AlmeAnalysisInput): AlmeRecommendation {
    const diag = input.assessmentResult ?? input.assessmentResultScore ?? 75;
    const lit = input.literacy ?? input.literacyScore ?? 80;
    const num = input.numeracy ?? input.numeracyScore ?? 75;
    const reas = input.reasoning ?? input.reasoningScore ?? 80;
    const exp = input.experimentResult ?? input.experimentResultScore ?? 75;

    const interventionType = this.determineInterventionType(diag, lit, num, reas);
    const interventionContent = this.getInterventionContent(interventionType, 'Fisika');

    const categoryLabels: Record<AlmeInterventionType, 'Remedial' | 'Pengayaan' | 'Soal Literasi' | 'Soal Numerasi' | 'Latihan Soal'> = {
      remedial: 'Remedial',
      pengayaan: 'Pengayaan',
      soal_literasi: 'Soal Literasi',
      soal_numerasi: 'Soal Numerasi',
      latihan_soal: 'Latihan Soal',
    };

    const category = categoryLabels[interventionType];

    // 1. Sisipan Remedial
    if (interventionType === 'remedial') {
      return {
        type: 'Remedial',
        recommendationType: 'Remedial',
        interventionType: 'remedial',
        interventionCategory: 'Remedial',
        category: 'Remedial',
        title: 'Sisipan ALME: Remedial Fondasi Konsep Esensial',
        message: 'Penguatan konsep dasar kalor, perubahan wujud, dan formulasi matematis terarah.',
        current: `${diag}/100`,
        target: '75/100',
        gap: `${Math.max(0, 75 - diag)} poin`,
        reason: 'Hasil asesmen awal memerlukan pemulihan konsep kunci sebelum masuk simulasi kompleks.',
        actionText: 'Buka Sisipan Remedial',
        recommendedMissionId: 'msn-cls-xii-1-1',
        actionTargetMissionId: 'msn-cls-xii-1-1',
        recommendedMissionTitle: 'Misi 1: Fondasi Konsep & Teman Berpikir AI',
        pedagogicalAction: 'Bimbingan Konsep Esensial & Scaffolding AI Berjenjang',
        whyExplanation:
          'ALME menyiapkan modul remedial interaktif untuk memastikan kamu memahami persamaan Azas Black dan konsep konduksi kalor secara bertahap.',
        difficultyLevel: 1,
        difficulty: 1,
        xpReward: 120,
        interventionContent,
      };
    }

    // 2. Sisipan Soal Numerasi
    if (interventionType === 'soal_numerasi') {
      return {
        type: 'Soal Numerasi',
        recommendationType: 'Numeracy',
        interventionType: 'soal_numerasi',
        interventionCategory: 'Soal Numerasi',
        category: 'Soal Numerasi',
        title: 'Sisipan ALME: Penguatan Soal Numerasi Sains',
        message: 'Penguatan interpretasi grafik bivariat, persamaan garis regresi, dan perhitungan data.',
        current: `${num}/100`,
        target: '80/100',
        gap: `${Math.max(0, 80 - num)} poin`,
        reason: 'Capaian numerasi perlu penguatan pada konversi satuan dan perhitungan kalor jenis.',
        actionText: 'Buka Sisipan Soal Numerasi',
        recommendedMissionId: 'msn-cls-xii-1-1',
        actionTargetMissionId: 'msn-cls-xii-1-1',
        recommendedMissionTitle: 'Misi 1: Scaffold Regresi Linear & Numerasi Data',
        pedagogicalAction: 'Latihan Kalkulasi Numerasi, Gradien Regresi & Data Sensor',
        whyExplanation:
          'Kamu sudah memahami konsep dasar grafik, namun disarankan memperdalam perhitungan nilai gradien m dan korelasi r² untuk memprediksi data bivariat secara presisi.',
        difficultyLevel: 2,
        difficulty: 2,
        xpReward: 130,
        interventionContent,
      };
    }

    // 3. Sisipan Soal Literasi
    if (interventionType === 'soal_literasi') {
      return {
        type: 'Soal Literasi',
        recommendationType: 'Literacy',
        interventionType: 'soal_literasi',
        interventionCategory: 'Soal Literasi',
        category: 'Soal Literasi',
        title: 'Sisipan ALME: Penguatan Soal Literasi Saintifik',
        message: 'Peningkatan pemahaman teks fenomena ilmiah, interpretasi wacana, dan kesimpulan saintifik.',
        current: `${lit}/100`,
        target: '85/100',
        gap: `${Math.max(0, 85 - lit)} poin`,
        reason: 'Meningkatkan daya interpretasi wacana berbasis kasus nyata dan perancangan variabel sains.',
        actionText: 'Buka Sisipan Soal Literasi',
        recommendedMissionId: 'msn-cls-xii-1-2',
        actionTargetMissionId: 'msn-cls-xii-1-2',
        recommendedMissionTitle: 'Misi 2: Studi Kasus Nyata & Literasi Sains',
        pedagogicalAction: 'Analisis Wacana Fenomena Nyata & Sintesis Informasi Saintifik',
        whyExplanation:
          'ALME merekomendasikan penelaahan wacana terarah agar kamu semakin terampil merumuskan hipotesis dan menguraikan variabel sains dalam teks ilmiah.',
        difficultyLevel: 2,
        difficulty: 2,
        xpReward: 135,
        interventionContent,
      };
    }

    // 4. Sisipan Pengayaan
    if (interventionType === 'pengayaan') {
      return {
        type: 'Pengayaan',
        recommendationType: 'Enrichment',
        interventionType: 'pengayaan',
        interventionCategory: 'Pengayaan',
        category: 'Pengayaan',
        title: 'Sisipan ALME: Pengayaan & Tantangan HOTS STEM',
        message: 'Eksplorasi tingkat lanjut integrasi matematika-fisika pada masalah rekayasa berkelanjutan.',
        current: `${Math.round((diag + lit + num + reas) / 4)}/100`,
        target: '95/100',
        gap: 'Optimal',
        reason: 'Seluruh indikator kompetensi telah mencapai level mandiri unggul.',
        actionText: 'Buka Sisipan Pengayaan',
        recommendedMissionId: 'msn-cls-xii-1-3',
        actionTargetMissionId: 'msn-cls-xii-1-3',
        recommendedMissionTitle: 'Misi 3: Eksperimen Virtual Sensor Presisi Tinggi',
        pedagogicalAction: 'Tantangan Pemecahan Masalah HOTS & Desain Rekayasa Inovatif',
        whyExplanation:
          'Capaian asesmenmu istimewa. ALME menantangmu menyelesaikan proyek efisiensi fotovoltaik termal dan rancang bangun kalorimeter canggih.',
        difficultyLevel: 4,
        difficulty: 4,
        xpReward: 180,
        interventionContent,
      };
    }

    // 5. Sisipan Latihan Soal
    return {
      type: 'Latihan Soal',
      recommendationType: 'Strengthening',
      interventionType: 'latihan_soal',
      interventionCategory: 'Latihan Soal',
      category: 'Latihan Soal',
      title: 'Sisipan ALME: Latihan Soal & Evaluasi Mandiri',
      message: 'Uji pemahaman komprehensif untuk memantapkan penguasaan materi dan kesiapan belajar.',
      current: `${Math.round((diag + lit + num + reas) / 4)}/100`,
      target: '85/100',
      gap: `${Math.max(0, 85 - diag)} poin`,
      reason: 'Pemantapan keterampilan menyelesaikan soal beragam tipe sebelum asesmen sumatif.',
      actionText: 'Buka Sisipan Latihan Soal',
      recommendedMissionId: 'msn-cls-xii-1-2',
      actionTargetMissionId: 'msn-cls-xii-1-2',
      recommendedMissionTitle: 'Misi 2: Penerapan Konsep & Eksplorasi Sains',
      pedagogicalAction: 'Drill Soal Formatif Terarah & Uji Pemahaman Mandiri',
      whyExplanation:
        'Pemahamanmu sudah berkembang baik. Latihan soal variatif ini akan memperkuat daya analisis dan kesiapanmu menghadapi asesmen komprehensif.',
      difficultyLevel: 3,
      difficulty: 3,
      xpReward: 150,
      interventionContent,
    };
  }
}

