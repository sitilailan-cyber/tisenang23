import { SensorReading } from '../../types';
import { SensorDataSourceMode } from './types';
import { SpreadsheetSensorProvider } from './SpreadsheetSensorProvider';

class SensorManager {
  private mode: SensorDataSourceMode = 'simulated';
  public spreadsheetProvider: SpreadsheetSensorProvider;
  private lastReading: SensorReading;
  private baseTemp = 27.5;
  private baseLight = 850;
  private baseHumidity = 62;

  constructor() {
    this.spreadsheetProvider = new SpreadsheetSensorProvider();
    this.lastReading = this.generateSimulatedReading();
  }

  public getMode(): SensorDataSourceMode {
    return this.mode;
  }

  public setMode(mode: SensorDataSourceMode): void {
    this.mode = mode;
  }

  public generateSimulatedReading(): SensorReading {
    const jitter = (Math.random() - 0.5) * 0.4;
    const temp = Number((this.baseTemp + jitter).toFixed(2));
    const hum = Math.round(this.baseHumidity + (Math.random() - 0.5) * 2);
    const light = Math.round(this.baseLight + (Math.random() - 0.5) * 30);
    const volt = Number((3.28 + (Math.random() - 0.5) * 0.05).toFixed(2));
    const curr = Number((0.21 + (Math.random() - 0.5) * 0.02).toFixed(3));
    const cond = Math.round(450 + (Math.random() - 0.5) * 15);
    const mot = Math.random() > 0.85 ? 1 : 0;

    const reading: SensorReading = {
      timestamp: Date.now(),
      port1: {
        temperature: temp,
      },
      port2: {
        humidity: hum,
      },
      port3: {
        motion: mot,
      },
      port4: {
        voltage: volt,
        current: curr,
        conductivity: cond,
      },
      port5: {
        light: light,
      },
    };

    this.lastReading = reading;
    return reading;
  }

  public async readSensors(): Promise<SensorReading> {
    if (this.mode === 'spreadsheet') {
      try {
        const res = await this.spreadsheetProvider.fetchSpreadsheetData();
        if (res.success && res.latestReading) {
          this.lastReading = res.latestReading;
          return res.latestReading;
        }
      } catch (err) {
        console.warn('Gagal membaca data spreadsheet sensor, beralih ke simulasi:', err);
      }
    }

    return this.generateSimulatedReading();
  }

  public getLatestReading(): SensorReading {
    return this.lastReading;
  }
}

export const sensorManager = new SensorManager();
