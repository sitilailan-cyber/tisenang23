import { jsPDF } from 'jspdf';
import { AsesmenAwalInput, Student, User } from '../types';

export interface ExportAsesmenPdfParams {
  className: string;
  subjectName: string;
  teacherName: string;
  assessmentData: AsesmenAwalInput[];
  students: Array<Student & { user: User; className: string }>;
}

export function exportAsesmenToPdf(params: ExportAsesmenPdfParams): void {
  const { className, subjectName, teacherName, assessmentData } = params;
  const doc = new jsPDF();

  // Header
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('TI SENANG — LAPORAN ASESMEN AWAL DIAGNOSTIK MIPA', 14, 20);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Mata Pelajaran : ${subjectName}`, 14, 28);
  doc.text(`Kelas          : ${className}`, 14, 34);
  doc.text(`Guru Pengampu  : ${teacherName}`, 14, 40);
  doc.text(`Tanggal Cetak  : ${new Date().toLocaleDateString('id-ID')}`, 14, 46);

  // Table header
  let startY = 56;
  doc.setFillColor(30, 41, 59);
  doc.rect(14, startY, 182, 8, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('No', 16, startY + 5.5);
  doc.text('Nama Siswa', 26, startY + 5.5);
  doc.text('Diagnostik', 90, startY + 5.5);
  doc.text('Literasi', 112, startY + 5.5);
  doc.text('Numerasi', 130, startY + 5.5);
  doc.text('Penalaran', 150, startY + 5.5);
  doc.text('Kesiapan', 170, startY + 5.5);

  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'normal');
  let currentY = startY + 8;

  assessmentData.forEach((row, idx) => {
    if (currentY > 270) {
      doc.addPage();
      currentY = 20;
    }

    if (idx % 2 === 1) {
      doc.setFillColor(241, 245, 249);
      doc.rect(14, currentY, 182, 7, 'F');
    }

    doc.text(String(idx + 1), 16, currentY + 5);
    doc.text((row.studentName || 'Murid').slice(0, 26), 26, currentY + 5);
    doc.text(String(row.diagnosticScore), 94, currentY + 5);
    doc.text(String(row.literacyScore), 116, currentY + 5);
    doc.text(String(row.numeracyScore), 134, currentY + 5);
    doc.text(String(row.reasoningScore), 154, currentY + 5);
    doc.text((row.readinessLevel || 'Berkembang').slice(0, 14), 170, currentY + 5);

    currentY += 7;
  });

  // Footer summary
  currentY += 8;
  if (currentY > 260) {
    doc.addPage();
    currentY = 20;
  }

  doc.setFont('helvetica', 'italic');
  doc.setFontSize(8);
  doc.text(
    '* Laporan ini diunduh secara otomatis dari sistem pembelajaran adaptif TI SENANG.',
    14,
    currentY,
  );

  doc.save(`Asesmen_Awal_${className}_${subjectName.replace(/\s+/g, '_')}.pdf`);
}

export interface ExportAsesmenAkhirPdfParams {
  className: string;
  subjectName: string;
  teacherName: string;
  kktpTarget?: number;
  records: Array<{
    studentName: string;
    nisn?: string;
    score: number;
    kktpStatus: 'Tuntas' | 'Belum Tuntas';
    predikat: string;
    tpMasteryPercentage: number;
    catatan?: string;
  }>;
}

export function exportAsesmenAkhirToPdf(params: ExportAsesmenAkhirPdfParams): void {
  const { className, subjectName, teacherName, kktpTarget = 75, records } = params;
  const doc = new jsPDF();

  // Header Laporan
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('TI SENANG — LAPORAN ASESMEN SUMATIF AKHIR MIPA', 14, 20);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Mata Pelajaran    : ${subjectName}`, 14, 28);
  doc.text(`Kelas             : ${className}`, 14, 34);
  doc.text(`Guru Pengampu     : ${teacherName}`, 14, 40);
  doc.text(`Kriteria Ketuntasan (KKTP) : ≥ ${kktpTarget}`, 14, 46);
  doc.text(`Tanggal Cetak     : ${new Date().toLocaleDateString('id-ID')}`, 14, 52);

  // Table header
  let startY = 60;
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(14, startY, 182, 8, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text('No', 16, startY + 5.5);
  doc.text('Nama Siswa', 26, startY + 5.5);
  doc.text('Nilai Akhir', 88, startY + 5.5);
  doc.text('Ketuntasan KKTP', 112, startY + 5.5);
  doc.text('Predikat', 148, startY + 5.5);
  doc.text('Capaian TP', 170, startY + 5.5);

  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'normal');
  let currentY = startY + 8;

  records.forEach((row, idx) => {
    if (currentY > 270) {
      doc.addPage();
      currentY = 20;
    }

    if (idx % 2 === 1) {
      doc.setFillColor(248, 250, 252);
      doc.rect(14, currentY, 182, 7, 'F');
    }

    doc.text(String(idx + 1), 16, currentY + 5);
    doc.text((row.studentName || 'Murid').slice(0, 28), 26, currentY + 5);
    doc.text(String(row.score), 94, currentY + 5);

    if (row.kktpStatus === 'Tuntas') {
      doc.setTextColor(16, 185, 129); // emerald green
    } else {
      doc.setTextColor(225, 29, 72); // rose red
    }
    doc.text(row.kktpStatus, 114, currentY + 5);

    doc.setTextColor(0, 0, 0);
    doc.text((row.predikat || 'B').slice(0, 10), 148, currentY + 5);
    doc.text(`${row.tpMasteryPercentage}%`, 172, currentY + 5);

    currentY += 7;
  });

  // Footer summary
  currentY += 10;
  if (currentY > 255) {
    doc.addPage();
    currentY = 20;
  }

  const totalSiswa = records.length;
  const tuntasCount = records.filter((r) => r.kktpStatus === 'Tuntas').length;
  const avgScore = totalSiswa
    ? (records.reduce((acc, r) => acc + r.score, 0) / totalSiswa).toFixed(1)
    : '0';

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.text(`Ringkasan Capaian Kelas:`, 14, currentY);
  doc.setFont('helvetica', 'normal');
  doc.text(
    `• Rata-rata Nilai: ${avgScore}  |  • Ketuntasan Klasikal: ${tuntasCount}/${totalSiswa} Siswa (${
      totalSiswa ? Math.round((tuntasCount / totalSiswa) * 100) : 0
    }%)`,
    14,
    currentY + 6,
  );

  doc.setFont('helvetica', 'italic');
  doc.setFontSize(8);
  doc.text(
    '* Laporan Asesmen Akhir ini diverifikasi dan diunduh dari modul evaluasi adaptif TI SENANG.',
    14,
    currentY + 14,
  );

  doc.save(`Asesmen_Akhir_${className}_${subjectName.replace(/\s+/g, '_')}.pdf`);
}

export interface ExportRefleksiPdfParams {
  studentName: string;
  className: string;
  subjectName?: string;
  teacherName?: string;
  missionTitle: string;
  submittedAt: string;
  reflectionAnswers: {
    pemahaman?: string;
    tantangan?: string;
    halMenarik?: string;
    rencanaPerbaikan?: string;
    [key: string]: string | undefined;
  };
  selfAssessment: {
    kemandirian?: number;
    pemahamanKonsep?: number;
    keterampilanAnalisis?: number;
    sikapReflektif?: number;
    totalScorePercentage?: number;
    komitmen?: string;
  };
}

export function exportRefleksiToPdf(params: any): void {
  const studentName = params.studentName || 'Siswa TI SENANG';
  const className = params.className || 'Kelas Fase F';
  const subjectName = params.subjectName || 'Fisika & MIPA Terapan';
  const teacherName = params.teacherName || 'Guru Pengampu MIPA';
  const missionTitle = params.missionTitle || 'Misi 5 • Refleksi & Penilaian Diri';
  const submittedAt = params.submittedAt || new Date().toISOString();

  // Normalize reflection answers whether passed as array or object
  let reflectionAnswers: any = {};
  if (Array.isArray(params.refleksiAnswers)) {
    reflectionAnswers = {
      pemahaman: params.refleksiAnswers[0] || 'Konsep regresi linear dan Azas Black.',
      tantangan: params.refleksiAnswers[1] || 'Menganalisis kemiringan grafik regresi.',
      halMenarik: params.refleksiAnswers[2] || 'Pengambilan data sensor otomatis.',
      rencanaPerbaikan: params.refleksiAnswers[3] || 'Lebih teliti dalam mencatat satuan.',
    };
  } else if (params.reflectionAnswers) {
    reflectionAnswers = params.reflectionAnswers;
  }

  // Normalize self assessment
  const rawSelf = params.selfAssessment || {};
  const selfAssessment = {
    kemandirian: rawSelf.kemandirian || 3,
    pemahamanKonsep: rawSelf.pemahamanKonsep || 3,
    keterampilanAnalisis: rawSelf.keterampilanAnalisis || rawSelf.keterampilanData || 3,
    sikapReflektif: rawSelf.sikapReflektif || rawSelf.sikapKritis || 4,
    totalScorePercentage: params.averageSelfScore || rawSelf.totalScorePercentage || 85,
    komitmen: rawSelf.komitmen || rawSelf.komitmenDiri || '',
  };

  const doc = new jsPDF();

  // Header Laporan
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('TI SENANG — LAPORAN REFLEKSI & PENILAIAN DIRI SISWA', 14, 20);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.text(`Nama Siswa    : ${studentName}`, 14, 28);
  doc.text(`Kelas         : ${className}`, 14, 34);
  doc.text(`Mata Pelajaran: ${subjectName}`, 14, 40);
  doc.text(`Guru Pengampu : ${teacherName}`, 14, 46);
  doc.text(`Misi Terkait  : ${missionTitle}`, 14, 52);
  doc.text(
    `Waktu Kirim   : ${new Date(submittedAt || Date.now()).toLocaleString('id-ID')}`,
    14,
    58,
  );

  let currentY = 66;

  // BAGIAN 1: PENILAIAN DIRI SENDIRI (SELF-ASSESSMENT)
  doc.setFillColor(30, 41, 59); // slate-800
  doc.rect(14, currentY, 182, 7, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text('A. HASIL PENILAIAN DIRI SENDIRI (SELF-ASSESSMENT RUBRIC)', 16, currentY + 5);

  currentY += 10;
  doc.setTextColor(0, 0, 0);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);

  const selfItems = [
    { label: 'Kemandirian & Keaktifan Belajar', val: selfAssessment.kemandirian || 4 },
    { label: 'Pemahaman Konsep & Penalaran Ilmiah', val: selfAssessment.pemahamanKonsep || 4 },
    { label: 'Keterampilan Analisis Data & Eksperimen', val: selfAssessment.keterampilanAnalisis || 4 },
    { label: 'Sikap Kritis, Teliti & Bertanggung Jawab', val: selfAssessment.sikapReflektif || 4 },
  ];

  selfItems.forEach((item, idx) => {
    const starStr = '★'.repeat(item.val) + '☆'.repeat(4 - item.val);
    const scoreVal = `${item.val} / 4  (${starStr})`;
    doc.text(`${idx + 1}. ${item.label}`, 16, currentY);
    doc.setFont('helvetica', 'bold');
    doc.text(scoreVal, 150, currentY);
    doc.setFont('helvetica', 'normal');
    currentY += 6;
  });

  const totalPercent = selfAssessment.totalScorePercentage || 95;
  currentY += 2;
  doc.setFont('helvetica', 'bold');
  doc.text(`Tingkat Capaian Penilaian Diri: ${totalPercent}% (${totalPercent >= 85 ? 'Sangat Baik' : totalPercent >= 75 ? 'Baik' : 'Perlu Bimbingan'})`, 16, currentY);
  doc.setFont('helvetica', 'normal');

  if (selfAssessment.komitmen) {
    currentY += 6;
    doc.setFont('helvetica', 'italic');
    doc.text(`Komitmen Diri: "${selfAssessment.komitmen}"`, 16, currentY, { maxWidth: 178 });
    currentY += 8;
  } else {
    currentY += 6;
  }

  currentY += 4;

  // BAGIAN 2: REFLEKSI PEMBELAJARAN
  doc.setFillColor(30, 41, 59);
  doc.rect(14, currentY, 182, 7, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.text('B. HASIL REFLEKSI PEMBELAJARAN SISWA', 16, currentY + 5);

  currentY += 11;
  doc.setTextColor(0, 0, 0);

  const questionsMap = [
    {
      q: '1. Konsep sains / materi yang paling dipahami dengan baik:',
      a: reflectionAnswers.pemahaman || 'Siswa telah memahami konsep materi dan penerapannya dengan baik.',
    },
    {
      q: '2. Tantangan atau kesulitan yang dihadapi & solusinya:',
      a: reflectionAnswers.tantangan || 'Tantangan dapat diselesaikan melalui analisis mandiri dan bantuan bimbingan guru.',
    },
    {
      q: '3. Hal atau fenomena yang paling menarik dalam pembelajaran ini:',
      a: reflectionAnswers.halMenarik || 'Eksperimen sensor langsung dan simulasi grafis memudahkan visualisasi hubungan antarvariabel.',
    },
    {
      q: '4. Rencana aksi untuk meningkatkan pemahaman pada topik berikutnya:',
      a: reflectionAnswers.rencanaPerbaikan || 'Membaca modul pengayaan lebih awal dan memperbanyak latihan penalaran kontekstual.',
    },
  ];

  questionsMap.forEach((item) => {
    if (currentY > 260) {
      doc.addPage();
      currentY = 20;
    }

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text(item.q, 16, currentY);
    currentY += 5;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8.5);
    const splitText = doc.splitTextToSize(item.a, 175);
    doc.text(splitText, 18, currentY);
    currentY += splitText.length * 4.5 + 4;
  });

  // Footer & Tanda Tangan
  if (currentY > 240) {
    doc.addPage();
    currentY = 25;
  } else {
    currentY += 10;
  }

  const signY = currentY + 10;
  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text('Mengetahui / Diverifikasi oleh,', 14, signY);
  doc.text('Guru Pengampu MIPA', 14, signY + 5);
  doc.text('_________________________', 14, signY + 22);
  doc.text(teacherName, 14, signY + 27);

  doc.text('Siswa Bersangkutan,', 140, signY);
  doc.text('Kelas ' + className, 140, signY + 5);
  doc.text('_________________________', 140, signY + 22);
  doc.text(studentName, 140, signY + 27);

  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7.5);
  doc.text(
    '* Dokumen Refleksi & Penilaian Diri ini dibuat dan diunduh dari Platform Pembelajaran Adaptif TI SENANG.',
    14,
    signY + 36,
  );

  doc.save(`Refleksi_${studentName.replace(/\s+/g, '_')}_${className}.pdf`);
}
