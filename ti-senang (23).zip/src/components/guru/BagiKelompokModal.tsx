import React, { useState, useEffect } from 'react';
import { Users, Shuffle, Check, X, Sparkles, Layers } from 'lucide-react';
import { Student } from '../../types';
import { storage } from '../../services/storage';

interface BagiKelompokModalProps {
  isOpen: boolean;
  onClose: () => void;
  classNameTitle: string;
  students: Student[];
  onSaved: () => void;
}

const AVAILABLE_KELOMPOK = [
  'Kelompok 1',
  'Kelompok 2',
  'Kelompok 3',
  'Kelompok 4',
  'Kelompok 5',
];

const KELOMPOK_COLORS: Record<string, { bg: string; text: string; border: string; badge: string }> = {
  'Kelompok 1': { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200', badge: 'bg-blue-500 text-white' },
  'Kelompok 2': { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200', badge: 'bg-emerald-500 text-white' },
  'Kelompok 3': { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200', badge: 'bg-amber-500 text-white' },
  'Kelompok 4': { bg: 'bg-purple-50', text: 'text-purple-700', border: 'border-purple-200', badge: 'bg-purple-500 text-white' },
  'Kelompok 5': { bg: 'bg-rose-50', text: 'text-rose-700', border: 'border-rose-200', badge: 'bg-rose-500 text-white' },
};

export const BagiKelompokModal: React.FC<BagiKelompokModalProps> = ({
  isOpen,
  onClose,
  classNameTitle,
  students,
  onSaved,
}) => {
  // Mapping of studentId -> kelompok string
  const [groupAssignments, setGroupAssignments] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {};
    students.forEach((s) => {
      initial[s.id] = s.kelompok || '';
    });
    return initial;
  });

  const [filterGroup, setFilterGroup] = useState<string>('ALL');
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      const initial: Record<string, string> = {};
      students.forEach((s) => {
        initial[s.id] = s.kelompok || '';
      });
      setGroupAssignments(initial);
    }
  }, [isOpen, students]);

  if (!isOpen) return null;

  // Single student group assignment (toggle support)
  const handleAssignGroup = (studentId: string, kelompok: string) => {
    setGroupAssignments((prev) => ({
      ...prev,
      [studentId]: prev[studentId] === kelompok ? '' : kelompok,
    }));
  };

  // Automatic distribution (Kelompok 1 - 5)
  const handleAutoDistribute = () => {
    const updated: Record<string, string> = {};
    students.forEach((s, idx) => {
      const groupNum = (idx % 5) + 1;
      updated[s.id] = `Kelompok ${groupNum}`;
    });
    setGroupAssignments(updated);
  };

  // Reset distribution
  const handleReset = () => {
    const updated: Record<string, string> = {};
    students.forEach((s) => {
      updated[s.id] = '';
    });
    setGroupAssignments(updated);
  };

  // Save changes to database and dispatch real-time events
  const handleSave = () => {
    const list: Array<{ studentId: string; kelompok: string }> = Object.entries(groupAssignments).map(
      ([studentId, kelompok]) => ({
        studentId,
        kelompok: (kelompok as string) || 'Kelompok 1',
      })
    );

    storage.batchUpdateStudentKelompok(list);
    setSuccessMsg('Pembagian kelompok berhasil disimpan dan disinkronkan!');
    setTimeout(() => {
      setSuccessMsg(null);
      onSaved();
      onClose();
    }, 1000);
  };

  // Statistics per group
  const groupStats: Record<string, number> = {
    'Kelompok 1': 0,
    'Kelompok 2': 0,
    'Kelompok 3': 0,
    'Kelompok 4': 0,
    'Kelompok 5': 0,
    unassigned: 0,
  };

  students.forEach((s) => {
    const grp = groupAssignments[s.id];
    if (grp && groupStats[grp] !== undefined) {
      groupStats[grp]++;
    } else {
      groupStats.unassigned++;
    }
  });

  const displayedStudents = students.filter((s) => {
    if (filterGroup === 'ALL') return true;
    if (filterGroup === 'unassigned') return !groupAssignments[s.id];
    return groupAssignments[s.id] === filterGroup;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 flex flex-col max-h-[90vh] overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-4 bg-gradient-to-r from-indigo-50/70 via-purple-50/40 to-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-md shadow-indigo-200">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display font-bold text-slate-800 text-base flex items-center gap-2">
                Bagi Kelompok Siswa
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 border border-indigo-200">
                  {classNameTitle}
                </span>
              </h3>
              <p className="text-xs text-slate-500">
                Petakan siswa ke dalam Kelompok 1 - 5 untuk sinkronisasi otomatis sensor dan profil murid.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Action Toolbar & Group Summary */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 shrink-0 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleAutoDistribute}
                className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-sm flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
              >
                <Shuffle className="w-3.5 h-3.5" />
                <span>Bagi Otomatis (1-5)</span>
              </button>

              <button
                type="button"
                onClick={handleReset}
                className="px-3 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs border border-slate-200 transition-all cursor-pointer"
              >
                Reset Pilihan
              </button>
            </div>

            <div className="text-xs font-semibold text-slate-500">
              Total: <span className="font-bold text-slate-800">{students.length} Siswa</span>
              {groupStats.unassigned > 0 && (
                <span className="text-amber-600 ml-2">({groupStats.unassigned} belum terbagi)</span>
              )}
            </div>
          </div>

          {/* Group pill filters */}
          <div className="flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() => setFilterGroup('ALL')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                filterGroup === 'ALL'
                  ? 'bg-slate-800 text-white'
                  : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-200'
              }`}
            >
              Semua ({students.length})
            </button>
            {AVAILABLE_KELOMPOK.map((kel) => (
              <button
                key={kel}
                type="button"
                onClick={() => setFilterGroup(kel)}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all border ${
                  filterGroup === kel
                    ? `${KELOMPOK_COLORS[kel].badge} border-transparent shadow-xs`
                    : `${KELOMPOK_COLORS[kel].bg} ${KELOMPOK_COLORS[kel].text} ${KELOMPOK_COLORS[kel].border} hover:opacity-80`
                }`}
              >
                {kel} ({groupStats[kel] || 0})
              </button>
            ))}
          </div>
        </div>

        {/* Students list */}
        <div className="flex-1 overflow-y-auto p-4 divide-y divide-slate-100">
          {displayedStudents.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400">
              Tidak ada siswa dalam filter ini.
            </div>
          ) : (
            displayedStudents.map((std, idx) => {
              const currentGroup = groupAssignments[std.id] || '';
              return (
                <div
                  key={std.id}
                  className="py-2.5 px-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/80 rounded-xl transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 text-white flex items-center justify-center font-display font-bold text-xs shrink-0">
                      {(std.name || std.user?.fullName || 'M')[0]}
                    </div>
                    <div>
                      <div className="font-bold text-slate-800 text-xs">
                        {std.name || std.user?.fullName || 'Murid'}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {std.nisn ? `NISN: ${std.nisn}` : std.email || std.user?.username || '-'}
                      </div>
                    </div>
                  </div>

                  {/* Kelompok selector */}
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {AVAILABLE_KELOMPOK.map((kel) => {
                      const isSelected = currentGroup === kel;
                      return (
                        <button
                          key={kel}
                          type="button"
                          onClick={() => handleAssignGroup(std.id, kel)}
                          className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all border ${
                            isSelected
                              ? `${KELOMPOK_COLORS[kel].badge} border-transparent shadow-xs scale-105`
                              : `${KELOMPOK_COLORS[kel].bg} ${KELOMPOK_COLORS[kel].text} ${KELOMPOK_COLORS[kel].border} hover:scale-102`
                          }`}
                        >
                          {kel.replace('Kelompok ', 'K-')}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          {successMsg ? (
            <div className="text-xs font-bold text-emerald-700 flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>{successMsg}</span>
            </div>
          ) : (
            <span className="text-[11px] text-slate-500">
              Perubahan kelompok langsung diterapkan ke dashboard & profil murid.
            </span>
          )}

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-200 font-bold text-xs transition-colors"
            >
              Batal
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-200 transition-all flex items-center gap-1.5 cursor-pointer active:scale-95"
            >
              <Check className="w-4 h-4" />
              <span>Simpan Pembagian</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
