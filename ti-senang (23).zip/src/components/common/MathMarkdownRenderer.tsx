import React, { useMemo } from 'react';
import katex from 'katex';

interface MathMarkdownRendererProps {
  content: string;
  className?: string;
}

function sanitizeControlChars(str: string): string {
  if (!str) return '';
  return str
    .replace(/\x0c/g, '\\f') // Restore form feed to \f (e.g. \frac)
    .replace(/\x08/g, '\\b')
    .replace(/\x0b/g, '\\v');
}

/**
 * Normalizes math delimiters and formats before rendering
 * Supports:
 * - $$ ... $$ (display math)
 * - \[ ... \] (display math)
 * - standalone [\n math \n] (display math)
 * - $ ... $ (inline math)
 * - \( ... \) (inline math)
 * - (a \neq 0) parenthesized expressions containing LaTeX commands
 * - Auto-wraps standalone formulas like °F = 9/5 °C + 32 or T_F = ... into display math
 */
function normalizeMathDelimiters(text: string): string {
  if (!text) return '';

  let normalized = text.replace(/\r\n/g, '\n');
  normalized = sanitizeControlChars(normalized);

  // Convert \[ ... \] to $$ ... $$
  normalized = normalized.replace(/\\\[([\s\S]*?)\\\]/g, (_, math) => `\n$$\n${math.trim()}\n$$\n`);

  // Convert multi-line [\n math \n] to $$ ... $$ if content contains math symbols/operators
  normalized = normalized.replace(/(?:^|\n)\[\s*\n([\s\S]*?)\n\s*\](?:\n|$)/g, (match, math) => {
    if (/[\^=_+\-\\*/\\><\d|()]/.test(math)) {
      return `\n$$\n${math.trim()}\n$$\n`;
    }
    return match;
  });

  // Convert \( ... \) to $ ... $
  normalized = normalized.replace(/\\\(([\s\S]*?)\\\)/g, (_, math) => `$${math.trim()}$`);

  // Convert parenthesized LaTeX expressions like (a\neq0) into ($a\neq0$)
  normalized = normalized.replace(/\(([a-zA-Z0-9\s]*\\[a-zA-Z]+[^\)]*)\)/g, '($$$1$$)');

  // Auto-detect standalone formula lines for temperature and physics (e.g. °F = ... or T_F = ...) not inside $$
  const lines = normalized.split('\n');
  const processedLines = lines.map((line) => {
    const trimmed = line.trim();
    if (
      trimmed.startsWith('$$') ||
      trimmed.startsWith('$') ||
      trimmed.startsWith('#') ||
      trimmed.startsWith('- ') ||
      trimmed.startsWith('* ') ||
      trimmed.startsWith('> ') ||
      trimmed.startsWith('|')
    ) {
      return line;
    }
    // Check if line is a standalone formula equation (e.g. °F = ..., F = 9/5 C + 32, T_F = ...)
    if (
      /^(?:°[FCRK]|T_[\{]?[FCRK][\}]?|\^?\\?circ\\?text\{[FCRK]\}|[FCRK])\s*=\s*[\s\S]+$/i.test(trimmed) &&
      (/[\/\\+\-×*]/.test(trimmed) || /frac/i.test(trimmed))
    ) {
      const formulaTex = trimmed
        .replace(/°F/g, '^\\circ\\text{F}')
        .replace(/°C/g, '^\\circ\\text{C}')
        .replace(/°R/g, '^\\circ\\text{R}')
        .replace(/(\d+)\/(\d+)/g, '\\frac{$1}{$2}')
        .replace(/×|\*/g, '\\times ');
      return `\n$$\n${formulaTex}\n$$\n`;
    }
    return line;
  });

  normalized = processedLines.join('\n');
  return normalized;
}

function cleanLatexForKatex(tex: string): string {
  if (!tex) return '';
  let s = sanitizeControlChars(tex.trim());
  // Replace accidental ^circ without leading backslash
  s = s.replace(/\^circ(?![a-zA-Z])/g, '^{\\circ}');
  // Replace unicode degree symbols with properly formatted KaTeX
  s = s.replace(/°F/g, '{}^{\\circ}\\text{F}');
  s = s.replace(/°C/g, '{}^{\\circ}\\text{C}');
  s = s.replace(/°R/g, '{}^{\\circ}\\text{R}');
  s = s.replace(/°K/g, '\\text{ K}');
  s = s.replace(/°/g, '^{\\circ}');
  // Ensure leading ^\circ has a valid empty anchor in math mode
  s = s.replace(/^\s*\^\\circ/g, '{}^{\\circ}');
  s = s.replace(/(\s|[=+\-(×*\/])\^\\circ/g, '$1{}^{\\circ}');
  return s;
}

export const MathMarkdownRenderer: React.FC<MathMarkdownRendererProps> = ({
  content,
  className = '',
}) => {
  const renderedElements = useMemo(() => {
    if (!content) return null;

    const normalizedContent = normalizeMathDelimiters(content);
    const lines = normalizedContent.split('\n');
    const nodes: React.ReactNode[] = [];
    let i = 0;

    const renderKatexBlock = (tex: string, key: string) => {
      try {
        const cleanTex = cleanLatexForKatex(tex);
        const html = katex.renderToString(cleanTex, {
          displayMode: true,
          throwOnError: false,
          strict: false,
        });
        return (
          <div
            key={key}
            className="my-3 px-3.5 py-2.5 bg-slate-900/90 border border-slate-800 rounded-xl overflow-x-auto text-slate-100 flex justify-center items-center shadow-inner scrollbar-thin text-sm sm:text-base select-text transition-colors hover:border-slate-700"
            dangerouslySetInnerHTML={{ __html: html }}
          />
        );
      } catch {
        return (
          <div key={key} className="my-1 font-mono text-xs text-amber-400 bg-slate-900 p-2 rounded">
            {tex}
          </div>
        );
      }
    };

    const renderKatexInline = (tex: string, key: string) => {
      try {
        const cleanTex = cleanLatexForKatex(tex);

        const html = katex.renderToString(cleanTex, {
          displayMode: false,
          throwOnError: false,
          strict: false,
        });
        return (
          <span
            key={key}
            className="inline-block mx-0.5 align-middle select-text text-slate-100 font-sans"
            dangerouslySetInnerHTML={{ __html: html }}
          />
        );
      } catch {
        return (
          <span key={key} className="font-mono text-xs text-amber-400">
            {tex}
          </span>
        );
      }
    };

    const renderInline = (text: string): React.ReactNode[] => {
      const inlineParts: React.ReactNode[] = [];
      // Regex matches:
      // 1. $$...$$
      // 2. $...$
      // 3. **bold**
      // 4. *italic*
      // 5. `code`
      // 6. Degree and temperature notations: ^\circ\text{...}, °F, °C, °R
      // 7. Raw LaTeX commands like \frac{...}{...}, \sqrt{...}, \text{...}, \cdot, etc.
      const inlineRegex = /(\$\$[\s\S]*?\$\$|\$(?:\\.|[^\$\n])+\$|\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\^\\circ(?:\\text\{[^{}]*\}|[A-Za-z]+)?|°[FCRK]|\\(?:frac\{[^{}]*\}\{[^{}]*\}|sqrt\{[^{}]*\}|text\{[^{}]*\}|sum|int|times|div|pm|leq|geq|neq|approx|infty|alpha|beta|pi|Delta|theta|to|implies|iff|mathbb\{[A-Z]\}|cdot|degree|circ))/g;

      let lastIndex = 0;
      let match: RegExpExecArray | null;

      while ((match = inlineRegex.exec(text)) !== null) {
        if (match.index > lastIndex) {
          inlineParts.push(text.slice(lastIndex, match.index));
        }

        const matchedStr = match[0];

        if (matchedStr.startsWith('$$') && matchedStr.endsWith('$$')) {
          const tex = matchedStr.slice(2, -2).trim();
          inlineParts.push(renderKatexBlock(tex, `disp-${match.index}`));
        } else if (matchedStr.startsWith('$') && matchedStr.endsWith('$')) {
          const tex = matchedStr.slice(1, -1).trim();
          inlineParts.push(renderKatexInline(tex, `inl-${match.index}`));
        } else if (matchedStr.startsWith('\\') || matchedStr.startsWith('^') || matchedStr.startsWith('°')) {
          // Standalone LaTeX symbol/command or degree notation
          inlineParts.push(renderKatexInline(matchedStr, `cmd-${match.index}`));
        } else if (matchedStr.startsWith('**') && matchedStr.endsWith('**')) {
          inlineParts.push(
            <strong key={`bold-${match.index}`} className="font-bold text-white">
              {renderInline(matchedStr.slice(2, -2))}
            </strong>
          );
        } else if (matchedStr.startsWith('*') && matchedStr.endsWith('*')) {
          inlineParts.push(
            <em key={`em-${match.index}`} className="italic text-slate-200">
              {renderInline(matchedStr.slice(1, -1))}
            </em>
          );
        } else if (matchedStr.startsWith('`') && matchedStr.endsWith('`')) {
          inlineParts.push(
            <code
              key={`code-${match.index}`}
              className="px-1.5 py-0.5 rounded bg-slate-800 text-amber-300 font-mono text-xs border border-slate-700"
            >
              {matchedStr.slice(1, -1)}
            </code>
          );
        }

        lastIndex = match.index + matchedStr.length;
      }

      if (lastIndex < text.length) {
        inlineParts.push(text.slice(lastIndex));
      }

      return inlineParts;
    };

    while (i < lines.length) {
      const line = lines[i];

      // Multi-line block math $$ ... $$
      if (line.trim().startsWith('$$')) {
        let blockTex = line.trim().slice(2);
        if (blockTex.endsWith('$$') && blockTex.length > 0) {
          blockTex = blockTex.slice(0, -2);
          nodes.push(renderKatexBlock(blockTex, `block-math-${i}`));
          i++;
          continue;
        } else {
          // Find closing $$
          let j = i + 1;
          const texLines = [blockTex];
          let foundClose = false;
          while (j < lines.length) {
            if (lines[j].trim().endsWith('$$')) {
              texLines.push(lines[j].trim().slice(0, -2));
              foundClose = true;
              break;
            } else {
              texLines.push(lines[j]);
            }
            j++;
          }
          if (foundClose) {
            nodes.push(renderKatexBlock(texLines.join('\n'), `block-math-${i}`));
            i = j + 1;
            continue;
          }
        }
      }

      // Headings
      if (line.startsWith('# ')) {
        nodes.push(
          <h1 key={`h1-${i}`} className="text-base sm:text-lg font-bold text-white mt-3 mb-1.5 flex items-center gap-1.5">
            {renderInline(line.slice(2))}
          </h1>
        );
        i++;
        continue;
      }
      if (line.startsWith('## ')) {
        nodes.push(
          <h2 key={`h2-${i}`} className="text-sm sm:text-base font-bold text-indigo-300 mt-2.5 mb-1 flex items-center gap-1.5">
            {renderInline(line.slice(3))}
          </h2>
        );
        i++;
        continue;
      }
      if (line.startsWith('### ')) {
        nodes.push(
          <h3 key={`h3-${i}`} className="text-xs sm:text-sm font-semibold text-emerald-300 mt-2 mb-1">
            {renderInline(line.slice(4))}
          </h3>
        );
        i++;
        continue;
      }

      // Blockquote >
      if (line.startsWith('> ')) {
        const quoteLines: string[] = [];
        let j = i;
        while (j < lines.length && lines[j].startsWith('> ')) {
          quoteLines.push(lines[j].slice(2));
          j++;
        }
        nodes.push(
          <blockquote
            key={`quote-${i}`}
            className="my-2 pl-3 border-l-2 border-indigo-500 bg-indigo-950/20 py-1.5 pr-2 rounded-r text-indigo-200 text-xs sm:text-sm italic"
          >
            {quoteLines.map((ql, idx) => (
              <p key={idx}>{renderInline(ql)}</p>
            ))}
          </blockquote>
        );
        i = j;
        continue;
      }

      // Markdown Table
      if (line.trim().startsWith('|') && line.trim().endsWith('|')) {
        const tableLines: string[] = [];
        let j = i;
        while (j < lines.length && lines[j].trim().startsWith('|') && lines[j].trim().endsWith('|')) {
          tableLines.push(lines[j].trim());
          j++;
        }
        if (tableLines.length >= 2) {
          const headerCells = tableLines[0]
            .split('|')
            .slice(1, -1)
            .map((c) => c.trim());
          const hasSeparator = /^[:\s\-|]+$/.test(tableLines[1]);
          const rowLines = hasSeparator ? tableLines.slice(2) : tableLines.slice(1);

          nodes.push(
            <div key={`table-${i}`} className="my-3 overflow-x-auto rounded-xl border border-slate-800 bg-slate-900/60 shadow-inner">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-800/60 text-indigo-200 font-semibold">
                    {headerCells.map((hc, idx) => (
                      <th key={idx} className="p-2.5 whitespace-nowrap">
                        {renderInline(hc)}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {rowLines.map((rl, rIdx) => {
                    const cells = rl
                      .split('|')
                      .slice(1, -1)
                      .map((c) => c.trim());
                    return (
                      <tr key={rIdx} className="hover:bg-slate-800/30 transition-colors">
                        {cells.map((cell, cIdx) => (
                          <td key={cIdx} className="p-2.5 text-slate-300">
                            {renderInline(cell)}
                          </td>
                        ))}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          );
          i = j;
          continue;
        }
      }

      // Bullet lists
      if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
        const listItems: string[] = [];
        let j = i;
        while (j < lines.length && (lines[j].trim().startsWith('- ') || lines[j].trim().startsWith('* '))) {
          listItems.push(lines[j].trim().slice(2));
          j++;
        }
        nodes.push(
          <ul key={`ul-${i}`} className="my-1.5 space-y-1 pl-4 list-disc marker:text-indigo-400 text-xs sm:text-sm">
            {listItems.map((item, idx) => (
              <li key={idx} className="leading-relaxed text-slate-200">
                {renderInline(item)}
              </li>
            ))}
          </ul>
        );
        i = j;
        continue;
      }

      // Ordered list 1. 2.
      if (/^\s*\d+\.\s/.test(line)) {
        const listItems: string[] = [];
        let j = i;
        while (j < lines.length && /^\s*\d+\.\s/.test(lines[j])) {
          listItems.push(lines[j].replace(/^\s*\d+\.\s/, ''));
          j++;
        }
        nodes.push(
          <ol key={`ol-${i}`} className="my-1.5 space-y-1 pl-4 list-decimal marker:text-emerald-400 text-xs sm:text-sm">
            {listItems.map((item, idx) => (
              <li key={idx} className="leading-relaxed text-slate-200">
                {renderInline(item)}
              </li>
            ))}
          </ol>
        );
        i = j;
        continue;
      }

      // Empty line
      if (!line.trim()) {
        nodes.push(<div key={`spacer-${i}`} className="h-1.5" />);
        i++;
        continue;
      }

      // Normal paragraph
      nodes.push(
        <p key={`p-${i}`} className="my-1 leading-relaxed text-slate-200 text-xs sm:text-sm">
          {renderInline(line)}
        </p>
      );
      i++;
    }

    return nodes;
  }, [content]);

  return <div className={`math-markdown-content space-y-0.5 ${className}`}>{renderedElements}</div>;
};

