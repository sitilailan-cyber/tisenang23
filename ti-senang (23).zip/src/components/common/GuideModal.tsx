import React, { useState } from 'react';
import { Modal } from './Modal';
import {
  Compass,
  Sparkles,
  CheckCircle2,
  Cpu,
  Layers,
  FlaskConical,
  GraduationCap,
  BookOpen,
  Settings,
  Database,
  FileSpreadsheet,
  Share2,
  HelpCircle,
  ShieldCheck,
  Zap,
  Lightbulb,
} from 'lucide-react';

interface GuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GuideModal: React.FC<GuideModalProps> = ({ isOpen, onClose }) => {
  const [activeCategory, setActiveCategory] = useState<
    'semua' | 'misi' | 'guru' | 'lab' | 'admin'
  >('semua');

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Petunjuk Penggunaan Media Pembelajaran TI SENANG"
      subtitle="Panduan lengkap mengoptimalkan sistem pembelajaran adaptif, eksperimen IoT, dan Kurikulum Merdeka Fase F"
      maxWidth="2xl"
    >
      <div className="space-y-4 text-slate-700 text-xs sm:text-sm max-h-[74vh] overflow-y-auto pr-1">
        {/* Category Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 border-b border-slate-200">
          <button
            type="button"
            onClick={() => setActiveCategory('semua')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              activeCategory === 'semua'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Semua Panduan
          </button>
          <button
            type="button"
            onClick={() => setActiveCategory('misi')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeCategory === 'misi'
                ? 'bg-indigo-600 text-white shadow-2xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Murid & 6 Misi</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveCategory('guru')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeCategory === 'guru'
                ? 'bg-emerald-600 text-white shadow-2xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Guru & Asesmen</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveCategory('lab')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeCategory === 'lab'
                ? 'bg-cyan-700 text-white shadow-2xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Eksperimen IoT & Simulasi</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveCategory('admin')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
              activeCategory === 'admin'
                ? 'bg-amber-600 text-white shadow-2xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Admin & Database</span>
          </button>
        </div>

        {/* Section 1: Alur Masuk & Peran */}
        {(activeCategory === 'semua' || activeCategory === 'misi' || activeCategory === 'guru') && (
          <div className="p-4 rounded-2xl bg-blue-50/80 border border-blue-200/80 space-y-2">
            <h4 className="font-bold text-blue-950 text-sm sm:text-base flex items-center gap-2">
              <Compass className="w-4 h-4 text-blue-600" />
              <span>1. Alur Masuk & Pemilihan Peran</span>
            </h4>
            <p className="text-slate-600 leading-relaxed text-xs sm:text-sm">
              Klik tombol <strong>MULAI</strong> pada halaman utama untuk memilih peran Anda:
            </p>
            <ul className="list-disc list-inside space-y-1 text-slate-700 text-xs sm:text-sm pl-1">
              <li>
                <strong>👨‍🎓 Akun Murid:</strong> Mengakses alur 6 Misi Pembelajaran Kurikulum Merdeka, Misi Sisipan adaptif ALME, Eksperimen Kit Sensor IoT (5 port) & Simulasi Virtual, konsultasi dengan Teman Berpikir AI, serta mengunggah karya ke Galeri Portofolio Kelas.
              </li>
              <li>
                <strong>👩‍🏫 Akun Guru:</strong> Merancang Tujuan Pembelajaran (TP) & alokasi JP, mengunggah Excel Asesmen Awal (1:1), mengaktifkan rekomendasi adaptif ALME, merilis konten materi 6 Misi, mengevaluasi tugas & portofolio murid, serta melihat rekap nilai. Suara asisten AI akan otomatis menyesuaikan sapaan <em>Bapak</em> atau <em>Ibu</em> sesuai profil guru.
              </li>
              <li>
                <strong>⚙️ Administrator:</strong> Tombol <strong>ADMIN</strong> di navbar atas untuk mengelola data master guru, murid, dan kelas, dengan seluruh data tersimpan otomatis di database Firebase Realtime.
              </li>
            </ul>
          </div>
        )}

        {/* Section 2: Peta 6 Misi Belajar Kurikulum Merdeka */}
        {(activeCategory === 'semua' || activeCategory === 'misi') && (
          <div className="p-4 rounded-2xl bg-indigo-50/80 border border-indigo-200/80 space-y-2.5">
            <h4 className="font-bold text-indigo-950 text-sm sm:text-base flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-600" />
              <span>2. Peta 6 Misi Belajar Kurikulum Merdeka (MIPA Fase F)</span>
            </h4>
            <p className="text-slate-600 text-xs sm:text-sm">
              Alur belajar siswa dirancang bertahap, bermakna, dan menyenangkan:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
              <div className="p-3 rounded-xl bg-white border border-indigo-100 shadow-2xs space-y-1">
                <span className="font-bold text-indigo-900 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center text-[10px] font-black">1</span>
                  Misi 1: Pahami Konsep
                </span>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Menyimak rujukan materi guru melalui 2–3 tautan pembelajaran (video YouTube, dokumen Google Drive, atau web interaktif) serta fitur rangkuman konsep mandiri bersama AI.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-white border border-indigo-100 shadow-2xs space-y-1">
                <span className="font-bold text-rose-900 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center text-[10px] font-black">2</span>
                  Misi 2: Selesaikan Masalah Nyata
                </span>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Menganalisis studi kasus kontekstual sains kehidupan nyata, merumuskan hipotesis, dan menyusun solusi penalaran saintifik berbasis fakta.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-white border border-indigo-100 shadow-2xs space-y-1">
                <span className="font-bold text-cyan-900 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-cyan-100 text-cyan-700 flex items-center justify-center text-[10px] font-black">3</span>
                  Misi 3: Eksperimen & Simulasi
                </span>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Praktikum sains langsung dengan Kit Sensor IoT TI SENANG (5 port terhubung Firebase) atau Simulasi Virtual interaktif (Kalorimeter, Rangkaian Listrik, Regresi Linear).
                </p>
              </div>

              <div className="p-3 rounded-xl bg-white border border-indigo-100 shadow-2xs space-y-1">
                <span className="font-bold text-emerald-900 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center text-[10px] font-black">4</span>
                  Misi 4: Game Edukasi Sains
                </span>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Bermain game edukatif pilihan guru untuk memperkuat pemahaman konsep dengan cara yang menyenangkan dan interaktif.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-white border border-indigo-100 shadow-2xs space-y-1">
                <span className="font-bold text-amber-900 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center text-[10px] font-black">5</span>
                  Misi 5: Refleksi dan Penilaian Diri
                </span>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Melakukan refleksi pengalaman belajar metakognitif mandiri serta mengisi lembar penilaian diri atas penguasaan materi dan sikap belajar.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-white border border-indigo-100 shadow-2xs space-y-1">
                <span className="font-bold text-purple-900 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center text-[10px] font-black">6</span>
                  Misi 6: Asesmen Akhir
                </span>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Mengerjakan evaluasi sumatif akhir pembelajaran untuk menguji pencapaian kompetensi materi yang telah dipelajari secara objektif.
                </p>
              </div>
            </div>

            {/* Sisipan ALME Highlight */}
            <div className="p-3 rounded-xl bg-amber-100/70 border border-amber-300 text-amber-950 space-y-1">
              <span className="font-bold text-xs flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-amber-700" />
                Sisipan Pembelajaran Adaptif ALME
              </span>
              <p className="text-[11px] text-amber-900 leading-relaxed">
                Berdasarkan hasil Asesmen Awal, mesin adaptif ALME akan menyajikan misi sisipan yang dipersonalisasi untuk setiap murid, berupa <strong>Remedial</strong>, <strong>Pengayaan</strong>, <strong>Soal Literasi</strong>, <strong>Soal Numerasi</strong>, atau <strong>Latihan Soal</strong>.
              </p>
            </div>
          </div>
        )}

        {/* Section 3: Eksperimen Kit Sensor IoT (5 Port) */}
        {(activeCategory === 'semua' || activeCategory === 'lab') && (
          <div className="p-4 rounded-2xl bg-cyan-50/80 border border-cyan-200/80 space-y-2">
            <h4 className="font-bold text-cyan-950 text-sm sm:text-base flex items-center gap-2">
              <Cpu className="w-4 h-4 text-cyan-600" />
              <span>3. Eksperimen Sains IoT (Kit TI SENANG - 5 Port Sensor)</span>
            </h4>
            <p className="text-slate-600 leading-relaxed text-xs sm:text-sm">
              Kit perangkat keras praktikum sains yang terhubung langsung ke Firebase Realtime Database:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
              <div className="p-2.5 rounded-xl bg-white border border-cyan-100 shadow-2xs">
                <strong>Port 1:</strong> Suhu Air / Kalorimeter (DS18B20)
              </div>
              <div className="p-2.5 rounded-xl bg-white border border-cyan-100 shadow-2xs">
                <strong>Port 2:</strong> Intensitas Cahaya (BH1750)
              </div>
              <div className="p-2.5 rounded-xl bg-white border border-cyan-100 shadow-2xs">
                <strong>Port 3:</strong> Suhu & Kelembaban Udara (DHT22)
              </div>
              <div className="p-2.5 rounded-xl bg-white border border-cyan-100 shadow-2xs">
                <strong>Port 4:</strong> Arus Listrik & Tegangan (INA219)
              </div>
              <div className="p-2.5 rounded-xl bg-white border border-cyan-100 shadow-2xs sm:col-span-2">
                <strong>Port 5:</strong> Deteksi Gerak & Jarak (PIR / Ultrasonik)
              </div>
            </div>
            <ul className="list-disc list-inside space-y-1 text-slate-700 text-xs sm:text-sm pt-1 pl-1">
              <li><strong>Tombol "Ambil Data":</strong> Mencatat seketika nilai pembacaan sensor saat itu ke tabel pengamatan praktikum.</li>
              <li><strong>Tombol "Data Kelompok":</strong> Menarik dan menyelaraskan data percobaan kelompok kelas dari cloud Firebase.</li>
              <li><strong>Tombol "Selesai Eksperimen & Buka Misi 4":</strong> Menyimpan capaian Misi 3 dan langsung membuka akses Misi 4 bagi murid.</li>
            </ul>
          </div>
        )}

        {/* Section 4: Simulasi Virtual */}
        {(activeCategory === 'semua' || activeCategory === 'lab') && (
          <div className="p-4 rounded-2xl bg-violet-50/80 border border-violet-200/80 space-y-2">
            <h4 className="font-bold text-violet-950 text-sm sm:text-base flex items-center gap-2">
              <FlaskConical className="w-4 h-4 text-violet-600" />
              <span>4. Simulasi Virtual Interaktif</span>
            </h4>
            <p className="text-slate-600 leading-relaxed text-xs sm:text-sm">
              Laboratorium maya yang dapat diakses kapan saja:
            </p>
            <ul className="list-disc list-inside space-y-1 text-slate-700 text-xs sm:text-sm pl-1">
              <li><strong>Simulasi Guru:</strong> Membuka media interaktif pilihan guru (PhET, GeoGebra, atau lab virtual eksternal).</li>
              <li><strong>Simulasi Kalorimeter:</strong> Mensimulasikan perpindahan kalor, massa air, dan kapasitas kalor jenis logam.</li>
              <li><strong>Simulasi Rangkaian Listrik:</strong> Merakit komponen sakelar, baterai, resistor, serta mengukur tegangan dan arus listrik.</li>
              <li><strong>Simulasi Regresi Linear Sains:</strong> Mengolah titik data observasi, grafik garis tren, korelasi Pearson $r$, dan koefisien determinasi $R^2$.</li>
            </ul>
          </div>
        )}

        {/* Section 5: Teman Berpikir AI */}
        {(activeCategory === 'semua' || activeCategory === 'misi') && (
          <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200/80 space-y-2">
            <h4 className="font-bold text-amber-950 text-sm sm:text-base flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-600" />
              <span>5. Teman Berpikir AI (Bimbingan Sokratik Bernalar)</span>
            </h4>
            <p className="text-slate-700 leading-relaxed text-xs sm:text-sm">
              Gunakan tombol melayang <strong>Teman Berpikir AI</strong> di pojok kanan bawah. AI mendampingi cara berpikir siswa secara sokratik melalui pertanyaan pemantik bertahap dan analogi konsep, bukan sekadar memberikan jawaban langsung secara instan.
            </p>
          </div>
        )}

        {/* Section 6: Panduan Khusus Guru */}
        {(activeCategory === 'semua' || activeCategory === 'guru') && (
          <div className="p-4 rounded-2xl bg-emerald-50/80 border border-emerald-200/80 space-y-2.5">
            <h4 className="font-bold text-emerald-950 text-sm sm:text-base flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-emerald-600" />
              <span>6. Panduan Dashboard Guru</span>
            </h4>
            <div className="space-y-2 text-xs sm:text-sm text-slate-700">
              <div className="p-3 rounded-xl bg-white border border-emerald-200/80 space-y-1 shadow-2xs">
                <strong className="text-emerald-900 block font-bold">A. Asesmen Awal & Rekomendasi ALME:</strong>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Guru dapat mengunggah file Excel nilai asesmen awal dengan hasil tampilan yang persis 1:1 sesuai isi Excel. Tersedia tombol <strong>Hapus Semua Data</strong> jika ingin mengatur ulang data asesmen awal kelas. Hasil asesmen ini otomatis memetakan rekomendasi intervensi ALME bagi murid.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-white border border-emerald-200/80 space-y-1 shadow-2xs">
                <strong className="text-emerald-900 block font-bold">B. Tujuan Pembelajaran (TP) & Alokasi JP:</strong>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Menentukan dan mengorganisasi TP serta alokasi jam pelajaran (JP) sesuai fase kurikulum.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-white border border-emerald-200/80 space-y-1 shadow-2xs">
                <strong className="text-emerald-900 block font-bold">C. Manajemen Misi Belajar:</strong>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Menyusun konten materi Misi 1 (hingga 2–3 link tautan rujukan), Misi 2, Misi 3, Misi 4, Misi 5 (Refleksi dan Penilaian Diri), serta Misi 6 (Asesmen Akhir).
                </p>
              </div>

              <div className="p-3 rounded-xl bg-white border border-emerald-200/80 space-y-1 shadow-2xs">
                <strong className="text-emerald-900 block font-bold">D. Rekap Nilai, Tugas Murid & Profil:</strong>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Mengevaluasi laporan tugas praktikum murid, merekap nilai asesmen akhir, serta mengatur profil guru dengan sapaan AI otomatis (Bapak/Ibu).
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Section 7: Panduan Administrator */}
        {(activeCategory === 'semua' || activeCategory === 'admin') && (
          <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200/80 space-y-2">
            <h4 className="font-bold text-amber-950 text-sm sm:text-base flex items-center gap-2">
              <Settings className="w-4 h-4 text-amber-600" />
              <span>7. Panduan Administrator (Admin Center)</span>
            </h4>
            <p className="text-slate-600 leading-relaxed text-xs sm:text-sm">
              Administrator dapat mengelola data master institusi melalui tombol <strong>ADMIN</strong>:
            </p>
            <ul className="list-disc list-inside space-y-1 text-slate-700 text-xs sm:text-sm pl-1">
              <li><strong>Kelola Guru:</strong> Menambah guru baru, mengubah username/password, dan memilih <em>Jenis Kelamin (Laki-laki / Perempuan)</em> agar suara AI memanggil dengan sapaan Bapak atau Ibu secara akurat.</li>
              <li><strong>Kelola Murid:</strong> Menambah akun murid secara manual atau <strong>Impor Massal Excel</strong> secara instan dengan format resmi yang telah disediakan.</li>
              <li><strong>Kelola Kelas:</strong> Menambah rombel/kelas baru, mengubah nama kelas, atau menghapus kelas yang sudah tidak digunakan.</li>
              <li><strong>Penyimpanan Database Cloud:</strong> Semua data yang dimasukkan admin langsung tersimpan dan tersinkronisasi aman ke <strong>Firebase Realtime Database</strong>.</li>
            </ul>
          </div>
        )}

        {/* Section 8: Petunjuk Pengunggahan Portofolio & Google Drive */}
        {(activeCategory === 'semua' || activeCategory === 'misi' || activeCategory === 'guru') && (
          <div className="p-4 rounded-2xl bg-slate-100/90 border border-slate-200 space-y-2">
            <h4 className="font-bold text-slate-900 text-sm sm:text-base flex items-center gap-2">
              <Share2 className="w-4 h-4 text-blue-600" />
              <span>8. Petunjuk Tautan Google Drive untuk Portofolio</span>
            </h4>
            <p className="text-slate-600 leading-relaxed text-xs sm:text-sm">
              Saat murid atau guru melampirkan tautan Google Drive pada tugas, materi, atau portofolio:
            </p>
            <ol className="list-decimal list-inside space-y-1 text-slate-700 text-xs sm:text-sm pl-1">
              <li>Buka file atau foto di Google Drive Anda.</li>
              <li>Klik tombol <strong>Bagikan (Share)</strong>.</li>
              <li>Ubah akses umum menjadi <strong>"Siapa saja yang memiliki link" (Anyone with the link can view)</strong>.</li>
              <li>Klik <strong>Salin Link (Copy link)</strong> dan tempelkan ke kolom isian di TI SENANG.</li>
            </ol>
          </div>
        )}
      </div>
    </Modal>
  );
};
