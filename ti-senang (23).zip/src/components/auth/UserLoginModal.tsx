import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Modal } from '../common/Modal';
import {
  BookOpen,
  GraduationCap,
  Lock,
  AlertCircle,
  Eye,
  EyeOff,
  Sparkles,
  CheckCircle2,
  ArrowRight,
  Compass,
  FileSpreadsheet,
  Target,
  Brain,
  Award,
} from 'lucide-react';
import { storage } from '../../services/storage';
import { playPersonalAudioGreeting } from '../../services/audioGreeting';

interface UserLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultRole?: 'guru' | 'murid';
  onSuccess: () => void;
}

export const UserLoginModal: React.FC<UserLoginModalProps> = ({
  isOpen,
  onClose,
  defaultRole = 'murid',
  onSuccess,
}) => {
  const { login } = useAuth();
  const [role, setRole] = useState<'guru' | 'murid'>(defaultRole);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPostLoginGuide, setShowPostLoginGuide] = useState(false);
  const [loggedInName, setLoggedInName] = useState('');

  useEffect(() => {
    if (defaultRole) {
      setRole(defaultRole);
      setUsername('');
      setPassword('');
      setShowPassword(false);
      setError(null);
      setShowPostLoginGuide(false);
    }
  }, [defaultRole, isOpen]);

  const handleRoleChange = (newRole: 'guru' | 'murid') => {
    setRole(newRole);
    setError(null);
    setUsername('');
    setPassword('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    try {
      const res = login(username, password, role);
      if (res.success) {
        const user = storage.getUsers().find((u) => u.username === username);
        if (user) {
          playPersonalAudioGreeting(user);
          setLoggedInName(user.fullName || user.name || user.username);
        } else {
          setLoggedInName(username);
        }
        setShowPostLoginGuide(true);
      } else {
        setError(res.error || 'Login gagal.');
      }
    } catch {
      setError('Terjadi kesalahan saat masuk.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDismissGuide = () => {
    setShowPostLoginGuide(false);
    onSuccess();
    onClose();
  };

  const isMurid = role === 'murid';

  if (showPostLoginGuide) {
    return (
      <Modal
        isOpen={isOpen}
        onClose={handleDismissGuide}
        maxWidth="5xl"
        title={`Petunjuk ${isMurid ? 'Langkah Belajar Murid' : 'Awal Mengajar Guru'}`}
        subtitle={`Selamat datang, ${loggedInName}! Berikut panduan ringkas alur kerja Anda:`}
      >
        <div className="space-y-3.5 text-slate-800 text-xs sm:text-sm">
          {isMurid ? (
            <div className="space-y-2.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                {/* Step 1 */}
                <div className="p-2.5 rounded-xl bg-blue-50/90 border border-blue-200/90 flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-lg bg-blue-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                    1
                  </div>
                  <div className="text-xs">
                    <p className="font-bold text-blue-950">Pilih Mapel & Semester</p>
                    <p className="text-[11px] text-slate-600 leading-snug">
                      Pastikan Mapel MIPA & Semester aktif telah sesuai di menu atas.
                    </p>
                  </div>
                </div>

                {/* Step 2 */}
                <div className="p-2.5 rounded-xl bg-indigo-50/90 border border-indigo-200/90 flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-lg bg-indigo-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                    2
                  </div>
                  <div className="text-xs">
                    <p className="font-bold text-indigo-950">Misi 1: Pahami Konsep</p>
                    <p className="text-[11px] text-slate-600 leading-snug">
                      Pelajari modul/video, catat poin, & kuis AI untuk membuka Misi 2.
                    </p>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="p-2.5 rounded-xl bg-purple-50/90 border border-purple-200/90 flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-lg bg-purple-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                    3
                  </div>
                  <div className="text-xs">
                    <p className="font-bold text-purple-950">Misi 2: Studi Masalah Nyata</p>
                    <p className="text-[11px] text-slate-600 leading-snug">
                      Kaji studi kasus kontekstual & simpan karya ke portofolio Drive.
                    </p>
                  </div>
                </div>

                {/* Step 4 */}
                <div className="p-2.5 rounded-xl bg-cyan-50/90 border border-cyan-200/90 flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-lg bg-cyan-700 text-white font-bold text-xs flex items-center justify-center shrink-0">
                    4
                  </div>
                  <div className="text-xs">
                    <p className="font-bold text-cyan-950">Misi 3: Eksperimen / Simulasi</p>
                    <p className="text-[11px] text-slate-600 leading-snug">
                      Uji sensor Kit IoT atau virtual lab, lalu klik "Selesai Eksperimen".
                    </p>
                  </div>
                </div>

                {/* Step 5 */}
                <div className="p-2.5 rounded-xl bg-amber-50/90 border border-amber-200/90 flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-lg bg-amber-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                    5
                  </div>
                  <div className="text-xs">
                    <p className="font-bold text-amber-950">Misi 4: Game Edukasi</p>
                    <p className="text-[11px] text-slate-600 leading-snug">
                      Asah pemahaman konsep lewat tantangan mini game interaktif sains.
                    </p>
                  </div>
                </div>

                {/* Step 6 */}
                <div className="p-2.5 rounded-xl bg-emerald-50/90 border border-emerald-200/90 flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                    6
                  </div>
                  <div className="text-xs">
                    <p className="font-bold text-emerald-950">Misi 5 & 6: Refleksi & Asesmen</p>
                    <p className="text-[11px] text-slate-600 leading-snug">
                      Isi penilaian diri lalu selesaikan asesmen sumatif akhir kompetensi.
                    </p>
                  </div>
                </div>
              </div>

              {/* Companion note */}
              <div className="p-2 rounded-xl bg-slate-50 border border-slate-200 flex items-center gap-2 text-[11px] text-slate-700">
                <Sparkles className="w-4 h-4 text-amber-500 shrink-0" />
                <span>
                  <strong>Teman Berpikir AI:</strong> Manfaatkan tombol AI di sudut bawah kapan saja Anda butuh bimbingan atau penjelasan rumus!
                </span>
              </div>
            </div>
          ) : (
            <div className="space-y-2.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                {/* Guru Step 1 */}
                <div className="p-2.5 rounded-xl bg-indigo-50/90 border border-indigo-200/90 flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-lg bg-indigo-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                    1
                  </div>
                  <div className="text-xs">
                    <p className="font-bold text-indigo-950">Pilih Mapel & Rombel</p>
                    <p className="text-[11px] text-slate-600 leading-snug">
                      Tentukan rombel kelas binaan dan semester aktif pada menu atas.
                    </p>
                  </div>
                </div>

                {/* Guru Step 2 */}
                <div className="p-2.5 rounded-xl bg-blue-50/90 border border-blue-200/90 flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-lg bg-blue-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                    2
                  </div>
                  <div className="text-xs">
                    <p className="font-bold text-blue-950">Atur Tujuan Pembelajaran</p>
                    <p className="text-[11px] text-slate-600 leading-snug">
                      Kelola daftar TP, alokasi JP, dan kriteria ketercapaian (KKTP).
                    </p>
                  </div>
                </div>

                {/* Guru Step 3 */}
                <div className="p-2.5 rounded-xl bg-purple-50/90 border border-purple-200/90 flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-lg bg-purple-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                    3
                  </div>
                  <div className="text-xs">
                    <p className="font-bold text-purple-950">Asesmen Awal (Diagnostik)</p>
                    <p className="text-[11px] text-slate-600 leading-snug">
                      Input nilai asesmen awal untuk mengaktifkan personalisasi adaptif ALME.
                    </p>
                  </div>
                </div>

                {/* Guru Step 4 */}
                <div className="p-2.5 rounded-xl bg-cyan-50/90 border border-cyan-200/90 flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-lg bg-cyan-700 text-white font-bold text-xs flex items-center justify-center shrink-0">
                    4
                  </div>
                  <div className="text-xs">
                    <p className="font-bold text-cyan-950">Kelola 6 Misi Belajar</p>
                    <p className="text-[11px] text-slate-600 leading-snug">
                      Rilis materi Misi 1, kasus Misi 2, simulasi Misi 3, game, hingga asesmen.
                    </p>
                  </div>
                </div>

                {/* Guru Step 5 */}
                <div className="p-2.5 rounded-xl bg-emerald-50/90 border border-emerald-200/90 flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                    5
                  </div>
                  <div className="text-xs">
                    <p className="font-bold text-emerald-950">Tinjau Portofolio</p>
                    <p className="text-[11px] text-slate-600 leading-snug">
                      Periksa karya dan laporan siswa serta berikan nilai dan umpan balik.
                    </p>
                  </div>
                </div>

                {/* Guru Step 6 */}
                <div className="p-2.5 rounded-xl bg-amber-50/90 border border-amber-200/90 flex items-start gap-2.5">
                  <div className="w-6 h-6 rounded-lg bg-amber-600 text-white font-bold text-xs flex items-center justify-center shrink-0">
                    6
                  </div>
                  <div className="text-xs">
                    <p className="font-bold text-amber-950">Pantau Rapor & Unduh Rekap</p>
                    <p className="text-[11px] text-slate-600 leading-snug">
                      Lihat visualisasi ALME siswa dan unduh rekap nilai rapor PDF/Excel.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="pt-2 flex items-center justify-end">
            <button
              id="btn-confirm-login-guide"
              type="button"
              onClick={handleDismissGuide}
              className={`w-full sm:w-auto px-6 py-2 rounded-xl font-bold text-xs sm:text-sm text-white shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 ${
                isMurid
                  ? 'bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700'
                  : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700'
              }`}
            >
              <span>{isMurid ? 'Saya Mengerti, Mulai Belajar' : 'Saya Mengerti, Masuk Ruang Guru'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </Modal>
    );
  }

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      maxWidth="sm"
    >
      {/* Role Tabs */}
      <div className="flex rounded-xl bg-white/50 backdrop-blur-xs p-1 mb-5 border border-white/60 shadow-xs">
        <button
          type="button"
          onClick={() => handleRoleChange('murid')}
          className={`flex-1 py-2.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            isMurid
              ? 'bg-white text-pink-600 shadow-xs'
              : 'text-slate-800 hover:text-slate-950 font-semibold'
          }`}
        >
          <GraduationCap className="w-4 h-4" />
          <span>Murid</span>
        </button>
        <button
          type="button"
          onClick={() => handleRoleChange('guru')}
          className={`flex-1 py-2.5 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            !isMurid
              ? 'bg-white text-blue-700 shadow-xs'
              : 'text-slate-800 hover:text-slate-950 font-semibold'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Guru</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <div>
          <label className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-1.5">
            Username
          </label>
          <input
            id="user-username-input"
            type="text"
            required
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder={isMurid ? 'contoh: aisyah' : 'contoh: budi'}
            className="w-full h-11 px-3.5 rounded-xl border border-white/80 focus:border-blue-600 focus:ring-2 focus:ring-blue-300 text-sm font-medium outline-hidden transition-all bg-white/95 text-slate-900 shadow-xs"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-1.5">
            Password
          </label>
          <div className="relative">
            <input
              id="user-password-input"
              type={showPassword ? 'text' : 'password'}
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Masukkan password"
              className="w-full h-11 pl-3.5 pr-11 rounded-xl border border-white/80 focus:border-blue-600 focus:ring-2 focus:ring-blue-300 text-sm font-medium outline-hidden transition-all bg-white/95 text-slate-900 shadow-xs"
            />
            <button
              type="button"
              id="btn-toggle-user-password"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-2.5 top-2.5 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
              title={showPassword ? 'Sembunyikan password' : 'Lihat password'}
              aria-label={showPassword ? 'Sembunyikan password' : 'Lihat password'}
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <div className="pt-2">
          <button
            id="btn-user-submit"
            type="submit"
            disabled={isSubmitting}
            className={`w-full h-11 rounded-xl text-white text-sm font-bold shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 active:scale-98 disabled:opacity-50 cursor-pointer ${
              isMurid
                ? 'bg-gradient-to-r from-pink-600 to-pink-500 hover:from-pink-700 hover:to-pink-600'
                : 'bg-gradient-to-r from-blue-700 to-blue-600 hover:from-blue-800 hover:to-blue-700'
            }`}
          >
            <span>Masuk</span>
          </button>
        </div>
      </form>
    </Modal>
  );
};
