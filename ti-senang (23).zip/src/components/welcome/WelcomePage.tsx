import React, { useState } from 'react';
import {
  Rocket,
  GraduationCap,
  BookOpen,
  ShieldCheck,
  ChevronRight,
  HelpCircle,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import logoTiSenang from '../../assets/images/logo_ti_senang.png';
import welcomeBg from '../../assets/images/welcome_bg.jpg';
import { FallingParticles } from './FallingParticles';
import { DnaLightWave } from './DnaLightWave';
import { RoleSelectionGatewayModal } from './RoleSelectionGatewayModal';

interface WelcomePageProps {
  onOpenAdminLogin?: () => void;
  onSelectRoleLogin: (role: 'guru' | 'murid') => void;
}

export const WelcomePage: React.FC<WelcomePageProps> = ({
  onSelectRoleLogin,
}) => {
  const [showRoleModal, setShowRoleModal] = useState(false);

  return (
    <div className="relative w-full h-full min-h-0 flex flex-col justify-center items-center overflow-hidden bg-slate-950">
      {/* Background Image with increased light opacity (+10%) */}
      <div
        className="absolute inset-0 w-full h-full bg-cover bg-center bg-no-repeat pointer-events-none z-0 opacity-70 brightness-[0.78] contrast-[1.03]"
        style={{ backgroundImage: `url(${welcomeBg})` }}
      />
      {/* Soft Vignette Overlays adjusted to let 10% more luminous ambient light through */}
      <div className="absolute inset-0 bg-gradient-to-b from-slate-950/55 via-slate-950/30 to-slate-950/60 pointer-events-none z-0" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-950/45 via-slate-950/15 to-slate-950/60 pointer-events-none z-0" />

      {/* Horizontal DNA Light Wave in Center */}
      <DnaLightWave />

      {/* Falling Particles from Top */}
      <FallingParticles />

      {/* Main Hero Section - Zero scroll, perfectly centered in frame */}
      <main className="relative flex-1 w-full max-w-5xl mx-auto flex flex-col items-center justify-center text-center px-3 sm:px-6 z-10 py-2 sm:py-3">
        {/* LOGO TI SENANG - Bingkai diperkecil 5%, putih pinggir dikurangi sehingga logo memenuhi bingkai */}
        <div id="front-page-logo-container" className="relative mb-3 sm:mb-4 group">
          {/* Ambient luminous glow bernuansa biru senada */}
          <div className="absolute -inset-2 bg-gradient-to-r from-blue-600/35 via-cyan-400/30 to-blue-500/35 rounded-3xl blur-xl opacity-60 group-hover:opacity-90 transition duration-500 pointer-events-none" />
          
          <div className="relative bg-white rounded-2xl sm:rounded-3xl p-1 sm:p-1.5 shadow-2xl shadow-slate-950/40 border border-slate-100 flex items-center justify-center transition-all duration-300 group-hover:shadow-[0_20px_35px_rgba(0,0,0,0.3)] overflow-hidden">
            <img
              id="front-page-logo-img"
              src={logoTiSenang}
              alt="Logo Resmi TI SENANG"
              className="w-[122px] h-[122px] sm:w-[152px] sm:h-[152px] md:w-[182px] md:h-[182px] lg:w-[198px] lg:h-[198px] object-contain drop-shadow-[0_4px_10px_rgba(0,0,0,0.12)] transition-transform duration-300 group-hover:scale-105"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* Subtitle / Tagline dalam Panel Biru Senada yang Transparan & Fleksibel Responsif (HP / Tab / Laptop) */}
        <div className="relative w-full max-w-[96vw] sm:max-w-xl md:max-w-2xl lg:max-w-4xl mx-auto mb-3.5 sm:mb-5 px-1 sm:px-2">
          {/* Ambient glow lembut senada di belakang tagline */}
          <div className="absolute -inset-1.5 sm:-inset-2 bg-gradient-to-r from-blue-600/30 via-cyan-500/25 to-blue-600/30 rounded-[24px] sm:rounded-[28px] blur-lg sm:blur-xl pointer-events-none" />

          <div
            id="tagline-panel"
            className="relative bg-gradient-to-r from-blue-950/75 via-blue-900/65 to-blue-950/75 backdrop-blur-xl border border-blue-400/35 sm:border-cyan-300/40 rounded-2xl sm:rounded-[20px] shadow-xl shadow-slate-950/35 px-3.5 sm:px-6 md:px-8 py-2 sm:py-3 md:py-3.5 flex items-center justify-center ring-1 ring-white/15"
          >
            <p
              id="tagline-text"
              className="text-[12px] min-[380px]:text-[13px] sm:text-[15px] md:text-[17px] lg:text-[20px] xl:text-[22px] font-bold text-white tracking-normal sm:tracking-tight text-center font-display leading-snug sm:leading-normal drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] break-words max-w-full"
            >
              Teknologi Inovatif untuk Sistem Pembelajaran Adaptif dan Menggembirakan
            </p>
          </div>
        </div>

        {/* Primary Action Area */}
        <div className="flex flex-col items-center justify-center gap-2 w-full max-w-xs sm:max-w-sm mx-auto">
          {/* 🚀 MULAI */}
          <button
            id="btn-mulai"
            onClick={() => setShowRoleModal(true)}
            className="w-56 sm:w-64 h-12 sm:h-13 px-6 rounded-2xl bg-gradient-to-r from-blue-600 via-blue-500 to-pink-500 hover:from-blue-700 hover:to-pink-600 text-white font-display font-bold text-base sm:text-lg tracking-wide shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/35 transition-all transform active:scale-98 flex items-center justify-center gap-2.5 cursor-pointer"
          >
            <Rocket className="w-5 h-5 animate-bounce" />
            <span>MULAI</span>
          </button>
        </div>
      </main>

      {/* Futuristic Welcome Gateway: Role Selection Modal (Triggered by 🚀 MULAI) */}
      <RoleSelectionGatewayModal
        isOpen={showRoleModal}
        onClose={() => setShowRoleModal(false)}
        onSelectRole={(role) => {
          setShowRoleModal(false);
          onSelectRoleLogin(role);
        }}
      />
    </div>
  );
};
