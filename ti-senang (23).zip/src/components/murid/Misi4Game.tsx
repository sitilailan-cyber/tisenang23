import React, { useState, useEffect } from 'react';
import {
  Gamepad2,
  Sparkles,
  Trophy,
  RotateCcw,
  CheckCircle2,
  ExternalLink,
  ArrowRight,
  Zap,
  Timer,
  Award,
  Layers,
  HelpCircle,
  Flag,
  Dices,
  Volume2,
  VolumeX,
  Music,
  X,
} from 'lucide-react';
import { Mission } from '../../types';
import { storage } from '../../services/storage';
import { joyfulGameMusic } from '../../services/audio/joyfulGameMusic';
import {
  fetchAiGameContent,
  getOfflineGameContent,
  GameContentData,
} from '../../services/ai/gameContentGenerator';

interface Misi4GameProps {
  studentId: string;
  studentName?: string;
  missionId: string;
  mission?: Mission;
  onCompleted?: () => void;
  onNextMission?: (nextMissionNumber: number) => void;
  onClose?: () => void;
}

type GameMode = 'TEACHER_LINK' | 'KARTU' | 'PUZZLE' | 'BALAPAN' | 'CERDAS_CERMAT' | 'ULAR_TANGGA';

// 1. DATA KARTU MENYAMAKAN KONSEP
interface CardItem {
  id: number;
  pairId: number;
  text: string;
  isFlipped: boolean;
  isMatched: boolean;
}

export const Misi4Game: React.FC<Misi4GameProps> = ({
  studentId,
  studentName = 'Siswa',
  missionId,
  mission,
  onCompleted,
  onNextMission,
  onClose,
}) => {
  // Helper deteksi mata pelajaran
  const getSubjectDisplayName = () => {
    const sId = (mission?.subjectId || '').toLowerCase();
    if (sId.includes('mat')) return 'Matematika';
    if (sId.includes('kim')) return 'Kimia';
    if (sId.includes('bio')) return 'Biologi';
    if (sId.includes('inf')) return 'Informatika';
    return 'Fisika';
  };

  // State konten game yang disesuaikan AI
  const [gameData, setGameData] = useState<GameContentData>(() =>
    getOfflineGameContent(getSubjectDisplayName(), mission?.title || 'Kalor & Termodinamika Sains')
  );
  const [isGeneratingAi, setIsGeneratingAi] = useState<boolean>(false);

  // Default to TEACHER_LINK if teacher provided a link, otherwise KARTU
  const hasTeacherLink = !!(mission?.gameUrl && mission.gameUrl.trim().length > 0);
  const [selectedGame, setSelectedGame] = useState<GameMode>(hasTeacherLink ? 'TEACHER_LINK' : 'KARTU');

  // Game completion state
  const [hasPlayed, setHasPlayed] = useState<boolean>(false);
  const [gameScore, setGameScore] = useState<number>(0);
  const [isMissionFinished, setIsMissionFinished] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(joyfulGameMusic.getIsMuted());
  const [isMusicPlaying, setIsMusicPlaying] = useState<boolean>(false);

  // --- 1. MENYAMAKAN KARTU STATE ---
  const [cards, setCards] = useState<CardItem[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [cardMatchesCount, setCardMatchesCount] = useState<number>(0);

  // --- 2. PUZZLE SUSUN KONSEP STATE ---
  const [puzzleTarget, setPuzzleTarget] = useState<string[]>(gameData.puzzleTarget);
  const [puzzleCurrent, setPuzzleCurrent] = useState<string[]>(gameData.puzzleInitial);
  const [puzzleSolved, setPuzzleSolved] = useState<boolean>(false);

  // --- 3. BALAPAN MENJAWAB SOAL STATE ---
  const [raceIdx, setRaceIdx] = useState<number>(0);
  const [raceDistance, setRaceDistance] = useState<number>(10);
  const [raceFinished, setRaceFinished] = useState<boolean>(false);

  // --- 4. CERDAS CERMAT SAINS STATE ---
  const [triviaIdx, setTriviaIdx] = useState<number>(0);
  const [triviaScore, setTriviaScore] = useState<number>(0);
  const [triviaFinished, setTriviaFinished] = useState<boolean>(false);

  // --- 5. ULAR TANGGA SAINS STATE ---
  const [pawnPosition, setPawnPosition] = useState<number>(1);
  const [diceRoll, setDiceRoll] = useState<number | null>(null);
  const [snakeMessage, setSnakeMessage] = useState<string>('Lempar dadu untuk memulai perjalanan sains!');
  const [ladderFinished, setLadderFinished] = useState<boolean>(false);

  // Inisialisasi Kartu dengan data kartu AI
  const initCardGameWithData = (cardItems: Array<{ pairId: number; text: string }>) => {
    const shuffled = [...cardItems]
      .sort(() => Math.random() - 0.5)
      .map((c, idx) => ({
        ...c,
        id: idx,
        isFlipped: false,
        isMatched: false,
      }));
    setCards(shuffled);
    setFlippedCards([]);
    setCardMatchesCount(0);
  };

  // Muat konten game berbasis AI sesuai mata pelajaran dan materi
  const loadAiContent = async () => {
    setIsGeneratingAi(true);
    const subjectName = getSubjectDisplayName();
    const topic = mission?.title || 'Kalor, Termodinamika & Regresi Sains';
    const desc = mission?.description || '';
    const content = await fetchAiGameContent(subjectName, topic, desc);
    
    setGameData(content);
    setIsGeneratingAi(false);

    // Update state semua game
    initCardGameWithData(content.cards);
    setPuzzleTarget(content.puzzleTarget);
    setPuzzleCurrent([...content.puzzleInitial]);
    setPuzzleSolved(false);

    setRaceIdx(0);
    setRaceDistance(10);
    setRaceFinished(false);

    setTriviaIdx(0);
    setTriviaScore(0);
    setTriviaFinished(false);

    setPawnPosition(1);
    setDiceRoll(null);
    setSnakeMessage('Lempar dadu untuk memulai perjalanan sains!');
    setLadderFinished(false);
  };

  useEffect(() => {
    loadAiContent();
  }, [mission?.subjectId, mission?.title]);

  // MUSIK MENGGEMBIRAKAN SAAT MASUK KE MISI GAME
  useEffect(() => {
    joyfulGameMusic.start();
    setIsMusicPlaying(true);

    const unsub = joyfulGameMusic.subscribe((playing, muted) => {
      setIsMusicPlaying(playing);
      setIsMuted(muted);
    });

    return () => {
      joyfulGameMusic.stop();
      unsub();
    };
  }, []);

  const handleToggleMusic = () => {
    const nextMuted = joyfulGameMusic.toggleMute();
    setIsMuted(nextMuted);
  };

  const handleCardClick = (id: number) => {
    if (flippedCards.length >= 2) return;
    const clickedCard = cards.find((c) => c.id === id);
    if (!clickedCard || clickedCard.isFlipped || clickedCard.isMatched) return;

    const newCards = cards.map((c) => (c.id === id ? { ...c, isFlipped: true } : c));
    setCards(newCards);

    const newFlipped = [...flippedCards, id];
    setFlippedCards(newFlipped);

    if (newFlipped.length === 2) {
      const first = cards.find((c) => c.id === newFlipped[0])!;
      const second = clickedCard;

      if (first.pairId === second.pairId) {
        setTimeout(() => {
          setCards((prev) =>
            prev.map((c) =>
              c.pairId === first.pairId ? { ...c, isMatched: true, isFlipped: true } : c,
            ),
          );
          setFlippedCards([]);
          const newCount = cardMatchesCount + 1;
          setCardMatchesCount(newCount);
          if (newCount === 4) {
            setHasPlayed(true);
            setGameScore(100);
          }
        }, 500);
      } else {
        setTimeout(() => {
          setCards((prev) =>
            prev.map((c) => (newFlipped.includes(c.id) ? { ...c, isFlipped: false } : c)),
          );
          setFlippedCards([]);
        }, 900);
      }
    }
  };

  // --- 2. PUZZLE SUSUN KONSEP HANDLER ---
  const handlePuzzleSwap = (fromIdx: number, toIdx: number) => {
    if (toIdx < 0 || toIdx >= puzzleCurrent.length) return;
    const updated = [...puzzleCurrent];
    const temp = updated[fromIdx];
    updated[fromIdx] = updated[toIdx];
    updated[toIdx] = temp;
    setPuzzleCurrent(updated);

    const isMatch = updated.every((val, idx) => val === puzzleTarget[idx]);
    if (isMatch) {
      setPuzzleSolved(true);
      setHasPlayed(true);
      setGameScore(100);
    }
  };

  // --- 3. BALAPAN MENJAWAB SOAL (SPEED RACE) HANDLER ---
  const raceQuestions = gameData.raceQuestions;
  const handleRaceAnswer = (optIdx: number) => {
    const isCorrect = optIdx === raceQuestions[raceIdx]?.correct;
    const addDist = isCorrect ? 30 : 10;
    const newDist = Math.min(100, raceDistance + addDist);
    setRaceDistance(newDist);

    if (raceIdx + 1 < raceQuestions.length) {
      setRaceIdx(raceIdx + 1);
    } else {
      setRaceFinished(true);
      setHasPlayed(true);
      setGameScore(newDist >= 80 ? 100 : 80);
    }
  };

  // --- 4. CERDAS CERMAT SAINS HANDLER ---
  const triviaQuestions = gameData.triviaQuestions;
  const handleTriviaAnswer = (optIdx: number) => {
    const isCorrect = optIdx === triviaQuestions[triviaIdx]?.correct;
    if (isCorrect) setTriviaScore((prev) => prev + 50);

    if (triviaIdx + 1 < triviaQuestions.length) {
      setTriviaIdx(triviaIdx + 1);
    } else {
      setTriviaFinished(true);
      setHasPlayed(true);
      setGameScore(isCorrect ? 100 : 75);
    }
  };

  // --- 5. ULAR TANGGA SAINS HANDLER ---
  const handleRollDice = () => {
    if (ladderFinished) return;
    const roll = Math.floor(Math.random() * 6) + 1;
    setDiceRoll(roll);
    let newPos = pawnPosition + roll;

    // Ladders & Snakes logic on 20-tile board
    if (newPos === 4) {
      newPos = 10;
      setSnakeMessage(gameData.snakeMessages.ladder1);
    } else if (newPos === 9) {
      newPos = 15;
      setSnakeMessage(gameData.snakeMessages.ladder2);
    } else if (newPos === 14) {
      newPos = 7;
      setSnakeMessage(gameData.snakeMessages.snake1);
    } else if (newPos === 18) {
      newPos = 11;
      setSnakeMessage(gameData.snakeMessages.snake2);
    } else if (newPos >= 20) {
      newPos = 20;
      setSnakeMessage(`🏆 Selamat! Anda berhasil mencapai garis finish Ular Tangga ${gameData.subjectName}!`);
      setLadderFinished(true);
      setHasPlayed(true);
      setGameScore(100);
    } else {
      setSnakeMessage(`Maju ${roll} langkah ke kotak ${newPos}. Lanjutkan petualangan sains!`);
    }

    setPawnPosition(newPos);
  };

  // SELESAI BERMAIN GAME -> OTOMATIS BUKA MISI 5
  const handleFinishMissionGame = () => {
    const finalScore = gameScore > 0 ? gameScore : 95;
    setIsMissionFinished(true);

    // 1. Simpan penyelesaian Misi 4 (TIDAK ADA PORTOFOLIO)
    storage.completeMission(studentId, missionId, finalScore, mission?.xpReward || 100);

    // 2. Beri notifikasi / callback untuk membuka Misi 5
    if (onCompleted) {
      onCompleted();
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-pink-600 via-rose-600 to-amber-600 rounded-3xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-xs font-bold uppercase tracking-wider">
                <Gamepad2 className="w-3.5 h-3.5" />
                Misi 4 • Game Edukasi Sains
              </div>

              {/* Cheerful Background Music Indicator & Mute Toggle */}
              <button
                type="button"
                onClick={handleToggleMusic}
                title={isMuted ? 'Nyalakan Musik Menggembirakan' : 'Senyapkan Musik'}
                className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/25 hover:bg-white/35 backdrop-blur border border-white/40 text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-95"
              >
                {isMuted ? (
                  <>
                    <VolumeX className="w-3.5 h-3.5 text-amber-200" />
                    <span className="text-amber-100">Musik: Senyap</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-3.5 h-3.5 text-emerald-300 animate-pulse" />
                    <span className="text-emerald-100 flex items-center gap-1">
                      <span>Musik Menggembirakan</span>
                      <span className="flex items-end gap-0.5 h-2.5">
                        <span className="w-0.5 h-1.5 bg-emerald-300 rounded animate-bounce" />
                        <span className="w-0.5 h-2.5 bg-emerald-300 rounded animate-bounce delay-100" />
                        <span className="w-0.5 h-1.5 bg-emerald-300 rounded animate-bounce delay-200" />
                      </span>
                    </span>
                  </>
                )}
              </button>
            </div>

            <h1 className="text-2xl sm:text-3xl font-display font-extrabold tracking-tight">
              Arena Permainan Interaktif TI SENANG
            </h1>
            <p className="text-pink-100 text-xs sm:text-sm mt-1 max-w-xl">
              Mainkan game edukasi dari tautan guru atau game buatan AI di bawah. Musik menggembirakan mengiringi permainanmu!
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <span className="px-3.5 py-1.5 rounded-full text-xs font-bold bg-white/20 backdrop-blur border border-white/30 text-white">
              +{mission?.xpReward || 100} XP Reward
            </span>
            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="px-3 py-1.5 rounded-full bg-white/20 hover:bg-white/30 border border-white/30 text-white text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                title="Tutup Misi Game"
              >
                <X className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Tutup</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* AI CONTENT ADAPTATION BANNER */}
      <div className="bg-gradient-to-r from-amber-50 via-rose-50 to-indigo-50 border border-amber-200/80 rounded-3xl p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-2xl bg-amber-500 text-white flex items-center justify-center shadow-xs shrink-0">
            <Sparkles className={`w-4 h-4 ${isGeneratingAi ? 'animate-spin' : ''}`} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-md bg-amber-200/70 text-amber-900">
                {gameData.isAiGenerated ? 'AI-Powered Game' : 'Smart Curriculum Engine'}
              </span>
              <span className="text-xs font-bold text-slate-800">
                Mata Pelajaran: <span className="text-indigo-600">{gameData.subjectName}</span>
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-0.5">
              Materi Pembelajaran: <strong>{gameData.topicTitle}</strong>
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => loadAiContent()}
          disabled={isGeneratingAi}
          className="px-4 py-2 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 text-xs font-bold text-slate-700 flex items-center justify-center gap-1.5 shadow-2xs transition-all active:scale-95 cursor-pointer disabled:opacity-50"
        >
          <RotateCcw className={`w-3.5 h-3.5 ${isGeneratingAi ? 'animate-spin text-amber-600' : 'text-slate-500'}`} />
          <span>{isGeneratingAi ? 'Menyesuaikan AI...' : 'Sesuaikan Materi dengan AI'}</span>
        </button>
      </div>

      {/* GAME MODE SWITCHER */}
      <div className="bg-white rounded-3xl p-4 border border-slate-200 shadow-xs">
        <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2 px-1">
          Pilih Mode Game Edukasi:
        </div>
        <div className="flex flex-wrap gap-2">
          {hasTeacherLink && (
            <button
              type="button"
              onClick={() => setSelectedGame('TEACHER_LINK')}
              className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                selectedGame === 'TEACHER_LINK'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Link Game Guru</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setSelectedGame('KARTU')}
            className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              selectedGame === 'KARTU'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>🃏 Menyamakan Kartu</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedGame('PUZZLE')}
            className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              selectedGame === 'PUZZLE'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>🧩 Puzzle Sains</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedGame('BALAPAN')}
            className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              selectedGame === 'BALAPAN'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>🏁 Balapan Menjawab</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedGame('CERDAS_CERMAT')}
            className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              selectedGame === 'CERDAS_CERMAT'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Trophy className="w-3.5 h-3.5" />
            <span>🏆 Cerdas Cermat</span>
          </button>

          <button
            type="button"
            onClick={() => setSelectedGame('ULAR_TANGGA')}
            className={`px-3.5 py-2 rounded-2xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              selectedGame === 'ULAR_TANGGA'
                ? 'bg-rose-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Dices className="w-3.5 h-3.5" />
            <span>🎲 Ular Tangga Sains</span>
          </button>
        </div>
      </div>

      {/* GAME ARENA CONTAINER */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
        {/* 0. LINK GAME GURU */}
        {selectedGame === 'TEACHER_LINK' && (
          <div className="text-center py-6 space-y-4">
            <div className="w-16 h-16 rounded-3xl bg-pink-100 text-pink-600 flex items-center justify-center mx-auto shadow-xs">
              <Gamepad2 className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <h3 className="text-lg font-bold text-slate-900">Game Rekomendasi Khusus dari Guru</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Guru telah menyiapkan tautan permainan edukatif (Quizizz, Wordwall, Kahoot, atau simulasi interaktif).
              </p>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
              <a
                href={mission?.gameUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  setHasPlayed(true);
                  setGameScore(100);
                }}
                className="px-6 py-3 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold flex items-center gap-2 shadow-md cursor-pointer active:scale-95"
              >
                <span>Buka Game di Tab Baru</span>
                <ExternalLink className="w-4 h-4" />
              </a>

              <button
                type="button"
                onClick={() => {
                  setHasPlayed(true);
                  setGameScore(100);
                }}
                className="px-4 py-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Saya Sudah Memainkan Game Guru</span>
              </button>
            </div>
          </div>
        )}

        {/* 1. MENYAMAKAN KARTU */}
        {selectedGame === 'KARTU' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <span>🃏 Game Menyamakan Kartu Konsep Sains</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Temukan 4 pasang kartu yang memiliki makna/rumus konsep yang cocok.
                </p>
              </div>
              <button
                type="button"
                onClick={() => initCardGameWithData(gameData.cards)}
                className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Kocok Ulang</span>
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
              {cards.map((card) => {
                const isOpen = card.isFlipped || card.isMatched;
                return (
                  <button
                    key={card.id}
                    type="button"
                    onClick={() => handleCardClick(card.id)}
                    className={`h-24 sm:h-28 rounded-2xl p-3 border flex items-center justify-center text-center transition-all cursor-pointer font-bold text-xs ${
                      card.isMatched
                        ? 'bg-emerald-50 border-emerald-300 text-emerald-800 shadow-xs'
                        : isOpen
                        ? 'bg-rose-50 border-rose-300 text-rose-900 shadow-md scale-102'
                        : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700 hover:scale-102'
                    }`}
                  >
                    {isOpen ? (
                      card.text
                    ) : (
                      <div className="flex flex-col items-center gap-1 text-slate-400">
                        <Sparkles className="w-5 h-5 text-amber-400" />
                        <span className="text-[10px]">Klik Buka</span>
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            {cardMatchesCount === 4 && (
              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-900 text-center text-xs font-bold flex items-center justify-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <span>Hebat! Seluruh pasangan kartu sains berhasil disamakan dengan tepat!</span>
              </div>
            )}
          </div>
        )}

        {/* 2. PUZZLE SUSUN KONSEP */}
        {selectedGame === 'PUZZLE' && (
          <div className="space-y-4">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                🧩 Puzzle Sains: Susun Rumus Perpindahan Kalor Termal
              </h3>
              <p className="text-xs text-slate-500">
                Susun kepingan di bawah sehingga membentuk rumus Azas Black: <strong>Q = m · c · ΔT</strong>
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-2 p-5 bg-slate-900 rounded-2xl">
              {puzzleCurrent.map((piece, idx) => (
                <div key={idx} className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handlePuzzleSwap(idx, idx - 1)}
                    disabled={idx === 0 || puzzleSolved}
                    className="w-5 h-5 rounded bg-slate-800 text-slate-400 hover:text-white text-[10px] flex items-center justify-center disabled:opacity-30"
                  >
                    ◀
                  </button>
                  <div
                    className={`w-12 h-14 sm:w-14 sm:h-16 rounded-xl flex items-center justify-center font-mono font-bold text-sm sm:text-base shadow-md border ${
                      puzzleSolved
                        ? 'bg-emerald-500 border-emerald-300 text-slate-950 ring-2 ring-emerald-300'
                        : 'bg-white border-slate-300 text-slate-900'
                    }`}
                  >
                    {piece}
                  </div>
                  <button
                    type="button"
                    onClick={() => handlePuzzleSwap(idx, idx + 1)}
                    disabled={idx === puzzleCurrent.length - 1 || puzzleSolved}
                    className="w-5 h-5 rounded bg-slate-800 text-slate-400 hover:text-white text-[10px] flex items-center justify-center disabled:opacity-30"
                  >
                    ▶
                  </button>
                </div>
              ))}
            </div>

            {puzzleSolved && (
              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-900 text-center text-xs font-bold flex items-center justify-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <span>Luar biasa! Susunan rumus kalor Q = m · c · ΔT berhasil tersusun rapi!</span>
              </div>
            )}
          </div>
        )}

        {/* 3. BALAPAN MENJAWAB SOAL */}
        {selectedGame === 'BALAPAN' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-900 text-sm">
                  🏁 Balapan Menjawab Soal Cepat Sains
                </h3>
                <p className="text-xs text-slate-500">
                  Jawab pertanyaan dengan akurat untuk memacu mobil eksperimen menuju garis finish!
                </p>
              </div>
            </div>

            {/* Race Track */}
            <div className="p-4 bg-slate-900 rounded-2xl space-y-2 border border-slate-800">
              <div className="flex items-center justify-between text-xs font-mono text-slate-400">
                <span>Start</span>
                <span>Jarak Tempuh: {raceDistance}%</span>
                <span className="flex items-center gap-1">
                  <Flag className="w-3.5 h-3.5 text-amber-400" /> Finish
                </span>
              </div>
              <div className="w-full h-8 bg-slate-800 rounded-xl relative overflow-hidden flex items-center px-1">
                <div
                  className="absolute top-1 bottom-1 bg-gradient-to-r from-amber-500 to-rose-500 rounded-lg transition-all duration-500"
                  style={{ width: `${raceDistance}%` }}
                />
                <span
                  className="absolute text-base transition-all duration-500"
                  style={{ left: `calc(${Math.min(92, raceDistance)}% - 10px)` }}
                >
                  🏎️
                </span>
              </div>
            </div>

            {!raceFinished ? (
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <span className="text-[10px] font-mono font-bold text-rose-600 uppercase">
                  Tantangan {raceIdx + 1} dari {raceQuestions.length}
                </span>
                <h4 className="text-xs sm:text-sm font-bold text-slate-800">
                  {raceQuestions[raceIdx].q}
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                  {raceQuestions[raceIdx].options.map((opt, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => handleRaceAnswer(i)}
                      className="p-3 rounded-xl bg-white border border-slate-200 hover:border-rose-400 hover:bg-rose-50/50 text-xs font-bold text-slate-700 transition-all cursor-pointer text-left"
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-900 text-center text-xs font-bold flex items-center justify-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <span>Balapan tuntas! Kecepatan dan ketepatan penalaran sains Anda memuaskan!</span>
              </div>
            )}
          </div>
        )}

        {/* 4. CERDAS CERMAT SAINS */}
        {selectedGame === 'CERDAS_CERMAT' && (
          <div className="space-y-4">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">
                🏆 Cerdas Cermat Sains Bertingkat
              </h3>
              <p className="text-xs text-slate-500">
                Uji wawasan konsep sains Anda dengan kuis cerdas cermat interaktif.
              </p>
            </div>

            {!triviaFinished ? (
              <div className="p-4 bg-purple-50/60 rounded-2xl border border-purple-200 space-y-3">
                <span className="text-[10px] font-mono font-bold text-purple-700 uppercase">
                  Pertanyaan {triviaIdx + 1} dari {triviaQuestions.length}
                </span>
                <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                  {triviaQuestions[triviaIdx].q}
                </h4>
                <div className="space-y-2 pt-1">
                  {triviaQuestions[triviaIdx].options.map((opt, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => handleTriviaAnswer(i)}
                      className="w-full p-3 rounded-xl bg-white border border-purple-200 hover:border-purple-400 text-xs text-slate-800 font-bold transition-all text-left flex items-center gap-2 cursor-pointer"
                    >
                      <span className="w-6 h-6 rounded-lg bg-purple-100 text-purple-700 text-xs flex items-center justify-center font-bold">
                        {String.fromCharCode(65 + i)}
                      </span>
                      <span>{opt}</span>
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 text-emerald-900 text-center text-xs font-bold flex items-center justify-center gap-2">
                <Trophy className="w-5 h-5 text-amber-500" />
                <span>Cerdas Cermat Selesai! Skor Anda: {triviaScore} Poin Bintang!</span>
              </div>
            )}
          </div>
        )}

        {/* 5. ULAR TANGGA SAINS */}
        {selectedGame === 'ULAR_TANGGA' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-900 text-sm">
                  🎲 Ular Tangga Sains (20 Kotak)
                </h3>
                <p className="text-xs text-slate-500">
                  Lempar dadu untuk menggerakkan bidak pion menuju kotak finish 20!
                </p>
              </div>

              <button
                type="button"
                onClick={handleRollDice}
                disabled={ladderFinished}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-rose-500 hover:from-amber-600 hover:to-rose-600 text-white text-xs font-bold shadow-xs flex items-center gap-2 cursor-pointer disabled:opacity-50 active:scale-95"
              >
                <Dices className="w-4 h-4" />
                <span>{diceRoll ? `Dadu: [${diceRoll}] • Lempar Lagi` : 'Lempar Dadu'}</span>
              </button>
            </div>

            {/* Board 20 Tiles */}
            <div className="grid grid-cols-5 sm:grid-cols-10 gap-1.5 p-3 bg-slate-900 rounded-2xl border border-slate-800">
              {Array.from({ length: 20 }, (_, i) => i + 1).map((num) => {
                const isPawnHere = pawnPosition === num;
                const isLadder = num === 4 || num === 9;
                const isSnake = num === 14 || num === 18;

                return (
                  <div
                    key={num}
                    className={`h-12 rounded-xl border flex flex-col items-center justify-center relative text-xs font-bold transition-all ${
                      isPawnHere
                        ? 'bg-amber-400 border-amber-300 text-slate-950 scale-105 shadow-md z-10'
                        : isLadder
                        ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
                        : isSnake
                        ? 'bg-rose-950/60 border-rose-500/40 text-rose-300'
                        : 'bg-slate-800/80 border-slate-700/60 text-slate-300'
                    }`}
                  >
                    <span className="text-[9px] opacity-60 absolute top-1 left-1">{num}</span>
                    {isPawnHere ? (
                      <span className="text-sm animate-bounce">🏃</span>
                    ) : isLadder ? (
                      <span className="text-[10px]">🪜</span>
                    ) : isSnake ? (
                      <span className="text-[10px]">🐍</span>
                    ) : null}
                  </div>
                );
              })}
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700 flex items-center gap-2">
              <span className="font-bold text-amber-700">Status Permainan:</span>
              <span>{snakeMessage}</span>
            </div>
          </div>
        )}
      </div>

      {/* FOOTER: SELESAIKAN GAME -> BUKA MISI 5 (TIDAK ADA PORTOFOLIO) */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="text-xs text-slate-600">
          <p className="font-bold text-slate-800">Selesai Bermain Game Edukasi?</p>
          <p className="text-slate-500 mt-0.5">
            Misi 5 (Refleksi) akan langsung otomatis terbuka tanpa perlu mengunggah portofolio.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-2.5 w-full sm:w-auto">
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto px-4 py-3 rounded-2xl font-bold text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 cursor-pointer transition-colors"
            >
              Tutup Misi Game
            </button>
          )}

          {isMissionFinished && onNextMission ? (
            <button
              id="btn-lanjut-misi-5"
              type="button"
              onClick={() => {
                joyfulGameMusic.stop();
                onNextMission(5);
              }}
              className="w-full sm:w-auto px-6 py-3 rounded-2xl font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 bg-blue-600 hover:bg-blue-700 text-white"
            >
              <span>Lanjut ke Misi 5 (Refleksi)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              id="btn-selesai-game-m4"
              type="button"
              onClick={() => {
                if (isMissionFinished) {
                  joyfulGameMusic.stop();
                  if (onNextMission) {
                    onNextMission(5);
                  } else if (onClose) {
                    onClose();
                  }
                } else {
                  handleFinishMissionGame();
                  if (onNextMission) {
                    joyfulGameMusic.stop();
                    onNextMission(5);
                  }
                }
              }}
              className={`w-full sm:w-auto px-6 py-3 rounded-2xl font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 ${
                isMissionFinished
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                  : hasPlayed
                  ? 'bg-gradient-to-r from-pink-600 via-rose-600 to-amber-600 hover:from-pink-700 hover:to-amber-700 text-white'
                  : 'bg-rose-600 hover:bg-rose-700 text-white'
              }`}
            >
              {isMissionFinished ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Game Selesai (Lanjut Misi 5)</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              ) : (
                <>
                  <span>Selesai Bermain & Buka Misi 5</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
