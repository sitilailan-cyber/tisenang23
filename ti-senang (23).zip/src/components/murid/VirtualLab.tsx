import React, { useState, useEffect, useRef } from 'react';
import {
  Thermometer,
  Zap,
  LineChart as LineChartIcon,
  Play,
  RotateCcw,
  Square,
  CheckCircle2,
  ExternalLink,
  Sparkles,
  GraduationCap,
  Laptop,
  ArrowRight,
  BookOpen,
  FlaskConical,
  Plus,
  Trash2,
  Save,
  Download,
  Share2,
  Info,
  Clock,
  Flame,
  Droplets,
  Lightbulb,
  ToggleLeft,
  ToggleRight,
  ChevronRight,
  Calculator,
  RefreshCw,
  FileSpreadsheet,
} from 'lucide-react';
import { storage } from '../../services/storage';
import { firebaseRealtime, STUDENT_DRIVE_FOLDER_URL } from '../../services/firebaseRealtime';
import { Mission, Subject } from '../../types';
import * as XLSX from 'xlsx';

interface VirtualLabProps {
  studentId: string;
  missionId?: string;
  onNavigateToMisi2?: (step?: 'COLLECT' | 'OBSERVE' | 'EXPERIMENT') => void;
  onFinishExperiment?: () => void;
}

type SimulasiMode = 'GURU' | 'APLIKASI';
type MateriType = 'suhu_kalor' | 'listrik' | 'regresi_linear';

interface SimulasiDataRow {
  id: string;
  no: number;
  param1: string; // misal Waktu / Tegangan / Variabel X
  param2: string; // misal Suhu / Arus / Variabel Y
  param3?: string; // misal Kalor / Hambatan / Residu
  catatan: string;
}

export const VirtualLab: React.FC<VirtualLabProps> = ({
  studentId,
  missionId = 'msn-cls-xii-1-3',
  onNavigateToMisi2,
  onFinishExperiment,
}) => {
  const profile = storage.getStudentProfile(studentId);
  const classId = profile?.student?.classId || 'cls-xii-1';
  const className = profile?.className || 'XII-1';

  // =========================================================================
  // LANGKAH 1: SELEKSI MATA PELAJARAN (Jangan langsung ditampilkan)
  // =========================================================================
  const [selectedSubjectId, setSelectedSubjectId] = useState<string | null>(null);
  const [selectedMateri, setSelectedMateri] = useState<MateriType>('suhu_kalor');

  // =========================================================================
  // LANGKAH 2: PILIH TOMBOL "SIMULASI GURU" ATAU "SIMULASI APLIKASI"
  // =========================================================================
  const [activeSimulasiMode, setActiveSimulasiMode] = useState<SimulasiMode | null>(null);

  // ----------------- STATE SIMULASI GURU -----------------
  const [teacherLink, setTeacherLink] = useState<string>('');
  const [teacherSimTitle, setTeacherSimTitle] = useState<string>('');
  const [teacherSimGuide, setTeacherSimGuide] = useState<string>('');
  const [isEditingTeacherLink, setIsEditingTeacherLink] = useState<boolean>(false);
  const [newTeacherUrlInput, setNewTeacherUrlInput] = useState<string>('');
  const [newTeacherTitleInput, setNewTeacherTitleInput] = useState<string>('');
  const [newTeacherGuideInput, setNewTeacherGuideInput] = useState<string>('');
  const [isSavingTeacherLink, setIsSavingTeacherLink] = useState<boolean>(false);

  // ----------------- STATE SIMULASI APLIKASI (AI) -----------------
  // 1. Materi: Suhu & Kalor
  const [heaterOn, setHeaterOn] = useState<boolean>(false);
  const [heaterPower, setHeaterPower] = useState<number>(100); // Watt
  const [waterVolume, setWaterVolume] = useState<number>(200); // mL / gram
  const [waterTemp, setWaterTemp] = useState<number>(25.0); // °C
  const [timerSeconds, setTimerSeconds] = useState<number>(0);
  const [calorimeterDataPoints, setCalorimeterDataPoints] = useState<{ t: number; temp: number }[]>([
    { t: 0, temp: 25.0 },
  ]);

  // 2. Materi: Listrik Dinamis
  const [circuitClosed, setCircuitClosed] = useState<boolean>(false);
  const [voltage, setVoltage] = useState<number>(9); // Volt
  const [resistance, setResistance] = useState<number>(30); // Ohm

  // 3. Materi: Regresi Linear & Diagram Pencar
  const [scatterPoints, setScatterPoints] = useState<{ x: number; y: number }[]>([
    { x: 10, y: 28 },
    { x: 20, y: 34 },
    { x: 30, y: 42 },
    { x: 40, y: 51 },
    { x: 50, y: 59 },
    { x: 60, y: 68 },
    { x: 70, y: 76 },
    { x: 80, y: 85 },
  ]);
  const [newPointX, setNewPointX] = useState<string>('');
  const [newPointY, setNewPointY] = useState<string>('');

  // ----------------- TABEL DATA HASIL SIMULASI -----------------
  const [recordedRows, setRecordedRows] = useState<SimulasiDataRow[]>([]);
  const [saveStatus, setSaveStatus] = useState<{ type: 'idle' | 'saving' | 'success' | 'error'; message: string }>({
    type: 'idle',
    message: '',
  });

  // Ambil link simulasi guru jika mapel dipilih
  useEffect(() => {
    if (selectedSubjectId) {
      // 1. Coba ambil dari Firebase RTDB simulasi_guru
      firebaseRealtime.fetchTeacherSimulationLink(selectedSubjectId, classId).then((linkObj) => {
        if (linkObj && linkObj.url) {
          setTeacherLink(linkObj.url);
          setTeacherSimTitle(linkObj.title || 'Simulasi Virtual dari Guru');
          setTeacherSimGuide(linkObj.guide || '');
        } else {
          // 2. Fallback: cari dari misi kelas guru
          const classMissions = storage.getMissionsByClass(classId);
          const teacherMission = classMissions.find(
            (m) =>
              (m.subjectId === selectedSubjectId || m.coreMissionNumber === 3) &&
              (m.simulationUrl || m.mediaResources?.some((r) => r.type === 'link'))
          );
          if (teacherMission && teacherMission.simulationUrl) {
            setTeacherLink(teacherMission.simulationUrl);
            setTeacherSimTitle(teacherMission.title);
            setTeacherSimGuide(teacherMission.simulationSteps || teacherMission.description);
          } else {
            // Default preset referensi saintifik jika belum ada
            if (selectedSubjectId === 'sbj-fisika') {
              setTeacherLink('https://phet.colorado.edu/sims/html/energy-forms-and-changes/latest/energy-forms-and-changes_all.html');
              setTeacherSimTitle('PhET Interactive Simulator: Bentuk Energi & Kalor');
              setTeacherSimGuide('1. Letakkan bejana air di atas kompor; 2. Pasang termometer di dalam air; 3. Naikkan panas api dan catat perubahan suhu setiap interval waktu.');
            } else if (selectedSubjectId === 'sbj-matematika') {
              setTeacherLink('https://www.geogebra.org/m/k9f2qfx4');
              setTeacherSimTitle('GeoGebra Simulator: Line of Best Fit & Regresi Linear');
              setTeacherSimGuide('Geser titik-titik data pengamatan untuk mengamati perubahan gradien kemiringan garis regresi dan koefisien determinasi R².');
            } else {
              setTeacherLink('');
              setTeacherSimTitle('');
              setTeacherSimGuide('');
            }
          }
        }
      });
    }
  }, [selectedSubjectId, classId]);

  // Loop Fisika Suhu & Kalor: Saat pemanas ON, suhu naik Q = P * t = m * c * DeltaT
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (heaterOn) {
      interval = setInterval(() => {
        setTimerSeconds((t) => {
          const nextT = t + 1;
          // c air = 4.184 J/g.C -> deltaT = (Power in Watt * 1 detik) / (mass in gram * 4.184)
          // Scale factor untuk simulasi yang nyaman di browser:
          const deltaTPerSecond = (heaterPower * 1.5) / (waterVolume * 4.184);
          setWaterTemp((prevTemp) => {
            const nextTemp = Math.min(100.0, Number((prevTemp + deltaTPerSecond).toFixed(2)));
            setCalorimeterDataPoints((prev) => [...prev.slice(-30), { t: nextT, temp: nextTemp }]);
            return nextTemp;
          });
          return nextT;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [heaterOn, heaterPower, waterVolume]);

  // Kalkulasi Fisika Listrik: Hukum Ohm I = V / R, P = V * I
  const currentAmpere = circuitClosed ? Number((voltage / resistance).toFixed(3)) : 0;
  const currentMilliAmp = circuitClosed ? Number(((voltage / resistance) * 1000).toFixed(1)) : 0;
  const electricPowerWatt = circuitClosed ? Number(((voltage * voltage) / resistance).toFixed(2)) : 0;

  // Kalkulasi Matematika: Regresi Linear (Slope m, Intercept c, Pearson r, R^2)
  const regressionStats = React.useMemo(() => {
    const n = scatterPoints.length;
    if (n < 2) return { m: 0, c: 0, r: 0, r2: 0 };
    let sumX = 0;
    let sumY = 0;
    let sumXY = 0;
    let sumX2 = 0;
    let sumY2 = 0;

    scatterPoints.forEach((p) => {
      sumX += p.x;
      sumY += p.y;
      sumXY += p.x * p.y;
      sumX2 += p.x * p.x;
      sumY2 += p.y * p.y;
    });

    const m = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const c = (sumY - m * sumX) / n;

    // Pearson r
    const numerator = n * sumXY - sumX * sumY;
    const denominator = Math.sqrt((n * sumX2 - sumX * sumX) * (n * sumY2 - sumY * sumY));
    const r = denominator !== 0 ? numerator / denominator : 0;
    const r2 = r * r;

    return {
      m: Number(m.toFixed(3)),
      c: Number(c.toFixed(2)),
      r: Number(r.toFixed(4)),
      r2: Number(r2.toFixed(4)),
    };
  }, [scatterPoints]);

  // =========================================================================
  // HANDLER PENCATATAN SIMULASI KE TABEL
  // =========================================================================
  const handleRecordDataSuhu = () => {
    const newRow: SimulasiDataRow = {
      id: `sim-suhu-${Date.now()}`,
      no: recordedRows.length + 1,
      param1: `${timerSeconds} detik`,
      param2: `${waterTemp} °C`,
      param3: `${(waterVolume * 4.184 * (waterTemp - 25.0)).toFixed(1)} Joule`,
      catatan: `Daya ${heaterPower}W, Volume ${waterVolume}mL`,
    };
    setRecordedRows((prev) => [...prev, newRow]);
  };

  const handleRecordDataListrik = () => {
    const newRow: SimulasiDataRow = {
      id: `sim-elec-${Date.now()}`,
      no: recordedRows.length + 1,
      param1: `${voltage} Volt`,
      param2: `${currentMilliAmp} mA (${currentAmpere} A)`,
      param3: `${electricPowerWatt} Watt`,
      catatan: `Hambatan R = ${resistance} Ω (${circuitClosed ? 'Saklar ON' : 'Saklar OFF'})`,
    };
    setRecordedRows((prev) => [...prev, newRow]);
  };

  const handleRecordDataRegresi = () => {
    const newRow: SimulasiDataRow = {
      id: `sim-reg-${Date.now()}`,
      no: recordedRows.length + 1,
      param1: `N = ${scatterPoints.length} Titik`,
      param2: `y = ${regressionStats.m}x + ${regressionStats.c}`,
      param3: `R² = ${regressionStats.r2} (r = ${regressionStats.r})`,
      catatan: `Korelasi ${Math.abs(regressionStats.r) > 0.8 ? 'Sangat Kuat' : 'Moderat'}`,
    };
    setRecordedRows((prev) => [...prev, newRow]);
  };

  // Simpan tabel simulasi ke Database Misi Siswa
  const handleSaveToStudentMission = async () => {
    if (recordedRows.length === 0) {
      setSaveStatus({
        type: 'error',
        message: 'Tabel simulasi masih kosong. Rekam beberapa data pengamatan terlebih dahulu.',
      });
      setTimeout(() => setSaveStatus({ type: 'idle', message: '' }), 3500);
      return;
    }

    setSaveStatus({ type: 'saving', message: 'Menyimpan tabel ke Database Misi Siswa & Firebase...' });
    try {
      await firebaseRealtime.saveStudentExperimentData(studentId, missionId, {
        studentName: profile?.student?.name || 'Siswa TI SENANG',
        className,
        rows: recordedRows,
        notes: `Simulasi Virtual ${selectedMateri} (${activeSimulasiMode === 'GURU' ? 'Simulasi Guru' : 'Simulasi Aplikasi AI'})`,
        parameters: {
          materi: selectedMateri,
          mode: activeSimulasiMode,
          subjectId: selectedSubjectId,
        },
      });

      // Format baris untuk Misi 2
      const rowsForStorage = recordedRows.map((r, idx) => ({
        waktu: (r as any).waktu !== undefined ? Number((r as any).waktu) : (idx * 5),
        suhuAwal: 25.0,
        suhuAkhir: (r as any).suhuAkhir !== undefined ? Number((r as any).suhuAkhir) : ((r as any).suhu !== undefined ? Number((r as any).suhu) : 28.0),
        deltaT: 3.0,
        kalorTerukur: 2500,
        kalorTeoritis: 2520,
        efisiensi: 99.2,
        intensitasCahaya: (r as any).intensitasCahaya !== undefined ? Number((r as any).intensitasCahaya) : 500,
      }));

      const baseSession = {
        experimentId: `exp-${Date.now()}`,
        studentId,
        missionId,
        startedAt: new Date(Date.now() - 60000).toISOString(),
        completedAt: new Date().toISOString(),
        status: 'COMPLETED' as const,
        source: 'SIMULATION' as const,
        readings: [],
        rows: rowsForStorage as any,
      };

      storage.saveExperimentSession(baseSession);
      storage.saveExperimentSession({
        ...baseSession,
        missionId: 'msn-cls-xii-1-2',
      });

      try {
        localStorage.setItem('tisenang_latest_experiment_rows', JSON.stringify(rowsForStorage));
        localStorage.setItem('tisenang_misi2_active_step', 'COLLECT');
      } catch {
        // ignore
      }

      storage.completeMission(studentId, missionId, 95, 120);

      window.dispatchEvent(
        new CustomEvent('tisenang_experiment_saved', {
          detail: { rows: rowsForStorage, step: 'COLLECT' },
        })
      );
      window.dispatchEvent(new CustomEvent('tisenang_missions_updated'));

      setSaveStatus({
        type: 'success',
        message: 'Hasil Simulasi Virtual berhasil disimpan! Mengalihkan ke Misi 2 Tahap 3 (Kumpul Data)...',
      });

      setTimeout(() => {
        setSaveStatus({ type: 'idle', message: '' });
        if (onNavigateToMisi2) {
          onNavigateToMisi2('COLLECT');
        }
      }, 700);
    } catch {
      setSaveStatus({
        type: 'error',
        message: 'Gagal menyimpan ke Firebase. Cek koneksi internet Anda.',
      });
      setTimeout(() => setSaveStatus({ type: 'idle', message: '' }), 3500);
    }
  };

  // Download Excel (.xlsx) untuk simulasi virtual
  const handleExportExcel = () => {
    if (recordedRows.length === 0) return;
    const worksheet = XLSX.utils.json_to_sheet(recordedRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Simulasi Virtual');
    XLSX.writeFile(workbook, `Simulasi_Virtual_TISENANG_${selectedMateri}.xlsx`);
  };

  // Simpan Link Simulasi Guru
  const handleSaveTeacherLinkCustom = async () => {
    if (!newTeacherUrlInput.trim() || !selectedSubjectId) return;
    setIsSavingTeacherLink(true);
    try {
      await firebaseRealtime.saveTeacherSimulationLink(selectedSubjectId, classId, {
        url: newTeacherUrlInput.trim(),
        title: newTeacherTitleInput.trim() || 'Simulasi Virtual Pembelajaran Guru',
        guide: newTeacherGuideInput.trim(),
        teacherName: 'Guru Pembimbing',
      });
      setTeacherLink(newTeacherUrlInput.trim());
      setTeacherSimTitle(newTeacherTitleInput.trim() || 'Simulasi Virtual Pembelajaran Guru');
      setTeacherSimGuide(newTeacherGuideInput.trim());
      setIsEditingTeacherLink(false);
      alert('Tautan simulasi guru berhasil disimpan ke Firebase!');
    } catch {
      alert('Gagal menyimpan tautan guru ke Firebase.');
    } finally {
      setIsSavingTeacherLink(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Utama: Simulasi Virtual */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-5 rounded-3xl border border-indigo-500/30 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/40 text-[10px] font-black tracking-wider uppercase">
                Laboratorium Saintifik Maya
              </span>
              <span className="text-[11px] font-bold text-slate-300">
                Kelas {className}
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
              <FlaskConical className="w-6 h-6 text-indigo-400" />
              <span>Simulasi Virtual</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
              Eksplorasi fenomena sains dan pemodelan matematika interaktif. Pilih mata pelajaran untuk menjalankan simulasi yang dikirimkan oleh Guru atau simulasi virtual interaktif berbasis AI.
            </p>
          </div>

          {/* Reset / Ganti Mata Pelajaran */}
          {selectedSubjectId && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setSelectedSubjectId(null);
                  setActiveSimulasiMode(null);
                }}
                className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <span>← Ganti Mata Pelajaran</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* =========================================================================
          LANGKAH 1: SISWA HARUS MEMILIH MATA PELAJARAN TERLEBIH DAHULU
          (Jangan langsung ditampilkan sebelum mata pelajaran dipilih)
          ========================================================================= */}
      {!selectedSubjectId ? (
        <div className="bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          <div className="text-center max-w-md mx-auto space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 flex items-center justify-center mx-auto">
              <BookOpen className="w-6 h-6" />
            </div>
            <h2 className="text-lg font-black text-slate-900 dark:text-white">
              Pilih Mata Pelajaran Praktikum
            </h2>
            <p className="text-xs text-slate-500">
              Silakan pilih mata pelajaran untuk mengakses Simulasi Guru atau Simulasi Aplikasi interaktif AI.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 max-w-4xl mx-auto">
            {/* FISIKA */}
            <button
              onClick={() => {
                setSelectedSubjectId('sbj-fisika');
                setSelectedMateri('suhu_kalor');
              }}
              className="p-5 rounded-2xl border-2 border-slate-200 dark:border-slate-800 hover:border-indigo-500 hover:shadow-lg transition-all text-left group bg-gradient-to-b from-white to-slate-50/50 dark:from-slate-900 dark:to-slate-850 cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-950/50 text-rose-600 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                <Thermometer className="w-5 h-5" />
              </div>
              <h3 className="font-black text-sm text-slate-900 dark:text-white group-hover:text-indigo-600 transition-colors">
                Fisika
              </h3>
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                Simulasi Suhu & Kalor (Gelas Ukur & Termometer), Rangkaian Listrik Dinamis (Hukum Ohm).
              </p>
              <div className="mt-3 flex items-center gap-1 text-[11px] font-bold text-indigo-600">
                <span>Pilih Fisika</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </div>
            </button>

            {/* MATEMATIKA */}
            <button
              onClick={() => {
                setSelectedSubjectId('sbj-matematika');
                setSelectedMateri('regresi_linear');
              }}
              className="p-5 rounded-2xl border-2 border-slate-200 dark:border-slate-800 hover:border-indigo-500 hover:shadow-lg transition-all text-left group bg-gradient-to-b from-white to-slate-50/50 dark:from-slate-900 dark:to-slate-850 cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950/50 text-blue-600 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                <LineChartIcon className="w-5 h-5" />
              </div>
              <h3 className="font-black text-sm text-slate-900 dark:text-white group-hover:text-indigo-600 transition-colors">
                Matematika
              </h3>
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                Diagram Pencar (Scatter Plot), Line of Best Fit, Regresi Linear, dan Interpretasi Analisis Data.
              </p>
              <div className="mt-3 flex items-center gap-1 text-[11px] font-bold text-indigo-600">
                <span>Pilih Matematika</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </div>
            </button>

            {/* KIMIA */}
            <button
              onClick={() => {
                setSelectedSubjectId('sbj-kimia');
                setSelectedMateri('suhu_kalor');
              }}
              className="p-5 rounded-2xl border-2 border-slate-200 dark:border-slate-800 hover:border-indigo-500 hover:shadow-lg transition-all text-left group bg-gradient-to-b from-white to-slate-50/50 dark:from-slate-900 dark:to-slate-850 cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950/50 text-amber-600 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                <Flame className="w-5 h-5" />
              </div>
              <h3 className="font-black text-sm text-slate-900 dark:text-white group-hover:text-indigo-600 transition-colors">
                Kimia
              </h3>
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                Termokimia kalor reaksi, laju reaksi kimia, dan kesetimbangan larutan.
              </p>
              <div className="mt-3 flex items-center gap-1 text-[11px] font-bold text-indigo-600">
                <span>Pilih Kimia</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </div>
            </button>

            {/* BIOLOGI */}
            <button
              onClick={() => {
                setSelectedSubjectId('sbj-biologi');
                setSelectedMateri('regresi_linear');
              }}
              className="p-5 rounded-2xl border-2 border-slate-200 dark:border-slate-800 hover:border-indigo-500 hover:shadow-lg transition-all text-left group bg-gradient-to-b from-white to-slate-50/50 dark:from-slate-900 dark:to-slate-850 cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/50 text-emerald-600 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                <Droplets className="w-5 h-5" />
              </div>
              <h3 className="font-black text-sm text-slate-900 dark:text-white group-hover:text-indigo-600 transition-colors">
                Biologi
              </h3>
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                Pengamatan fotosintesis, pengaruh suhu terhadap aktivitas enzim, dan kurva pertumbuhan.
              </p>
              <div className="mt-3 flex items-center gap-1 text-[11px] font-bold text-indigo-600">
                <span>Pilih Biologi</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </div>
            </button>
          </div>
        </div>
      ) : (
        /* =========================================================================
            LANGKAH 2: SETELAH MATA PELAJARAN DIPILIH, TAMPILKAN 2 TOMBOL:
            - "Simulasi Guru"
            - "Simulasi Aplikasi"
            ========================================================================= */
        <div className="space-y-6">
          {/* Top Bar: Pemilihan Mode Simulasi & Materi */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider text-slate-400">
                Mata Pelajaran:
              </span>
              <span className="px-3 py-1 rounded-xl bg-indigo-50 dark:bg-indigo-950/70 text-indigo-700 dark:text-indigo-300 font-black text-xs border border-indigo-200 dark:border-indigo-800">
                {selectedSubjectId === 'sbj-fisika'
                  ? 'Fisika'
                  : selectedSubjectId === 'sbj-matematika'
                  ? 'Matematika'
                  : selectedSubjectId === 'sbj-kimia'
                  ? 'Kimia'
                  : 'Biologi'}
              </span>

              {/* Pemilih Topik Materi Khusus Fisika */}
              {selectedSubjectId === 'sbj-fisika' && (
                <div className="flex items-center gap-1 ml-2">
                  <button
                    onClick={() => setSelectedMateri('suhu_kalor')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                      selectedMateri === 'suhu_kalor'
                        ? 'bg-rose-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    Suhu & Kalor
                  </button>
                  <button
                    onClick={() => setSelectedMateri('listrik')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                      selectedMateri === 'listrik'
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    Rangkaian Listrik
                  </button>
                </div>
              )}
            </div>

            {/* DUA TOMBOL UTAMA YANG DIINSTRUKSIKAN */}
            <div className="flex items-center gap-2">
              {/* TOMBOL 1: SIMULASI GURU */}
              <button
                id="btn-simulasi-guru"
                onClick={() => setActiveSimulasiMode('GURU')}
                className={`flex-1 sm:flex-initial px-5 py-2.5 rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  activeSimulasiMode === 'GURU'
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 shadow-md shadow-amber-500/25 border border-amber-400'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 border border-slate-300 dark:border-slate-700'
                }`}
              >
                <GraduationCap className="w-4 h-4" />
                <span>Simulasi Guru</span>
              </button>

              {/* TOMBOL 2: SIMULASI APLIKASI */}
              <button
                id="btn-simulasi-aplikasi"
                onClick={() => setActiveSimulasiMode('APLIKASI')}
                className={`flex-1 sm:flex-initial px-5 py-2.5 rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  activeSimulasiMode === 'APLIKASI'
                    ? 'bg-gradient-to-r from-indigo-600 to-blue-600 text-white shadow-md shadow-indigo-500/25 border border-indigo-400'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 border border-slate-300 dark:border-slate-700'
                }`}
              >
                <Sparkles className="w-4 h-4 text-cyan-300" />
                <span>Simulasi Aplikasi</span>
              </button>
            </div>
          </div>

          {/* =========================================================================
              TAMPILAN KETIKA BELUM MEMILIH SALAH SATU DARI DUA TOMBOL
              ========================================================================= */}
          {!activeSimulasiMode && (
            <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm text-center space-y-4">
              <div className="w-14 h-14 rounded-3xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 flex items-center justify-center mx-auto">
                <Laptop className="w-7 h-7" />
              </div>
              <div className="max-w-md mx-auto space-y-1">
                <h3 className="text-base font-black text-slate-900 dark:text-white">
                  Pilih Jenis Simulasi Virtual
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Silakan klik salah satu tombol di atas:
                  <br />
                  <strong className="text-amber-700 dark:text-amber-400">"Simulasi Guru"</strong> untuk membuka tautan simulator yang disiapkan khusus oleh guru, atau
                  <br />
                  <strong className="text-indigo-600 dark:text-indigo-400">"Simulasi Aplikasi"</strong> untuk menjalankan simulator interaktif yang digenerate oleh sistem AI.
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <button
                  onClick={() => setActiveSimulasiMode('GURU')}
                  className="px-5 py-2.5 rounded-2xl bg-amber-500 text-slate-950 font-black text-xs shadow-xs hover:bg-amber-600 flex items-center gap-2 cursor-pointer"
                >
                  <GraduationCap className="w-4 h-4" />
                  <span>Buka Simulasi Guru</span>
                </button>
                <button
                  onClick={() => setActiveSimulasiMode('APLIKASI')}
                  className="px-5 py-2.5 rounded-2xl bg-indigo-600 text-white font-black text-xs shadow-xs hover:bg-indigo-700 flex items-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-cyan-300" />
                  <span>Buka Simulasi Aplikasi</span>
                </button>
              </div>
            </div>
          )}

          {/* =========================================================================
              PILIHAN 1: SIMULASI GURU (Link yang dikirimkan sendiri oleh Guru)
              ========================================================================= */}
          {activeSimulasiMode === 'GURU' && (
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden space-y-4">
              {/* Header Simulasi Guru */}
              <div className="p-5 bg-gradient-to-r from-amber-50 to-orange-50/60 dark:from-amber-950/20 dark:to-orange-950/20 border-b border-amber-200 dark:border-amber-900/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-amber-200/80 text-amber-900 font-black text-[10px] uppercase tracking-wider">
                      Simulasi dari Guru Pembimbing
                    </span>
                  </div>
                  <h3 className="text-base font-black text-slate-900 dark:text-white mt-1">
                    {teacherSimTitle || 'Tautan Simulator Virtual Guru'}
                  </h3>
                  {teacherSimGuide && (
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 max-w-2xl bg-white/60 dark:bg-slate-800/60 p-2.5 rounded-xl border border-amber-200/60">
                      <strong>Langkah Praktikum dari Guru:</strong> {teacherSimGuide}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setIsEditingTeacherLink(!isEditingTeacherLink);
                      setNewTeacherUrlInput(teacherLink);
                      setNewTeacherTitleInput(teacherSimTitle);
                      setNewTeacherGuideInput(teacherSimGuide);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-300 dark:border-slate-700 text-xs font-bold hover:bg-slate-100 flex items-center gap-1.5"
                  >
                    <span>{isEditingTeacherLink ? 'Batal Edit' : '✏️ Kelola Tautan Guru'}</span>
                  </button>

                  {teacherLink && (
                    <a
                      href={teacherLink}
                      target="_blank"
                      rel="noreferrer"
                      className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-xs"
                    >
                      <span>Buka Tab Penuh</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  )}
                </div>
              </div>

              {/* Form Input / Edit Tautan Simulasi Guru */}
              {isEditingTeacherLink && (
                <div className="p-5 mx-5 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 space-y-3">
                  <h4 className="text-xs font-black uppercase text-slate-600 dark:text-slate-300">
                    Input / Perbarui Tautan Simulasi Guru (Tersimpan ke Firebase)
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-bold text-slate-600 mb-1">
                        Judul Simulasi Guru
                      </label>
                      <input
                        type="text"
                        value={newTeacherTitleInput}
                        onChange={(e) => setNewTeacherTitleInput(e.target.value)}
                        placeholder="Contoh: Simulator Kalorimeter Interaktif PhET"
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white dark:bg-slate-900"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-slate-600 mb-1">
                        URL / Link Simulator Web (PhET, GeoGebra, simulator HTML, dll.)
                      </label>
                      <input
                        type="url"
                        value={newTeacherUrlInput}
                        onChange={(e) => setNewTeacherUrlInput(e.target.value)}
                        placeholder="https://phet.colorado.edu/... atau https://geogebra.org/..."
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white dark:bg-slate-900"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      Panduan & Petunjuk Kerja untuk Siswa
                    </label>
                    <textarea
                      rows={2}
                      value={newTeacherGuideInput}
                      onChange={(e) => setNewTeacherGuideInput(e.target.value)}
                      placeholder="Petunjuk: 1. Amati suhu awal; 2. Nyalakan sumber panas; 3. Ambil data setiap 30 detik..."
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-xs bg-white dark:bg-slate-900"
                    />
                  </div>
                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      onClick={handleSaveTeacherLinkCustom}
                      disabled={isSavingTeacherLink}
                      className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>{isSavingTeacherLink ? 'Menyimpan...' : 'Simpan Tautan ke Firebase'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Frame Tampilan Simulasi Guru */}
              <div className="p-5 pt-0">
                {teacherLink ? (
                  <div className="rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-inner bg-slate-950">
                    <div className="h-[520px] w-full relative">
                      <iframe
                        src={teacherLink}
                        title={teacherSimTitle || 'Simulasi Guru'}
                        className="w-full h-full border-0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      />
                    </div>
                  </div>
                ) : (
                  <div className="py-16 text-center space-y-3 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-300 p-6">
                    <BookOpen className="w-10 h-10 text-amber-600 mx-auto" />
                    <h4 className="text-sm font-black text-slate-800 dark:text-white">
                      Belum Ada Tautan Simulasi Khusus dari Guru
                    </h4>
                    <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
                      Guru dapat mengirimkan tautan simulator virtual (PhET, GeoGebra, atau simulator web interaktif). Siswa atau Guru dapat mengklik tombol "Kelola Tautan Guru" untuk memasukkan URL simulator.
                    </p>
                    <button
                      onClick={() => setIsEditingTeacherLink(true)}
                      className="px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs shadow-xs hover:bg-amber-600 cursor-pointer"
                    >
                      + Tambahkan Tautan Simulasi Guru
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* =========================================================================
              PILIHAN 2: SIMULASI APLIKASI (AI Bertindak sebagai Pembuat Simulasi Virtual)
              - Materi Suhu dan Kalor: gambar air dalam gelas ukur dan pengukur suhu
              - Materi Listrik: rangkaian listrik yang dapat dipraktekkan secara maya
              - Materi Regresi Linear: tabel dan diagram pencar serta line of best fit dan analisis
              ========================================================================= */}
          {activeSimulasiMode === 'APLIKASI' && (
            <div className="space-y-6">
              {/* -----------------------------------------------------------------
                  KASUS 1: MATERI SUHU DAN KALOR (Fisika / Kimia)
                  - Gambar air dalam gelas ukur / kalorimeter
                  - Pengukur suhu (termometer probe digital + analog)
                  - Pemanas dengan pengatur watt, rumus Q = mcΔT, grafik real-time
                  ----------------------------------------------------------------- */}
              {selectedMateri === 'suhu_kalor' && (
                <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-6 space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
                    <div>
                      <span className="px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-800 text-[10px] font-black uppercase">
                        Simulasi AI: Fisika Termal
                      </span>
                      <h3 className="text-base font-black text-slate-900 dark:text-white mt-1 flex items-center gap-2">
                        <Thermometer className="w-5 h-5 text-rose-600" />
                        <span>Simulasi Kalorimeter: Air dalam Gelas Ukur & Termometer</span>
                      </h3>
                      <p className="text-xs text-slate-500">
                        Amati perubahan suhu air secara mikroskopis dan termometris seiring energi kalor yang diberikan: <code className="font-mono text-rose-600 font-bold">Q = m · c · ΔT</code>
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleRecordDataSuhu}
                        className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
                      >
                        <Plus className="w-4 h-4 stroke-[3]" />
                        <span>Catat ke Tabel</span>
                      </button>
                    </div>
                  </div>

                  {/* Stage Simulasi Visual: Air dalam Gelas Ukur & Termometer */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
                    {/* Visual Bejana Gelas Ukur & Termometer */}
                    <div className="lg:col-span-6 bg-gradient-to-b from-slate-900 to-slate-950 rounded-3xl p-6 border border-slate-800 flex flex-col items-center justify-center relative min-h-[380px] overflow-hidden">
                      {/* Layar Digital Suhu (LCD Termometer Digital) */}
                      <div className="absolute top-4 right-4 bg-slate-900/90 border border-slate-700 px-3 py-1.5 rounded-xl font-mono text-center shadow-md">
                        <span className="block text-[9px] uppercase tracking-wider text-slate-400 font-sans">
                          Probe Termometer
                        </span>
                        <span className="text-xl font-black text-rose-400">
                          {waterTemp.toFixed(1)}°C
                        </span>
                      </div>

                      {/* Visual Termometer Batang Kaca Analog (Kiri) */}
                      <div className="absolute left-6 top-10 bottom-16 w-5 bg-slate-800 rounded-full p-0.5 border border-slate-700 flex flex-col justify-end items-center">
                        <div
                          className="w-3 bg-gradient-to-t from-rose-600 to-red-400 rounded-full transition-all duration-300"
                          style={{
                            height: `${Math.min(100, Math.max(10, ((waterTemp - 20) / 80) * 100))}%`,
                          }}
                        />
                        <div className="w-5 h-5 rounded-full bg-rose-600 -mb-1 shadow-xs"></div>
                        <span className="text-[8px] font-mono text-slate-400 mt-2">°C</span>
                      </div>

                      {/* Gelas Ukur / Bejana Kalorimeter */}
                      <div className="relative w-48 h-64 border-4 border-t-0 border-slate-400/60 rounded-b-3xl bg-slate-800/30 flex flex-col justify-end p-2 overflow-hidden shadow-2xl backdrop-blur-xs">
                        {/* Skala Ukur Garis-Garis Gelas Ukur */}
                        <div className="absolute right-2 top-4 bottom-4 flex flex-col justify-between text-[8px] font-mono text-slate-500 pointer-events-none select-none">
                          <span>— 250 mL</span>
                          <span>— 200 mL</span>
                          <span>— 150 mL</span>
                          <span>— 100 mL</span>
                          <span>— 50 mL</span>
                        </div>

                        {/* Probe Sensor yang Tercelup ke Air */}
                        <div className="absolute top-0 left-12 w-2 h-44 bg-slate-400 rounded-b-md z-20 shadow-md border border-slate-500 flex flex-col justify-end items-center">
                          <div className="w-2.5 h-6 bg-rose-500 rounded-b-sm"></div>
                        </div>

                        {/* Batang Pengaduk */}
                        <div className="absolute top-0 left-24 w-1.5 h-48 bg-cyan-200/60 rounded-b-full z-20 shadow-xs transform rotate-2"></div>

                        {/* Cairan Air di dalam Gelas Ukur */}
                        <div
                          className={`w-full rounded-b-2xl transition-all duration-500 relative overflow-hidden flex items-center justify-center ${
                            waterTemp > 75
                              ? 'bg-gradient-to-t from-orange-500/80 via-amber-500/70 to-yellow-400/60'
                              : waterTemp > 45
                              ? 'bg-gradient-to-t from-amber-500/80 via-cyan-500/70 to-blue-400/60'
                              : 'bg-gradient-to-t from-blue-600/80 via-cyan-500/70 to-sky-400/60'
                          }`}
                          style={{
                            height: `${(waterVolume / 250) * 85}%`,
                          }}
                        >
                          {/* Gelembung Udara saat mendidih atau dipanaskan */}
                          {heaterOn && (
                            <div className="absolute inset-0 pointer-events-none flex justify-around">
                              <span className="w-2 h-2 rounded-full bg-white/60 animate-bounce delay-100 mt-12"></span>
                              <span className="w-1.5 h-1.5 rounded-full bg-white/70 animate-ping delay-300 mt-20"></span>
                              <span className="w-2.5 h-2.5 rounded-full bg-white/50 animate-bounce delay-200 mt-6"></span>
                            </div>
                          )}
                          <span className="text-[11px] font-bold text-white/90 z-10 font-mono drop-shadow-md">
                            Air {waterVolume} mL
                          </span>
                        </div>
                      </div>

                      {/* Elemen Pemanas Kompor / Heater di Bawah Gelas */}
                      <div
                        className={`w-56 h-7 rounded-t-xl border-t-2 transition-all duration-300 flex items-center justify-center gap-1 mt-1 ${
                          heaterOn
                            ? 'bg-gradient-to-r from-red-600 via-orange-500 to-red-600 border-red-400 shadow-lg shadow-orange-500/50'
                            : 'bg-slate-800 border-slate-700'
                        }`}
                      >
                        <span className="text-[9px] font-black uppercase tracking-wider text-white">
                          {heaterOn ? `🔥 HEATER AKTIF (${heaterPower} WATT)` : 'HEATER STANDBY'}
                        </span>
                      </div>
                    </div>

                    {/* Kontrol & Panel Instrumen Simulasi */}
                    <div className="lg:col-span-6 space-y-4">
                      <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-black uppercase text-slate-500">
                            Kontrol Pemanas & Volume
                          </span>
                          <span className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300">
                            Waktu: {timerSeconds} detik
                          </span>
                        </div>

                        {/* Tombol ON / OFF Heater */}
                        <div className="flex items-center gap-3">
                          <button
                            onClick={() => setHeaterOn(!heaterOn)}
                            className={`flex-1 py-3 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
                              heaterOn
                                ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-md shadow-rose-500/25'
                                : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-md shadow-emerald-500/25'
                            }`}
                          >
                            {heaterOn ? <Square className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
                            <span>{heaterOn ? 'Matikan Pemanas (OFF)' : 'Nyalakan Pemanas (ON)'}</span>
                          </button>

                          <button
                            onClick={() => {
                              setHeaterOn(false);
                              setWaterTemp(25.0);
                              setTimerSeconds(0);
                              setCalorimeterDataPoints([{ t: 0, temp: 25.0 }]);
                            }}
                            className="px-3.5 py-3 rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 text-slate-700 dark:text-slate-200 text-xs font-bold"
                            title="Reset simulasi ke kondisi awal"
                          >
                            <RotateCcw className="w-4 h-4" />
                          </button>
                        </div>

                        {/* Slider Daya Pemanas */}
                        <div>
                          <div className="flex justify-between text-xs font-bold mb-1">
                            <span className="text-slate-600 dark:text-slate-400">Daya Pemanas (Watt):</span>
                            <span className="text-rose-600 font-mono">{heaterPower} Watt</span>
                          </div>
                          <input
                            type="range"
                            min="50"
                            max="500"
                            step="25"
                            value={heaterPower}
                            onChange={(e) => setHeaterPower(Number(e.target.value))}
                            className="w-full accent-rose-600"
                          />
                        </div>

                        {/* Slider Volume Air */}
                        <div>
                          <div className="flex justify-between text-xs font-bold mb-1">
                            <span className="text-slate-600 dark:text-slate-400">Volume Air (massa air m):</span>
                            <span className="text-cyan-600 font-mono">{waterVolume} mL (gram)</span>
                          </div>
                          <input
                            type="range"
                            min="50"
                            max="250"
                            step="10"
                            value={waterVolume}
                            disabled={heaterOn}
                            onChange={(e) => setWaterVolume(Number(e.target.value))}
                            className="w-full accent-cyan-600 disabled:opacity-50"
                          />
                        </div>
                      </div>

                      {/* Mini Kurva Kenaikan Suhu Real-time */}
                      <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
                        <div className="flex items-center justify-between text-xs font-black uppercase text-slate-500">
                          <span>Grafik Real-Time: Suhu (°C) vs Waktu (s)</span>
                          <span className="text-rose-600 font-mono font-bold">ΔT = +{(waterTemp - 25.0).toFixed(1)}°C</span>
                        </div>
                        <div className="h-24 w-full bg-slate-900 rounded-xl p-2 flex items-end gap-1 overflow-hidden">
                          {calorimeterDataPoints.map((pt, i) => (
                            <div
                              key={i}
                              className="flex-1 bg-rose-500 rounded-t-xs hover:bg-rose-400 transition-all min-w-[4px]"
                              style={{
                                height: `${Math.min(100, Math.max(10, ((pt.temp - 20) / 80) * 100))}%`,
                              }}
                              title={`t=${pt.t}s : ${pt.temp}°C`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* -----------------------------------------------------------------
                  KASUS 2: MATERI LISTRIK (Fisika / MIPA)
                  - AI membuat rangkaian listrik yang dapat dipraktekkan secara maya
                  - Baterai V, saklar ON/OFF, resistor/lampu R, ampermeter & voltmeter
                  ----------------------------------------------------------------- */}
              {selectedMateri === 'listrik' && (
                <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-6 space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
                    <div>
                      <span className="px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-[10px] font-black uppercase">
                        Simulasi AI: Listrik Dinamis & Hukum Ohm
                      </span>
                      <h3 className="text-base font-black text-slate-900 dark:text-white mt-1 flex items-center gap-2">
                        <Zap className="w-5 h-5 text-indigo-600" />
                        <span>Laboratorium Rangkaian Listrik Virtual Maya</span>
                      </h3>
                      <p className="text-xs text-slate-500">
                        Praktekkan hubungan tegangan, hambatan, dan kuat arus listrik secara maya: <code className="font-mono text-indigo-600 font-bold">V = I · R</code> & <code className="font-mono text-amber-600 font-bold">P = V · I</code>
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleRecordDataListrik}
                        className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
                      >
                        <Plus className="w-4 h-4 stroke-[3]" />
                        <span>Catat Pengukuran Listrik</span>
                      </button>
                    </div>
                  </div>

                  {/* Visual Canvas Rangkaian Listrik */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
                    {/* Skema Visual Rangkaian Interaktif */}
                    <div className="lg:col-span-7 bg-slate-950 rounded-3xl p-6 border border-slate-800 min-h-[360px] flex flex-col justify-between relative overflow-hidden">
                      {/* Meteran Display Digital di Atas Rangkaian */}
                      <div className="flex items-center justify-between gap-2 z-10">
                        {/* Voltmeter */}
                        <div className="bg-slate-900/90 border border-slate-700 px-3 py-1.5 rounded-xl font-mono text-center">
                          <span className="block text-[8px] uppercase tracking-wider text-slate-400">
                            Voltmeter (V)
                          </span>
                          <span className="text-lg font-black text-cyan-400">{voltage.toFixed(1)} V</span>
                        </div>

                        {/* Ampermeter */}
                        <div className="bg-slate-900/90 border border-slate-700 px-3 py-1.5 rounded-xl font-mono text-center">
                          <span className="block text-[8px] uppercase tracking-wider text-slate-400">
                            Ampermeter (I)
                          </span>
                          <span className="text-lg font-black text-indigo-400">
                            {currentMilliAmp} mA
                          </span>
                        </div>

                        {/* Daya Listrik */}
                        <div className="bg-slate-900/90 border border-slate-700 px-3 py-1.5 rounded-xl font-mono text-center">
                          <span className="block text-[8px] uppercase tracking-wider text-slate-400">
                            Daya Lampu (P)
                          </span>
                          <span className="text-lg font-black text-amber-400">
                            {electricPowerWatt} W
                          </span>
                        </div>
                      </div>

                      {/* Gambar Rangkaian Loop Maya (Kawat Penghantar) */}
                      <div className="my-6 relative h-48 border-4 border-cyan-500/70 rounded-2xl p-4 flex items-center justify-between">
                        {/* Arus Elektron Animasi */}
                        {circuitClosed && (
                          <div className="absolute inset-0 pointer-events-none flex items-center justify-around overflow-hidden">
                            <span className="w-2 h-2 rounded-full bg-cyan-300 animate-ping"></span>
                            <span className="w-2 h-2 rounded-full bg-cyan-300 animate-ping delay-150"></span>
                            <span className="w-2 h-2 rounded-full bg-cyan-300 animate-ping delay-300"></span>
                          </div>
                        )}

                        {/* Baterai (Sisi Kiri) */}
                        <div className="flex flex-col items-center gap-1 bg-slate-900 p-2.5 rounded-xl border border-slate-700 z-10">
                          <div className="w-10 h-16 bg-gradient-to-b from-amber-500 to-amber-700 rounded-md flex flex-col justify-between p-1 items-center shadow-lg">
                            <span className="text-[9px] font-black text-white">+</span>
                            <span className="text-[10px] font-black text-white font-mono">{voltage}V</span>
                            <span className="text-[9px] font-black text-white">-</span>
                          </div>
                          <span className="text-[9px] font-bold text-slate-300">Baterai</span>
                        </div>

                        {/* Saklar Interaktif (Tengah Atas) */}
                        <button
                          onClick={() => setCircuitClosed(!circuitClosed)}
                          className={`px-4 py-2 rounded-xl font-black text-xs flex items-center gap-2 shadow-lg transition-all cursor-pointer z-10 ${
                            circuitClosed
                              ? 'bg-emerald-500 text-slate-950 hover:bg-emerald-400 shadow-emerald-500/30'
                              : 'bg-rose-600 text-white hover:bg-rose-500 shadow-rose-600/30'
                          }`}
                        >
                          {circuitClosed ? <ToggleRight className="w-5 h-5" /> : <ToggleLeft className="w-5 h-5" />}
                          <span>{circuitClosed ? 'Saklar TERTUTUP (ON)' : 'Saklar TERBUKA (OFF)'}</span>
                        </button>

                        {/* Lampu Pijar / Resistor (Sisi Kanan) */}
                        <div className="flex flex-col items-center gap-1 bg-slate-900 p-2.5 rounded-xl border border-slate-700 z-10">
                          <div
                            className={`w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 border-2 ${
                              circuitClosed && currentMilliAmp > 0
                                ? 'bg-amber-300 border-amber-400 shadow-2xl shadow-yellow-300 text-slate-950 scale-105'
                                : 'bg-slate-800 border-slate-600 text-slate-500'
                            }`}
                          >
                            <Lightbulb className="w-8 h-8" />
                          </div>
                          <span className="text-[9px] font-bold text-slate-300">
                            Lampu ({resistance} Ω)
                          </span>
                        </div>
                      </div>

                      <div className="text-center text-[10px] text-slate-400">
                        {circuitClosed
                          ? '⚡ Rangkaian tertutup: Elektron mengalir melalui kawat, lampu berpijar sesuai kuat arus.'
                          : '⚠️ Rangkaian terbuka: Saklar mati, tidak ada arus listrik yang mengalir.'}
                      </div>
                    </div>

                    {/* Kontrol Parameter Listrik */}
                    <div className="lg:col-span-5 space-y-4">
                      <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-4">
                        <h4 className="text-xs font-black uppercase text-slate-500">
                          Pengaturan Komponen Rangkaian
                        </h4>

                        {/* Slider Tegangan Baterai */}
                        <div>
                          <div className="flex justify-between text-xs font-bold mb-1">
                            <span className="text-slate-600 dark:text-slate-400">Tegangan Baterai (V):</span>
                            <span className="text-cyan-600 font-mono font-black">{voltage} Volt</span>
                          </div>
                          <input
                            type="range"
                            min="1.5"
                            max="24"
                            step="0.5"
                            value={voltage}
                            onChange={(e) => setVoltage(Number(e.target.value))}
                            className="w-full accent-cyan-600"
                          />
                          <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-0.5">
                            <span>1.5 V (Baterai AA)</span>
                            <span>9.0 V</span>
                            <span>24.0 V (Aki)</span>
                          </div>
                        </div>

                        {/* Slider Hambatan Lampu / Resistor */}
                        <div>
                          <div className="flex justify-between text-xs font-bold mb-1">
                            <span className="text-slate-600 dark:text-slate-400">Hambatan Resistor / Lampu (R):</span>
                            <span className="text-amber-600 font-mono font-black">{resistance} Ohm (Ω)</span>
                          </div>
                          <input
                            type="range"
                            min="5"
                            max="200"
                            step="5"
                            value={resistance}
                            onChange={(e) => setResistance(Number(e.target.value))}
                            className="w-full accent-amber-600"
                          />
                          <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-0.5">
                            <span>5 Ω</span>
                            <span>100 Ω</span>
                            <span>200 Ω</span>
                          </div>
                        </div>

                        {/* Analisis Saintifik Singkat */}
                        <div className="p-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 text-[11px] space-y-1">
                          <strong className="text-indigo-900 dark:text-indigo-300 block font-black">
                            Hasil Analisis Hukum Ohm:
                          </strong>
                          <p className="text-slate-600 dark:text-slate-300">
                            I = {voltage}V / {resistance}Ω = <strong className="text-indigo-600 font-mono">{currentAmpere} A ({currentMilliAmp} mA)</strong>.
                            Kecerahan lampu berbanding lurus dengan daya disipasi <strong className="text-amber-600 font-mono">{electricPowerWatt} Watt</strong>.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* -----------------------------------------------------------------
                  KASUS 3: MATERI REGRESI LINEAR (Matematika / Matematika Lanjut)
                  - AI membuat tabel dan diagram pencar (scatter plot)
                  - Line of best fit (y = mx + c)
                  - Hasil analisis statistik lengkap (slope m, intercept c, r, R2)
                  ----------------------------------------------------------------- */}
              {selectedMateri === 'regresi_linear' && (
                <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-6 space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
                    <div>
                      <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-black uppercase">
                        Simulasi AI: Matematika & Analisis Data
                      </span>
                      <h3 className="text-base font-black text-slate-900 dark:text-white mt-1 flex items-center gap-2">
                        <LineChartIcon className="w-5 h-5 text-blue-600" />
                        <span>Diagram Pencar (Scatter Plot) & Line of Best Fit</span>
                      </h3>
                      <p className="text-xs text-slate-500">
                        AI menghitung persamaan regresi linear, koefisien korelasi Pearson (r), dan koefisien determinasi (R²) secara real-time dari data pasangan (X, Y).
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleRecordDataRegresi}
                        className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-black text-xs flex items-center gap-1.5 shadow-xs cursor-pointer"
                      >
                        <Plus className="w-4 h-4 stroke-[3]" />
                        <span>Catat Analisis ke Tabel</span>
                      </button>
                    </div>
                  </div>

                  {/* Stage Diagram Pencar & Analisis Statistik */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                    {/* Diagram Pencar (Scatter Plot) dengan Line of Best Fit */}
                    <div className="lg:col-span-7 bg-slate-950 rounded-3xl p-6 border border-slate-800 space-y-3">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-black text-slate-300 flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
                          <span>Diagram Pencar & Garis Regresi (Line of Best Fit)</span>
                        </span>
                        <span className="font-mono text-cyan-300 font-bold bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-700">
                          ŷ = {regressionStats.m}x + {regressionStats.c}
                        </span>
                      </div>

                      {/* SVG Canvas Scatter Plot */}
                      <div className="h-64 w-full bg-slate-900/90 rounded-2xl p-4 relative border border-slate-800 flex items-center justify-center">
                        <svg className="w-full h-full overflow-visible" viewBox="0 0 400 200">
                          {/* Grid lines */}
                          <line x1="40" y1="20" x2="40" y2="170" stroke="#334155" strokeWidth="1.5" />
                          <line x1="40" y1="170" x2="380" y2="170" stroke="#334155" strokeWidth="1.5" />

                          {/* Line of Best Fit */}
                          {scatterPoints.length >= 2 && (
                            <line
                              x1="40"
                              y1={170 - (regressionStats.m * 0 + regressionStats.c) * 1.5}
                              x2="380"
                              y2={170 - (regressionStats.m * 100 + regressionStats.c) * 1.5}
                              stroke="#06b6d4"
                              strokeWidth="2.5"
                              strokeDasharray="4 2"
                            />
                          )}

                          {/* Dots Scatter Points */}
                          {scatterPoints.map((pt, idx) => {
                            const cx = 40 + (pt.x / 100) * 340;
                            const cy = 170 - (pt.y / 100) * 150;
                            return (
                              <circle
                                key={idx}
                                cx={cx}
                                cy={cy}
                                r="5.5"
                                className="fill-amber-400 stroke-slate-950 stroke-2 hover:r-7 transition-all cursor-pointer"
                              >
                                <title>{`(${pt.x}, ${pt.y})`}</title>
                              </circle>
                            );
                          })}
                        </svg>

                        {/* Label Sumbu */}
                        <span className="absolute bottom-1 right-4 text-[10px] font-mono text-slate-400">
                          Variabel Bebas (X) →
                        </span>
                        <span className="absolute top-2 left-2 text-[10px] font-mono text-slate-400">
                          ↑ Variabel Terikat (Y)
                        </span>
                      </div>

                      <div className="text-center text-[11px] text-slate-400">
                        Titik kuning: Data pasangan observasi (X, Y) • Garis putus-putus biru: Line of Best Fit
                      </div>
                    </div>

                    {/* Hasil Analisis AI & Manipulasi Titik Data */}
                    <div className="lg:col-span-5 space-y-4">
                      {/* Box Hasil Analisis Statistik Lengkap */}
                      <div className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-slate-800 dark:to-slate-850 p-4 rounded-2xl border border-blue-200 dark:border-slate-700 space-y-3">
                        <h4 className="text-xs font-black uppercase text-blue-900 dark:text-blue-300 flex items-center gap-1.5">
                          <Calculator className="w-4 h-4 text-blue-600" />
                          <span>Hasil Analisis Statistik AI</span>
                        </h4>

                        <div className="grid grid-cols-2 gap-2">
                          <div className="bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700">
                            <span className="text-[10px] uppercase font-bold text-slate-400 block">
                              Gradien Kemiringan (m)
                            </span>
                            <span className="text-base font-black text-slate-900 dark:text-white font-mono">
                              {regressionStats.m}
                            </span>
                          </div>
                          <div className="bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700">
                            <span className="text-[10px] uppercase font-bold text-slate-400 block">
                              Konstanta Intersep (c)
                            </span>
                            <span className="text-base font-black text-slate-900 dark:text-white font-mono">
                              {regressionStats.c}
                            </span>
                          </div>
                          <div className="bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700">
                            <span className="text-[10px] uppercase font-bold text-slate-400 block">
                              Korelasi Pearson (r)
                            </span>
                            <span className="text-base font-black text-blue-600 font-mono">
                              {regressionStats.r}
                            </span>
                          </div>
                          <div className="bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700">
                            <span className="text-[10px] uppercase font-bold text-slate-400 block">
                              Determinasi (R²)
                            </span>
                            <span className="text-base font-black text-emerald-600 font-mono">
                              {(regressionStats.r2 * 100).toFixed(1)}%
                            </span>
                          </div>
                        </div>

                        {/* Interpretasi Narasi AI */}
                        <div className="bg-white/80 dark:bg-slate-900/80 p-3 rounded-xl border border-blue-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                          <strong className="text-blue-700 dark:text-blue-300 block mb-0.5">
                            💡 Interpretasi Saintifik:
                          </strong>
                          {regressionStats.r > 0.7 ? (
                            <span>
                              Terdapat hubungan linier <strong>positif yang sangat kuat</strong> antara variabel X dan Y. Setiap kenaikan 1 unit pada variabel X diproyeksikan menaikkan variabel Y sebesar {regressionStats.m} unit.
                            </span>
                          ) : (
                            <span>
                              Korelasi antar variabel bersifat moderat. Sebagian variansi dipengaruhi faktor lain.
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Form Tambah Titik Data (X, Y) */}
                      <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
                        <span className="text-xs font-black uppercase text-slate-500 block">
                          Tambah / Uji Coba Titik Data Baru
                        </span>
                        <div className="flex items-center gap-2">
                          <input
                            type="number"
                            placeholder="Nilai X (0-100)"
                            value={newPointX}
                            onChange={(e) => setNewPointX(e.target.value)}
                            className="w-1/2 px-3 py-1.5 rounded-xl border border-slate-300 text-xs bg-white dark:bg-slate-900"
                          />
                          <input
                            type="number"
                            placeholder="Nilai Y (0-100)"
                            value={newPointY}
                            onChange={(e) => setNewPointY(e.target.value)}
                            className="w-1/2 px-3 py-1.5 rounded-xl border border-slate-300 text-xs bg-white dark:bg-slate-900"
                          />
                          <button
                            onClick={() => {
                              const x = parseFloat(newPointX);
                              const y = parseFloat(newPointY);
                              if (!isNaN(x) && !isNaN(y)) {
                                setScatterPoints((prev) => [...prev, { x, y }].sort((a, b) => a.x - b.x));
                                setNewPointX('');
                                setNewPointY('');
                              }
                            }}
                            className="px-3.5 py-1.5 rounded-xl bg-blue-600 text-white font-bold text-xs hover:bg-blue-700 cursor-pointer"
                          >
                            Tambah
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* =========================================================================
              TABEL DATA PENGAMATAN SIMULASI VIRTUAL (Dapat disimpan ke Database Misi Siswa)
              ========================================================================= */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden space-y-4 p-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4 text-indigo-600" />
                  <span>Tabel Data Pengamatan Simulasi Virtual</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Data yang tercatat dari percobaan simulasi dapat disimpan langsung ke database misi siswa.
                </p>
              </div>

              <div className="flex items-center gap-2">
                {recordedRows.length > 0 && (
                  <button
                    id="btn-download-excel-simulasi"
                    onClick={handleExportExcel}
                    className="px-4 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all active:scale-95"
                    title="Download tabel dalam format Excel (.xlsx)"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Download Excel (.xlsx)</span>
                  </button>
                )}

                <button
                  id="btn-simpan-misi-simulasi"
                  onClick={handleSaveToStudentMission}
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-md shadow-emerald-600/20 flex items-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Simpan ke Database Misi Siswa</span>
                </button>

                {recordedRows.length > 0 && (
                  <button
                    onClick={() => setRecordedRows([])}
                    className="p-2 rounded-xl border border-rose-200 hover:bg-rose-50 text-rose-600 text-xs font-bold"
                    title="Hapus semua baris"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* Notifikasi Status Simpan */}
            {saveStatus.message && (
              <div
                className={`p-3 rounded-2xl text-xs font-bold flex items-center justify-between gap-2 ${
                  saveStatus.type === 'success'
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                    : saveStatus.type === 'error'
                    ? 'bg-rose-50 text-rose-800 border border-rose-300'
                    : 'bg-blue-50 text-blue-800 border border-blue-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  {saveStatus.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <Info className="w-4 h-4" />
                  )}
                  <span>{saveStatus.message}</span>
                </div>
                {saveStatus.type === 'success' && (
                  <a
                    href={STUDENT_DRIVE_FOLDER_URL}
                    target="_blank"
                    rel="noreferrer"
                    className="px-2 py-1 rounded-lg bg-emerald-600 text-white text-[10px] font-bold hover:bg-emerald-700 flex items-center gap-1"
                  >
                    <span>Folder Google Drive</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            )}

            {/* Tabel Isi */}
            {recordedRows.length === 0 ? (
              <div className="py-10 text-center space-y-2 bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-300 p-4">
                <FileSpreadsheet className="w-8 h-8 text-slate-400 mx-auto" />
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  Belum ada data pengamatan tercatat
                </h4>
                <p className="text-[11px] text-slate-400 max-w-sm mx-auto">
                  Jalankan simulasi di atas dan klik tombol "Catat ke Tabel" untuk mengumpulkan data hasil eksperimen.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-700">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-800 font-black uppercase text-slate-600 dark:text-slate-300 text-[10px]">
                    <tr>
                      <th className="p-3 w-12 text-center">No</th>
                      <th className="p-3">Parameter 1</th>
                      <th className="p-3">Parameter 2</th>
                      <th className="p-3">Parameter 3</th>
                      <th className="p-3">Keterangan / Kondisi</th>
                      <th className="p-3 w-12 text-center">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                    {recordedRows.map((row) => (
                      <tr key={row.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                        <td className="p-3 text-center font-bold text-slate-400">{row.no}</td>
                        <td className="p-3 font-mono font-bold text-indigo-600">{row.param1}</td>
                        <td className="p-3 font-mono font-bold text-rose-600">{row.param2}</td>
                        <td className="p-3 font-mono text-slate-700 dark:text-slate-300">{row.param3 || '-'}</td>
                        <td className="p-3">{row.catatan}</td>
                        <td className="p-3 text-center">
                          <button
                            onClick={() =>
                              setRecordedRows((prev) =>
                                prev.filter((r) => r.id !== row.id).map((r, idx) => ({ ...r, no: idx + 1 }))
                              )
                            }
                            className="text-slate-300 hover:text-rose-600"
                            title="Hapus baris"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {onFinishExperiment && (
        <div className="flex justify-end pt-3">
          <button
            id="btn-selesai-eksperimen-virtual-lab"
            type="button"
            onClick={onFinishExperiment}
            className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-700 hover:to-cyan-700 text-white font-black text-xs sm:text-sm shadow-md flex items-center gap-2 cursor-pointer transition-all active:scale-95"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-200" />
            <span>Selesai Eksperimen & Buka Misi 4</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};
