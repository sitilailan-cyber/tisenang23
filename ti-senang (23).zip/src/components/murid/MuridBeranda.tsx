import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Users,
  Eye,
  Heart,
  Calendar,
  FlaskConical,
  Zap,
  X,
  Search,
  Upload,
  Camera,
  ExternalLink,
  MessageSquare,
} from 'lucide-react';
import { PortfolioItem } from '../../types';
import { storage } from '../../services/storage';
import { UploadPortfolioModal } from './UploadPortfolioModal';

import studentCalorimeterPhoto from '../../assets/images/student_physics_calorimeter_1789115270932.jpg';
import studentRegressionPhoto from '../../assets/images/student_data_regression_1789115288218.jpg';
import studentChemPhoto from '../../assets/images/student_chem_experiment_1789115301650.jpg';
import studentBioPhoto from '../../assets/images/student_bio_project_1789115315113.jpg';

interface MuridBerandaProps {
  className: string;
  classPortfolios: PortfolioItem[];
  onOpenDetail?: (item: PortfolioItem) => void;
  studentId?: string;
  studentName?: string;
  classId?: string;
  onRefreshPortfolios?: () => void;
}

export const MuridBeranda: React.FC<MuridBerandaProps> = ({
  className,
  classPortfolios,
  onOpenDetail,
  studentId = 'std-current',
  studentName = 'Siswa MIPA',
  classId = 'cls-xii-1',
  onRefreshPortfolios,
}) => {
  const [likes, setLikes] = useState<Record<string, number>>({});
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');
  const [activeModalItem, setActiveModalItem] = useState<PortfolioItem | null>(null);
  const [showUploadModal, setShowUploadModal] = useState<boolean>(false);
  const [newCommentText, setNewCommentText] = useState<string>('');

  // Sinkronisasi Real-time saat ada update portofolio dari Firebase
  useEffect(() => {
    const handleUpdate = () => {
      if (onRefreshPortfolios) onRefreshPortfolios();
    };
    window.addEventListener('tisenang_portfolios_updated', handleUpdate);
    return () => window.removeEventListener('tisenang_portfolios_updated', handleUpdate);
  }, [onRefreshPortfolios]);

  const handleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    storage.likePortfolio(id, studentId);
    setLikes((prev) => ({ ...prev, [id]: (prev[id] || 0) + 1 }));
    if (onRefreshPortfolios) onRefreshPortfolios();
  };

  const handleSendComment = (portfolioId: string) => {
    if (!newCommentText.trim()) return;
    storage.commentPortfolio(portfolioId, {
      authorName: studentName || 'Siswa MIPA',
      text: newCommentText.trim(),
    });
    setNewCommentText('');
    if (onRefreshPortfolios) onRefreshPortfolios();
    // Update active modal view with fresh comments
    const updated = storage.getAllPortfolios().find((p) => p.id === portfolioId);
    if (updated) setActiveModalItem(updated);
  };

  const handleOpenItem = (item: PortfolioItem) => {
    if (onOpenDetail) {
      onOpenDetail(item);
    } else {
      setActiveModalItem(item);
    }
  };

  // Helper to obtain authentic documentation photo (prioritizes uploaded photo or authentic student lab documentation)
  const getPortfolioImage = (item: PortfolioItem): string => {
    if (
      item.documentation &&
      typeof item.documentation === 'string' &&
      item.documentation.trim() !== '' &&
      !item.documentation.includes('misi_') &&
      !item.documentation.includes('logo')
    ) {
      if (
        item.documentation.startsWith('data:image') ||
        item.documentation.startsWith('http') ||
        item.documentation.startsWith('/') ||
        item.documentation.startsWith('blob:')
      ) {
        return item.documentation;
      }
    }

    const title = (item.title || '').toLowerCase();
    const cat = (item.category || '').toLowerCase();
    const subject = (item.subjectName || '').toLowerCase();

    if (
      title.includes('regresi') ||
      title.includes('matematika') ||
      title.includes('grafik') ||
      title.includes('bivariat') ||
      subject.includes('matematika')
    ) {
      return studentRegressionPhoto;
    }
    if (
      title.includes('kimia') ||
      title.includes('reaksi') ||
      title.includes('termokimia') ||
      title.includes('larutan') ||
      subject.includes('kimia')
    ) {
      return studentChemPhoto;
    }
    if (
      title.includes('biologi') ||
      title.includes('daun') ||
      title.includes('stomata') ||
      title.includes('transpirasi') ||
      title.includes('tanaman') ||
      subject.includes('biologi')
    ) {
      return studentBioPhoto;
    }
    if (
      title.includes('kalorimeter') ||
      title.includes('radiasi') ||
      title.includes('suhu') ||
      title.includes('kalor') ||
      subject.includes('fisika')
    ) {
      return studentCalorimeterPhoto;
    }

    if (cat.includes('analisis') || cat.includes('data')) return studentRegressionPhoto;
    if (cat.includes('proyek')) return studentBioPhoto;
    if (cat.includes('refleksi')) return studentChemPhoto;
    return studentCalorimeterPhoto;
  };

  // Helper to obtain concise learning objective (Tujuan Pembelajaran)
  const getTujuanPembelajaran = (item: PortfolioItem): string => {
    if (item.reflectionSummary && item.reflectionSummary.startsWith('[Tujuan: ')) {
      const match = item.reflectionSummary.match(/\[Tujuan:\s*([^\]]+)\]/);
      if (match && match[1]) {
        return match[1];
      }
    }
    if (item.missionId) {
      const missions = storage.getMissionsByClass(item.classId || 'cls-xii-1');
      const mission = missions.find((m) => m.id === item.missionId);
      if (mission?.tpCode && mission?.title) {
        return `${mission.tpCode}: ${mission.title}`;
      }
    }
    const tps = storage.getTujuanPembelajaran(item.subjectId);
    if (tps && tps.length > 0) {
      return `${tps[0].code}: ${tps[0].title}`;
    }
    if (
      item.title.toLowerCase().includes('kalorimeter') ||
      item.title.toLowerCase().includes('radiasi')
    ) {
      return 'TP-FIS-01: Menyelidiki pengaruh radiasi kalor terhadap laju kenaikan suhu fluida.';
    }
    if (
      item.title.toLowerCase().includes('regresi') ||
      item.title.toLowerCase().includes('linear')
    ) {
      return 'TP-MAT-01: Memodelkan data pengamatan eksperimen dengan persamaan regresi linear.';
    }
    return 'TP-01: Menganalisis dan mengaplikasikan konsep saintifik dalam penyelidikan terarah.';
  };

  // Helper to get clean report text without [Tujuan: ...] prefix
  const getCleanReportText = (text?: string): string => {
    if (!text) return '';
    return text.replace(/^\[Tujuan:\s*[^\]]+\]\s*/, '');
  };

  const categories = ['Semua', 'Eksperimen', 'Refleksi', 'Proyek MIPA'];

  const filteredPortfolios = classPortfolios.filter((item) => {
    const matchesCategory =
      selectedCategory === 'Semua' || item.category === selectedCategory;
    const matchesSearch =
      (item.title || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.studentName || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.reflectionSummary || '').toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const firstName = (studentName || 'Siswa').split(' ')[0];

  return (
    <div className="space-y-5 max-w-5xl mx-auto pb-8 animate-page-fade-up">
      {/* =========================================================================
          1. WELCOME DASHBOARD HEADER (Futuristic Welcome Student Dashboard)
          ========================================================================= */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#060c24] via-[#0d1c4f] to-[#201048] p-5 sm:p-7 text-white shadow-[0_18px_50px_rgba(2,6,23,0.38),0_0_35px_rgba(59,130,246,0.12)] border border-indigo-500/30">
        {/* Holographic light border accent on top edge */}
        <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-transparent via-cyan-400/60 to-transparent pointer-events-none" />

        {/* Delicate digital grid overlay */}
        <div className="absolute inset-0 bg-[radial-gradient(#38bdf814_1px,transparent_1px)] [background-size:22px_22px] pointer-events-none opacity-60" />

        {/* Dynamic ambient glowing orbs */}
        <div className="absolute -top-20 -left-16 w-72 h-72 rounded-full bg-cyan-500/16 blur-3xl pointer-events-none animate-pulse-subtle" />
        <div className="absolute -bottom-20 -right-16 w-80 h-80 rounded-full bg-fuchsia-600/16 blur-3xl pointer-events-none" />
        <div className="absolute top-1/2 left-1/3 w-56 h-56 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />

        {/* Abstract flowing waves - Futuristic delicate vector curves */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-30 animate-wave-float">
          <svg viewBox="0 0 1200 160" preserveAspectRatio="none" className="w-full h-full">
            <defs>
              <linearGradient id="berandaWaveGrad1" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.05" />
                <stop offset="40%" stopColor="#38bdf8" stopOpacity="0.3" />
                <stop offset="70%" stopColor="#818cf8" stopOpacity="0.35" />
                <stop offset="100%" stopColor="#c084fc" stopOpacity="0.05" />
              </linearGradient>
              <linearGradient id="berandaWaveGrad2" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#818cf8" stopOpacity="0.05" />
                <stop offset="50%" stopColor="#38bdf8" stopOpacity="0.25" />
                <stop offset="100%" stopColor="#f472b6" stopOpacity="0.05" />
              </linearGradient>
            </defs>
            <path
              d="M 0 90 C 250 145, 550 35, 850 95 C 1020 130, 1120 60, 1200 85"
              fill="none"
              stroke="url(#berandaWaveGrad1)"
              strokeWidth="1.6"
            />
            <path
              d="M 0 115 C 300 55, 600 155, 900 80 C 1040 45, 1140 120, 1200 100"
              fill="none"
              stroke="url(#berandaWaveGrad2)"
              strokeWidth="1.2"
              strokeDasharray="4 6"
            />
          </svg>
        </div>

        {/* Content Container (Compact, Tidy, and Balanced) */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5 relative z-10">
          <div className="space-y-2 max-w-xl">
            {/* Live Indicator & Class Welcome Badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900/75 backdrop-blur-md border border-cyan-400/30 text-[11px] font-mono font-bold text-cyan-300 shadow-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <Users className="w-3.5 h-3.5 text-cyan-300" />
              <span className="tracking-wide">DASHBOARD SISWA • KELAS {className || 'XII-1'} MIPA</span>
            </div>

            {/* Welcoming Title */}
            <h1 className="text-2xl sm:text-3xl font-display font-black tracking-tight text-white drop-shadow-sm leading-tight">
              Selamat Datang, <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-blue-200 to-indigo-200">{firstName}</span>!
            </h1>

            {/* Short Engaging Subtitle */}
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-normal">
              Eksplorasi dokumentasi riset saintifik terverifikasi teman sekelas dan bagikan hasil eksperimenmu.
            </p>
          </div>

          {/* Right: Quick Stat Chips & Action Button */}
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-3 shrink-0">
            {/* Stat Pill: Karya Terpublikasi */}
            <div className="inline-flex items-center gap-2.5 px-3.5 py-2 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 shadow-inner hover:bg-white/15 transition-all">
              <div className="w-7 h-7 rounded-xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-amber-300 animate-pulse-subtle" />
              </div>
              <div>
                <div className="flex items-baseline gap-1.5 leading-none">
                  <span className="font-display font-black text-white text-base">
                    {classPortfolios.length}
                  </span>
                  <span className="text-[11px] font-medium text-slate-300">Karya</span>
                </div>
                <span className="text-[10px] text-blue-200/90 font-medium">Terpublikasi</span>
              </div>
            </div>

            {/* Action Button: Upload Portofolio dengan Soft Glow */}
            <button
              type="button"
              id="btn-upload-portofolio-beranda"
              onClick={() => setShowUploadModal(true)}
              className="inline-flex items-center gap-2 px-4.5 py-2.5 rounded-2xl bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-400 hover:from-cyan-300 hover:to-blue-300 text-slate-950 font-display font-black text-xs sm:text-sm shadow-[0_0_20px_rgba(56,189,248,0.35)] hover:shadow-[0_0_28px_rgba(56,189,248,0.55)] transition-all duration-200 active:scale-95 cursor-pointer border border-cyan-200/60 shrink-0 group"
            >
              <Upload className="w-4 h-4 text-slate-950 transition-transform group-hover:-translate-y-0.5" />
              <span>Upload Portofolio</span>
            </button>
          </div>
        </div>
      </div>

      {/* =========================================================================
          2. FILTER & SEARCH CONTROLS (Compact & Refined Navigation)
          ========================================================================= */}
      <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-2.5 sm:p-3 border border-slate-200/90 shadow-xs hover:border-slate-300 transition-all flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 scrollbar-none">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`min-h-[36px] px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all duration-200 cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xs'
                    : 'bg-slate-100/90 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>

        {/* Search Box with Clear Icon */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari karya, siswa, atau topik..."
            className="w-full pl-9 pr-8 py-1.5 rounded-xl border border-slate-200 text-xs text-slate-800 placeholder-slate-400 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:outline-none transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 rounded-full hover:bg-slate-100 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* =========================================================================
          3. PORTFOLIOS FEED GRID (Modern Scientific Showcase Cards)
          ========================================================================= */}
      {filteredPortfolios.length === 0 ? (
        <div className="bg-white rounded-3xl p-10 sm:p-12 border border-slate-200/90 text-center space-y-3 shadow-xs">
          <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 mx-auto flex items-center justify-center shadow-inner">
            <Users className="w-7 h-7" />
          </div>
          <h3 className="font-display font-bold text-slate-800 text-base">
            Tidak Ada Karya yang Ditemukan
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto leading-relaxed">
            {searchQuery
              ? `Tidak ada hasil pencarian untuk "${searchQuery}". Coba kata kunci atau nama siswa lain.`
              : `Belum ada portofolio yang dibagikan untuk kategori ${selectedCategory}.`}
          </p>
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="px-4 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all cursor-pointer inline-flex items-center gap-1.5"
            >
              <X className="w-3.5 h-3.5" />
              <span>Reset Pencarian</span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
          {filteredPortfolios.map((item) => {
            const likeCount = (likes[item.id] || 0) + (item.id === 'pf-01' ? 4 : 2);
            return (
              <div
                key={item.id}
                id={`classmate-portfolio-${item.id}`}
                className="bg-white rounded-3xl p-4 sm:p-4.5 border border-slate-200/85 shadow-[0_4px_20px_rgba(0,0,0,0.03)] hover:shadow-[0_12px_30px_rgba(37,99,235,0.12)] hover:-translate-y-1.5 hover:border-indigo-300/75 transition-all duration-300 flex flex-col justify-between group relative overflow-hidden"
              >
                {/* Micro top gradient accent line on hover */}
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-400 via-indigo-500 to-violet-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                <div className="space-y-3">
                  {/* Bagian Atas: Foto Dokumentasi + Badges */}
                  <div className="relative aspect-[16/10] w-full rounded-2xl overflow-hidden bg-slate-100 border border-slate-200/60 shadow-inner">
                    <img
                      src={getPortfolioImage(item)}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                      referrerPolicy="no-referrer"
                    />
                    {/* Soft gradient vignette for contrast */}
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/50 via-transparent to-slate-950/15 pointer-events-none" />

                    {/* Overlay Badges */}
                    <div className="absolute top-2.5 left-2.5 flex flex-wrap items-center gap-1.5 z-10">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-slate-950/80 backdrop-blur-md text-white border border-white/20 shadow-sm">
                        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse-subtle" />
                        {item.category || 'Eksperimen'}
                      </span>
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-600/90 backdrop-blur-md text-white border border-emerald-400/40 shadow-sm">
                        <Camera className="w-3 h-3" />
                        Dokumentasi Siswa
                      </span>
                      {item.driveLink && (
                        <a
                          href={item.driveLink}
                          target="_blank"
                          rel="noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-600/90 backdrop-blur-md text-white border border-blue-400/40 shadow-sm hover:bg-blue-500 transition-colors"
                          title="Buka File di Google Drive"
                        >
                          <ExternalLink className="w-2.5 h-2.5" />
                          <span>Google Drive</span>
                        </a>
                      )}
                    </div>
                  </div>

                  {/* Bagian Isi: Penulis, Mata Pelajaran, Judul, Tujuan Pembelajaran */}
                  <div className="space-y-1.5 px-0.5">
                    {/* Penulis & Mata Pelajaran */}
                    <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                      <span className="text-blue-700 font-extrabold capitalize">{item.studentName || 'Siswa MIPA'}</span>
                      <span className="text-slate-300">•</span>
                      <span className="truncate text-slate-500 font-medium">
                        {item.subjectName || 'Fisika Eksperimental'}
                      </span>
                    </div>

                    {/* Judul Portofolio */}
                    <h2 className="font-display font-bold text-slate-900 text-base leading-snug group-hover:text-blue-600 transition-colors line-clamp-2">
                      {item.title}
                    </h2>

                    {/* Tujuan Pembelajaran (Compact Container) */}
                    <div className="bg-slate-50/90 rounded-xl p-2.5 border border-slate-100 text-xs text-slate-600 leading-relaxed line-clamp-2 flex items-start gap-1.5">
                      <span className="shrink-0 text-slate-400">🎯</span>
                      <span className="font-medium">
                        <strong className="text-slate-700 font-semibold">Tujuan:</strong>{' '}
                        {getTujuanPembelajaran(item)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Bagian Bawah: Tombol Like, XP Badge, Tombol "Lihat Laporan" */}
                <div className="mt-4 pt-3 border-t border-slate-100/90 flex items-center justify-between gap-2">
                  {/* Left: Like & XP */}
                  <div className="flex items-center gap-2">
                    <button
                      id={`btn-like-portfolio-${item.id}`}
                      onClick={(e) => handleLike(item.id, e)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100/90 hover:bg-rose-50 text-slate-600 hover:text-rose-600 border border-slate-200/60 hover:border-rose-200 text-xs font-bold transition-all active:scale-90 cursor-pointer shadow-2xs"
                      title="Sukai karya ini"
                    >
                      <Heart className="w-3.5 h-3.5 fill-rose-100 text-rose-500 transition-transform active:scale-125" />
                      <span>{likeCount}</span>
                    </button>

                    <div className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-amber-50/90 border border-amber-200/80 text-amber-700 text-xs font-black font-mono shadow-2xs">
                      <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
                      <span>+{item.xpEarned} XP</span>
                    </div>
                  </div>

                  {/* Right: Tombol "Lihat Laporan" */}
                  <button
                    id={`btn-view-report-${item.id}`}
                    onClick={() => handleOpenItem(item)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs font-bold shadow-xs hover:shadow-[0_4px_14px_rgba(59,130,246,0.35)] transition-all active:scale-95 cursor-pointer group/btn"
                  >
                    <span>Lihat Laporan</span>
                    <Eye className="w-3.5 h-3.5 transition-transform group-hover/btn:scale-110" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* =========================================================================
          4. DETAIL MODAL FOR CLASSMATE PORTFOLIO
          ========================================================================= */}
      {activeModalItem && (
        <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-4 my-8 animate-in fade-in zoom-in-95 border border-slate-200/80">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <span className="text-[10px] font-bold text-blue-600 uppercase tracking-wider">
                  Karya Siswa: {activeModalItem.studentName || 'Siswa'} • Kelas {activeModalItem.className || className}
                </span>
                <h3 className="font-display font-extrabold text-slate-900 text-base mt-0.5">
                  {activeModalItem.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveModalItem(null)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Foto Dokumentasi pada Modal Detail */}
            <div className="relative aspect-[16/9] w-full rounded-2xl overflow-hidden bg-slate-100 border border-slate-200">
              <img
                src={getPortfolioImage(activeModalItem)}
                alt={activeModalItem.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-slate-900/80 backdrop-blur-md text-white border border-white/20">
                  {activeModalItem.category}
                </span>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-emerald-600/90 backdrop-blur-md text-white border border-emerald-400/40 shadow-sm flex items-center gap-1">
                  <Camera className="w-3 h-3" />
                  Foto Dokumentasi Siswa
                </span>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-700 leading-relaxed">
              <div className="flex flex-wrap items-center justify-between gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-500">Karya Siswa:</span>
                  <span className="font-bold text-blue-700">{activeModalItem.studentName || 'Siswa MIPA'}</span>
                  <span className="text-slate-300">•</span>
                  <span className="text-slate-600 font-medium">{activeModalItem.subjectName}</span>
                </div>
                <span className="font-bold text-amber-600 font-mono">+{activeModalItem.xpEarned} XP</span>
              </div>

              {/* Info Tujuan Pembelajaran */}
              <div className="bg-emerald-50/60 p-3 rounded-2xl border border-emerald-100 text-emerald-900">
                <strong className="block text-xs font-bold mb-0.5">🎯 Tujuan Pembelajaran:</strong>
                <span className="text-xs">{getTujuanPembelajaran(activeModalItem)}</span>
              </div>

              {activeModalItem.reflectionSummary && (
                <div className="bg-blue-50/60 p-3.5 rounded-2xl border border-blue-100 space-y-1">
                  <h4 className="font-bold text-blue-900 text-xs">Catatan Laporan & Refleksi Saintifik:</h4>
                  <p className="italic text-slate-700 leading-relaxed">
                    "{getCleanReportText(activeModalItem.reflectionSummary)}"
                  </p>
                </div>
              )}

              {/* Link Google Drive */}
              {activeModalItem.driveLink && (
                <div className="bg-sky-50 p-3 rounded-2xl border border-sky-100 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-base">📁</span>
                    <div>
                      <span className="text-xs font-bold text-sky-950 block">Dokumen / Foto di Google Drive:</span>
                      <span className="text-[11px] text-sky-700 font-mono truncate max-w-xs block">
                        {activeModalItem.driveLink}
                      </span>
                    </div>
                  </div>
                  <a
                    href={activeModalItem.driveLink}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow-xs transition-colors shrink-0"
                  >
                    <span>Buka File Drive</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}

              {/* Komentar Teman & Guru (Peer Feedback) */}
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-2.5">
                <h4 className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-blue-600" />
                  <span>Umpan Balik & Komentar Teman / Guru ({activeModalItem.comments?.length || 0})</span>
                </h4>
                
                {/* Daftar Komentar */}
                {activeModalItem.comments && activeModalItem.comments.length > 0 ? (
                  <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
                    {activeModalItem.comments.map((c, i) => (
                      <div key={i} className="p-2 rounded-xl bg-white border border-slate-200/80 text-xs space-y-0.5 shadow-2xs">
                        <div className="flex items-center justify-between text-[10px]">
                          <span className="font-bold text-blue-800">{c.authorName}</span>
                          <span className="text-slate-400 font-mono">
                            {new Date(c.createdAt).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-slate-700">{c.text}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[11px] text-slate-400 italic">Belum ada komentar. Jadilah yang pertama memberi apresiasi!</p>
                )}

                {/* Input Komentar Baru */}
                <div className="flex items-center gap-2 pt-1 border-t border-slate-200/60">
                  <input
                    type="text"
                    value={newCommentText}
                    onChange={(e) => setNewCommentText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleSendComment(activeModalItem.id);
                    }}
                    placeholder="Beri apresiasi atau komentar konstruktif..."
                    className="flex-1 h-8 px-2.5 rounded-xl border border-slate-300 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <button
                    type="button"
                    onClick={() => handleSendComment(activeModalItem.id)}
                    className="h-8 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-colors cursor-pointer shrink-0"
                  >
                    Kirim
                  </button>
                </div>
              </div>

              {activeModalItem.experimentData && (
                <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-2">
                  <h4 className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                    <FlaskConical className="w-4 h-4 text-blue-600" />
                    Data Eksperimen Terukur
                  </h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-[11px] text-left">
                      <thead className="bg-slate-200 text-slate-700 font-bold">
                        <tr>
                          <th className="p-1.5">No</th>
                          <th className="p-1.5">Waktu (s)</th>
                          <th className="p-1.5">Suhu (°C)</th>
                          <th className="p-1.5">ΔT (°C)</th>
                          <th className="p-1.5">Kalor Q (J)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {activeModalItem.experimentData.rows.map((r, i) => (
                          <tr key={i} className="border-b border-slate-200">
                            <td className="p-1.5 font-mono">{i + 1}</td>
                            <td className="p-1.5 font-mono">{r.timeSeconds}</td>
                            <td className="p-1.5 font-mono">{r.tempCelsius}°C</td>
                            <td className="p-1.5 font-mono">{r.deltaT}°C</td>
                            <td className="p-1.5 font-mono">{r.heatJoules} J</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            <div className="pt-3 border-t flex justify-end">
              <button
                onClick={() => setActiveModalItem(null)}
                className="min-h-[40px] px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold active:scale-95 cursor-pointer shadow-xs transition-colors"
              >
                Tutup Laporan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upload Portofolio Modal */}
      <UploadPortfolioModal
        isOpen={showUploadModal}
        onClose={() => setShowUploadModal(false)}
        onSuccess={() => {
          if (onRefreshPortfolios) {
            onRefreshPortfolios();
          }
        }}
        studentId={studentId}
        studentName={studentName}
        classId={classId}
        className={className}
      />
    </div>
  );
};
