import React from 'react';
import { SubjectFilter } from './MissionTypes';
import { Layers, Calculator, Zap, FlaskConical, Leaf } from 'lucide-react';

interface MissionFilterBarProps {
  activeFilter: SubjectFilter;
  onFilterChange: (filter: SubjectFilter) => void;
  counts: Record<SubjectFilter, number>;
}

export const MissionFilterBar: React.FC<MissionFilterBarProps> = ({
  activeFilter,
  onFilterChange,
  counts,
}) => {
  const filterOptions: Array<{
    key: SubjectFilter;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    { key: 'SEMUA', label: 'SEMUA', icon: Layers },
    { key: 'MATEMATIKA', label: 'MATEMATIKA', icon: Calculator },
    { key: 'FISIKA', label: 'FISIKA', icon: Zap },
    { key: 'KIMIA', label: 'KIMIA', icon: FlaskConical },
    { key: 'BIOLOGI', label: 'BIOLOGI', icon: Leaf },
  ];

  return (
    <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1 scrollbar-none">
      <div className="flex items-center gap-2 p-1.5 bg-slate-900/80 backdrop-blur-md rounded-2xl border border-slate-800 shadow-sm">
        {filterOptions.map((opt) => {
          const Icon = opt.icon;
          const isActive = activeFilter === opt.key;
          const count = counts[opt.key] || 0;

          return (
            <button
              key={opt.key}
              id={`btn-filter-${opt.key.toLowerCase()}`}
              onClick={() => onFilterChange(opt.key)}
              className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-bold font-mono transition-all flex items-center gap-2 shrink-0 cursor-pointer ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-slate-400'}`} />
              <span>{opt.label}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-sans ${
                  isActive ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
