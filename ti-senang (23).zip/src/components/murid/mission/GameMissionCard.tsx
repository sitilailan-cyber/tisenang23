import React from 'react';
import {
  BarChart3,
  Thermometer,
  Sun,
  Atom,
  Leaf,
  Microscope,
  Trophy,
  Calculator,
  Activity,
  CheckCircle2,
  Lock,
  Play,
  Sparkles,
  Star,
  Clock,
  ChevronRight,
  ShieldCheck,
  Award,
} from 'lucide-react';
import { GameMissionItem } from './MissionTypes';

interface GameMissionCardProps {
  mission: GameMissionItem;
  isActiveSelection?: boolean;
  onSelect: (mission: GameMissionItem) => void;
  onActionClick: (mission: GameMissionItem) => void;
}

export const GameMissionCard: React.FC<GameMissionCardProps> = ({
  mission,
  isActiveSelection = false,
  onSelect,
  onActionClick,
}) => {
  // Render corresponding STEM educational icon
  const renderStemIcon = () => {
    const iconClass = 'w-7 h-7 sm:w-8 sm:h-8';
    switch (mission.iconType) {
      case 'barchart':
        return <BarChart3 className={iconClass} />;
      case 'thermometer':
        return <Thermometer className={iconClass} />;
      case 'sun':
        return <Sun className={iconClass} />;
      case 'atom':
        return <Atom className={iconClass} />;
      case 'leaf':
        return <Leaf className={iconClass} />;
      case 'microscope':
        return <Microscope className={iconClass} />;
      case 'trophy':
        return <Trophy className={iconClass} />;
      case 'calculator':
        return <Calculator className={iconClass} />;
      case 'activity':
      default:
        return <Activity className={iconClass} />;
    }
  };

  const isCompleted = mission.status === 'completed';
  const isAvailable = mission.status === 'available';
  const isLocked = mission.status === 'locked';
  const isRecommended = mission.isRecommended;
  const isBoss = mission.isBoss;

  // Visual card container styles
  let containerBorder = 'border-slate-800 bg-slate-900/90 text-slate-100';
  let badgeStatusBg = 'bg-slate-800 text-slate-400 border-slate-700';
  let badgeStatusText = 'LOCKED';
  let glowEffect = '';

  if (isBoss) {
    containerBorder = 'border-amber-500/70 bg-gradient-to-b from-slate-900 via-indigo-950 to-slate-900 shadow-xl shadow-amber-500/10';
    glowEffect = 'ring-1 ring-amber-400/40';
  } else if (isCompleted) {
    containerBorder = 'border-emerald-500/40 bg-gradient-to-b from-slate-900 via-slate-900 to-emerald-950/20';
    badgeStatusBg = 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30';
    badgeStatusText = 'COMPLETED';
  } else if (isRecommended) {
    containerBorder = 'border-amber-400/70 bg-gradient-to-b from-slate-900 via-indigo-950/40 to-pink-950/20';
    badgeStatusBg = 'bg-amber-400/20 text-amber-300 border-amber-400/40';
    badgeStatusText = 'RECOMMENDED';
    glowEffect = 'ring-2 ring-amber-400/50 shadow-xl shadow-pink-500/10';
  } else if (isAvailable) {
    containerBorder = 'border-blue-500/60 bg-gradient-to-b from-slate-900 via-slate-900 to-blue-950/30';
    badgeStatusBg = 'bg-blue-500/20 text-blue-300 border-blue-400/40';
    badgeStatusText = 'AVAILABLE';
    glowEffect = 'ring-2 ring-blue-500/40 shadow-xl shadow-blue-500/15';
  } else {
    // Locked styling: attractive frosted dark panel with clear requirements
    containerBorder = 'border-slate-800 bg-slate-900/60 opacity-80';
    badgeStatusBg = 'bg-slate-800/80 text-slate-400 border-slate-700';
    badgeStatusText = 'LOCKED';
  }

  return (
    <div
      id={`game-mission-card-${mission.id}`}
      onClick={() => onSelect(mission)}
      className={`relative w-[300px] sm:w-[330px] md:w-[350px] shrink-0 rounded-3xl p-5 sm:p-6 border transition-all duration-300 cursor-pointer flex flex-col justify-between select-none ${containerBorder} ${glowEffect} ${
        isActiveSelection ? 'scale-[1.02] shadow-2xl' : 'hover:scale-[1.01] hover:border-slate-600'
      } ${isAvailable ? 'md:scale-[1.02]' : ''}`}
    >
      {/* Top Banner & Badges */}
      <div>
        <div className="flex items-center justify-between gap-2 mb-3">
          <span className="font-mono text-xs font-bold tracking-wider text-slate-400 flex items-center gap-1.5">
            <span className="px-2 py-0.5 rounded-md bg-slate-800 border border-slate-700 text-slate-200">
              {mission.missionCode}
            </span>
            <span className="text-slate-500">•</span>
            <span className="text-[11px] font-medium text-slate-400">
              {mission.subjectName}
            </span>
          </span>

          {/* Status Badge */}
          <span
            className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold border ${badgeStatusBg}`}
          >
            {isCompleted && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
            {isRecommended && <Sparkles className="w-3.5 h-3.5 text-amber-400" />}
            {isAvailable && <Play className="w-3 h-3 fill-blue-400 text-blue-400" />}
            {isLocked && <Lock className="w-3 h-3 text-slate-400" />}
            <span>{badgeStatusText}</span>
          </span>
        </div>

        {/* Mastered Badge if high score */}
        {isCompleted && mission.isMastered && (
          <div className="mb-2">
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-amber-400/15 border border-amber-400/30 text-amber-300 text-[10px] font-mono font-extrabold tracking-wider uppercase">
              <Award className="w-3 h-3 text-amber-400" />
              MASTERED • SKOR {mission.score}/100
            </span>
          </div>
        )}

        {/* Boss Badge if Final Challenge */}
        {isBoss && (
          <div className="mb-2">
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-amber-500/20 border border-amber-400/40 text-amber-300 text-[10px] font-mono font-black tracking-widest uppercase">
              🏆 BOSS MISSION • FINAL CHALLENGE
            </span>
          </div>
        )}

        {/* Icon & Theme Header */}
        <div className="flex items-start gap-4 mb-3">
          <div
            className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 border shadow-inner ${
              isCompleted
                ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-400'
                : isRecommended
                ? 'bg-amber-950/60 border-amber-400/50 text-amber-300 animate-pulse'
                : isAvailable
                ? 'bg-blue-950/70 border-blue-500/50 text-blue-400 shadow-blue-500/20'
                : isBoss
                ? 'bg-amber-950/50 border-amber-500/40 text-amber-300'
                : 'bg-slate-800/80 border-slate-700 text-slate-400'
            }`}
          >
            {renderStemIcon()}
          </div>

          <div className="flex-1 min-w-0">
            <div className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
              {mission.themeTitle}
            </div>
            <h3 className="text-base sm:text-lg font-display font-extrabold text-white leading-snug truncate">
              {mission.title}
            </h3>
            <div className="flex items-center gap-2 mt-1 text-[11px] font-mono text-slate-400">
              <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-300">
                {mission.difficulty}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3 text-slate-400" />
                {mission.estimatedTime}
              </span>
            </div>
          </div>
        </div>

        {/* Short Description */}
        <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed mb-4">
          {mission.description}
        </p>

        {/* ALME reason if recommended */}
        {isRecommended && mission.recommendationReason && (
          <div className="mb-4 p-2.5 rounded-xl bg-amber-400/10 border border-amber-400/30 text-[11px] text-amber-200 leading-snug">
            <span className="font-bold font-mono text-amber-300 flex items-center gap-1 mb-0.5">
              <Sparkles className="w-3 h-3" />
              Rekomendasi ALME:
            </span>
            "{mission.recommendationReason}"
          </div>
        )}

        {/* Locked Reason if locked */}
        {isLocked && (
          <div className="mb-4 p-2.5 rounded-xl bg-slate-800/80 border border-slate-700 text-[11px] text-slate-400 flex items-start gap-2">
            <Lock className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-slate-300 font-mono">Syarat Membuka:</span>
              <p className="text-slate-400 mt-0.5">{mission.requiredMissionText}</p>
            </div>
          </div>
        )}
      </div>

      {/* Card Footer: Progress, XP Reward & CTA Button */}
      <div className="pt-3 border-t border-slate-800 space-y-3">
        {/* Active/In-Progress bar */}
        {(isAvailable || isCompleted || mission.progress > 0) && (
          <div className="space-y-1">
            <div className="flex justify-between items-center text-[11px] font-mono">
              <span className="text-slate-400">Progress Misi</span>
              <span
                className={`font-bold ${
                  isCompleted ? 'text-emerald-400' : 'text-blue-400'
                }`}
              >
                {mission.progress}%
              </span>
            </div>
            <div className="h-2 bg-slate-800 rounded-full overflow-hidden p-0.5 border border-slate-700">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  isCompleted
                    ? 'bg-emerald-500'
                    : isRecommended
                    ? 'bg-gradient-to-r from-amber-400 to-pink-500'
                    : 'bg-blue-500'
                }`}
                style={{ width: `${Math.max(5, mission.progress)}%` }}
              />
            </div>
          </div>
        )}

        {/* XP Reward & Date */}
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-1 text-amber-300 font-mono font-bold">
            <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
            <span>+{mission.xpReward} XP</span>
          </div>

          {isCompleted && mission.completedAt && (
            <span className="text-[10px] text-slate-500 font-mono">
              Selesai: {new Date(mission.completedAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}
            </span>
          )}
        </div>

        {/* Big Clear Action Button */}
        <button
          id={`btn-card-action-${mission.id}`}
          onClick={(e) => {
            e.stopPropagation();
            if (mission.isUnlocked) {
              onActionClick(mission);
            } else {
              onSelect(mission);
            }
          }}
          disabled={!mission.isUnlocked}
          className={`w-full min-h-[46px] px-4 py-2.5 rounded-2xl font-display font-bold text-xs sm:text-sm tracking-wide transition-all flex items-center justify-center gap-2 cursor-pointer ${
            isCompleted
              ? 'bg-slate-800 hover:bg-slate-700 text-emerald-300 border border-emerald-500/30'
              : isRecommended
              ? 'bg-gradient-to-r from-amber-500 via-amber-400 to-pink-500 hover:from-amber-600 hover:to-pink-600 text-slate-950 shadow-lg shadow-amber-500/20 active:scale-98'
              : isAvailable
              ? 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-lg shadow-blue-500/25 active:scale-98 ring-1 ring-white/20'
              : isBoss
              ? 'bg-slate-800/80 text-amber-300/60 border border-slate-700 cursor-not-allowed'
              : 'bg-slate-800/60 text-slate-500 border border-slate-700/60 cursor-not-allowed'
          }`}
        >
          {isCompleted ? (
            <>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>REVIEW & BUKA MISI</span>
            </>
          ) : isRecommended ? (
            <>
              <Sparkles className="w-4 h-4 fill-slate-950 text-slate-950" />
              <span>COBA MISI SEKARANG</span>
            </>
          ) : isAvailable ? (
            <>
              <Play className="w-4 h-4 fill-white text-white" />
              <span>MULAI MISI</span>
            </>
          ) : (
            <>
              <Lock className="w-4 h-4" />
              <span>TERKUNCI (LIHAT SYARAT)</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
