import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Bot,
  Zap,
  CheckCircle2,
  X,
  ArrowRight,
  ShieldCheck,
  AlertTriangle,
  Award,
  BookOpen,
  TrendingUp,
  Calculator,
  CheckSquare,
} from 'lucide-react';
import { storage } from '../../../services/storage';
import { AlmeEngine } from '../../../services/alme/almeEngine';
import { AlmeInterventionType } from '../../../types';

interface AlmePopupModalProps {
  isOpen: boolean;
  onClose: () => void;
  checkpointNumber?: 1 | 2;
  studentId: string;
  studentName: string;
  subjectId: string;
  subjectName: string;
  defaultIntervention?: AlmeInterventionType;
  onCompleted: (xpReward: number) => void;
}

export const AlmePopupModal: React.FC<AlmePopupModalProps> = ({
  isOpen,
  onClose,
  checkpointNumber = 1,
  studentId,
  studentName,
  subjectId,
  subjectName,
  defaultIntervention,
  onCompleted,
}) => {
  const [activeIntervention, setActiveIntervention] = useState<AlmeInterventionType>(
    defaultIntervention || (checkpointNumber === 1 ? 'soal_numerasi' : 'pengayaan')
  );
  const [activeQuestionIdx, setActiveQuestionIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (defaultIntervention) {
      setActiveIntervention(defaultIntervention);
    }
    setSelectedOption(null);
    setIsAnswered(false);
    setIsCorrect(false);
    setActiveQuestionIdx(0);
  }, [isOpen, defaultIntervention]);

  if (!isOpen) return null;

  const xpReward = checkpointNumber === 1 ? 60 : 75;

  // Dapatkan konten intervensi dari AlmeEngine
  const interventionContent = AlmeEngine.getInterventionContent(
    activeIntervention,
    subjectName
  );

  const currentQ =
    interventionContent.questions[activeQuestionIdx] ||
    interventionContent.questions[0];

  const handleSwitchTab = (type: AlmeInterventionType) => {
    setActiveIntervention(type);
    setActiveQuestionIdx(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setIsCorrect(false);
  };

  const handleSelectOption = (index: number) => {
    if (isAnswered) return;
    setSelectedOption(index);
    setIsAnswered(true);

    const chosenText = currentQ.options[index];
    const correct = chosenText === currentQ.correctAnswer;
    setIsCorrect(correct);
  };

  const handleClaimAndUnlock = () => {
    setIsSubmitting(true);

    // Rekam XP ke profile murid
    storage.addStudentXp(studentId, xpReward);

    setTimeout(() => {
      setIsSubmitting(false);
      onCompleted(xpReward);
      onClose();
    }, 400);
  };

  const tabs: { type: AlmeInterventionType; label: string; icon: any; color: string }[] = [
    { type: 'remedial', label: 'Remedial', icon: ShieldCheck, color: 'text-rose-400 border-rose-500/30' },
    { type: 'pengayaan', label: 'Pengayaan', icon: TrendingUp, color: 'text-purple-400 border-purple-500/30' },
    { type: 'soal_literasi', label: 'Soal Literasi', icon: BookOpen, color: 'text-sky-400 border-sky-500/30' },
    { type: 'soal_numerasi', label: 'Soal Numerasi', icon: Calculator, color: 'text-emerald-400 border-emerald-500/30' },
    { type: 'latihan_soal', label: 'Latihan Soal', icon: CheckSquare, color: 'text-amber-400 border-amber-500/30' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl sm:max-w-4xl max-h-[82vh] my-auto overflow-y-auto rounded-3xl bg-slate-900 border border-amber-500/40 p-5 sm:p-6 shadow-[0_0_50px_rgba(245,158,11,0.25)] text-white space-y-4">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          title="Tutup Sisipan ALME"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Top Header Badge */}
        <div className="flex items-center gap-3 pr-8">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 p-0.5 shadow-lg shadow-amber-500/30 shrink-0">
            <div className="w-full h-full rounded-2xl bg-slate-900 flex items-center justify-center text-amber-400">
              <Bot className="w-5 h-5" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30">
                ✨ SISIPAN PEMBELAJARAN ALME
              </span>
              <span className="text-[11px] font-mono font-bold text-amber-400 flex items-center gap-1">
                <Zap className="w-3 h-3 fill-amber-400" />+{xpReward} XP
              </span>
            </div>
            <h2 className="text-sm sm:text-base font-black text-white tracking-tight mt-0.5 line-clamp-1">
              {interventionContent.title}
            </h2>
          </div>
        </div>

        {/* 5 Sisipan Pembelajaran Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 border-b border-slate-800 scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeIntervention === tab.type;
            return (
              <button
                key={tab.type}
                type="button"
                onClick={() => handleSwitchTab(tab.type)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 flex items-center gap-1.5 transition-all cursor-pointer ${
                  isActive
                    ? 'bg-amber-400 text-slate-950 shadow-md font-extrabold'
                    : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300 border border-slate-700/60'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-slate-950' : tab.color.split(' ')[0]}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Overview & Instructions */}
        <div className="p-3 rounded-2xl bg-slate-800/70 border border-slate-700/60 text-xs text-slate-300 leading-relaxed space-y-1">
          <p className="text-slate-200 font-medium">{interventionContent.summary}</p>
          <p className="text-[11px] text-amber-300/90 font-mono">
            💡 {interventionContent.instructions}
          </p>
        </div>

        {/* Question & Interactive Options */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span className="font-mono font-bold text-amber-400">
              Pertanyaan {activeQuestionIdx + 1} dari {interventionContent.questions.length}
            </span>
            {interventionContent.questions.length > 1 && (
              <div className="flex gap-1">
                {interventionContent.questions.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setActiveQuestionIdx(i);
                      setSelectedOption(null);
                      setIsAnswered(false);
                      setIsCorrect(false);
                    }}
                    className={`w-5 h-5 rounded-md text-[10px] font-mono font-bold ${
                      activeQuestionIdx === i
                        ? 'bg-amber-400 text-slate-950'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                    }`}
                  >
                    {i + 1}
                  </button>
                ))}
              </div>
            )}
          </div>

          <p className="text-xs sm:text-sm font-semibold text-white leading-snug whitespace-pre-line bg-slate-950/50 p-3 rounded-xl border border-slate-800">
            {currentQ.question}
          </p>

          <div className="space-y-2">
            {currentQ.options.map((opt, idx) => {
              const isSelected = selectedOption === idx;
              const isOptionCorrect = opt === currentQ.correctAnswer;
              let btnStyle =
                'bg-slate-800/60 hover:bg-slate-800 border-slate-700/80 text-slate-300';

              if (isAnswered) {
                if (isOptionCorrect) {
                  btnStyle = 'bg-emerald-950/80 border-emerald-500 text-emerald-200 font-bold';
                } else if (isSelected && !isOptionCorrect) {
                  btnStyle = 'bg-rose-950/80 border-rose-500 text-rose-200';
                } else {
                  btnStyle = 'bg-slate-800/30 border-slate-800 text-slate-500';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelectOption(idx)}
                  disabled={isAnswered}
                  className={`w-full text-left p-3 rounded-2xl border text-xs sm:text-sm transition-all flex items-center justify-between cursor-pointer ${btnStyle}`}
                >
                  <span className="flex-1 pr-2">{opt}</span>
                  {isAnswered && isOptionCorrect && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  )}
                  {isAnswered && isSelected && !isOptionCorrect && (
                    <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Feedback after answering */}
        {isAnswered && (
          <div
            className={`p-3 rounded-2xl text-xs leading-relaxed border animate-in fade-in duration-200 ${
              isCorrect
                ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-200'
                : 'bg-amber-950/60 border-amber-500/40 text-amber-200'
            }`}
          >
            <p className="font-bold mb-1 flex items-center gap-1.5">
              {isCorrect ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  Jawaban Benar! Pemahaman Tervalidasi
                </>
              ) : (
                <>
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  Pembahasan Pedagogis ALME:
                </>
              )}
            </p>
            <p>{currentQ.explanation}</p>
          </div>
        )}

        {/* Action Button */}
        {isAnswered && (
          <div className="pt-1">
            <button
              id="btn-kirim-alme-popup"
              onClick={handleClaimAndUnlock}
              disabled={isSubmitting}
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-600 hover:to-orange-600 text-slate-950 font-black text-xs sm:text-sm uppercase tracking-wider shadow-lg shadow-amber-500/20 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {isSubmitting ? (
                <span>Menyimpan Capaian...</span>
              ) : (
                <>
                  <Award className="w-4 h-4" />
                  <span>Kirim & Selesaikan Sisipan (+{xpReward} XP)</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        )}

        {!isAnswered && (
          <p className="text-[11px] text-center text-slate-400">
            Pilih salah satu opsi jawaban di atas untuk mengonfirmasi pemahamanmu.
          </p>
        )}
      </div>
    </div>
  );
};
