import React, { useState, useMemo } from 'react';
import {
  BookOpen,
  HelpCircle,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Sparkles,
  ArrowRight,
  Award,
  RotateCcw,
  FileText,
  Video,
  ExternalLink,
  Zap,
  PenTool,
  Check,
  Volume2,
} from 'lucide-react';
import { Mission } from '../../types';
import { storage } from '../../services/storage';
import { soundEffects } from '../../services/audio/soundEffects';

interface Misi1PahamiKonsepProps {
  studentId: string;
  missionId: string;
  mission?: Mission;
  onCompleted?: () => void;
  onNextMission?: (nextMissionNumber: number) => void;
  onClose?: () => void;
}

interface SingleQuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  hint: string;
  explanation: string;
}

export const Misi1PahamiKonsep: React.FC<Misi1PahamiKonsepProps> = ({
  studentId,
  missionId,
  mission,
  onCompleted,
  onNextMission,
  onClose,
}) => {
  // Catatan informasi penting siswa dari bahan ajar
  const [catatanPenting, setCatatanPenting] = useState<string>(() => storage.getMisi1Notes(studentId) || '');

  // 1 Soal Mini Kuis Singkat AI yang dipastikan 100% selaras dengan Mata Pelajaran & TP aktif (tanpa mencampuradukkan materi)
  const defaultMiniQuiz: SingleQuizQuestion = useMemo(() => {
    const subId = (mission?.subjectId || '').toLowerCase();
    const subName = (mission?.subjectName || '').toLowerCase();

    if (subId.includes('kimia') || subName.includes('kimia')) {
      return {
        question:
          'Berdasarkan materi termokimia dan laju reaksi kimia: Apabila suatu sistem reaksi kimia melepaskan kalor ke lingkungan disertai kenaikan suhu lingkungan terukur (entalpi reaksi ΔH < 0), proses tersebut diklasifikasikan sebagai...',
        options: [
          'Reaksi eksoterm yang membebaskan kalor ke lingkungan',
          'Reaksi endoterm yang menyerap energi panas dari lingkungan',
          'Reaksi netral tanpa melibatkan perubahan energi ikat kimia',
          'Reaksi pengendapan spontan pada tekanan vakum mutlak',
        ],
        correctIndex: 0,
        hint: 'Perhatikan tanda entalpi (ΔH < 0) serta kenaikan suhu pada lingkungan.',
        explanation:
          'Tepat sekali! Pada reaksi eksoterm, sistem kimia melepaskan energi kalor ke lingkungan sehingga entalpi berkurang (ΔH < 0) dan suhu lingkungan meningkat.',
      };
    }

    if (subId.includes('biologi') || subName.includes('biologi')) {
      return {
        question:
          'Berdasarkan bahan ajar fisiologi tumbuhan: Mekanisme penguapan air melalui stomata daun yang menghasilkan daya hisap daun untuk mengalirkan air dan hara mineral dari akar ke seluruh jaringan adalah...',
        options: [
          'Transpirasi tumbuhan',
          'Gutasi melalui hidatoda',
          'Respirasi anaerob sel',
          'Siklus Calvin fotosintesis',
        ],
        correctIndex: 0,
        hint: 'Proses ini berlangsung secara dominan di permukaan stomata daun pada siang hari.',
        explanation:
          'Benar! Transpirasi adalah pelepasan uap air melalui stomata yang menciptakan tarikan kapilaritas xilem dari akar menuju daun.',
      };
    }

    if (subId.includes('informatika') || subName.includes('informatika')) {
      return {
        question:
          'Berdasarkan bahan ajar sistem tersemat dan IoT TI SENANG: Komponen fisis yang berfungsi mendeteksi besaran fisis (seperti suhu atau cahaya) lalu mengonversinya menjadi sinyal elektrik digital yang dapat diproses mikroprosesor adalah...',
        options: [
          'Sensor (Transduser Analog/Digital)',
          'Aktuator mekanik motor servo',
          'Kabel transmisi jaringan fiber optik',
          'Algoritma enkripsi asimetris',
        ],
        correctIndex: 0,
        hint: 'Perangkat ini menerima input dari lingkungan fisik di port input IoT.',
        explanation:
          'Tepat sekali! Sensor bertindak sebagai transduser yang menangkap fenomena fisis dan mengonversinya menjadi besaran elektrik yang terukur.',
      };
    }

    if (subId.includes('mat') || subName.includes('matematika')) {
      return {
        question:
          'Berdasarkan materi pemodelan regresi linear data bivariat ŷ = ax + b: Bagaimanakah interpretasi matematis yang paling presisi untuk koefisien kemiringan (gradien) "a"?',
        options: [
          'Taksiran perubahan nilai variabel terikat (ŷ) untuk setiap peningkatan 1 satuan pada variabel bebas (x)',
          'Nilai variabel terikat pada saat nilai variabel bebas x bernilai nol (titik potong)',
          'Total kuadrat galat acak dari seluruh titik data pada diagram pencar',
          'Jumlah observasi sampel yang diikutsertakan dalam estimasi garis',
        ],
        correctIndex: 0,
        hint: 'Kemiringan (slope) menyatakan laju perbandingan perubahan vertikal Δy terhadap perubahan horizontal Δx.',
        explanation:
          'Sangat tepat! Gradien kemiringan regresi mengukur rata-rata perubahan variabel respons ŷ saat variabel prediktor x bertambah sebesar satu satuan.',
      };
    }

    // Default: Fisika Eksperimental & Terapan (Azas Black & Kalor)
    return {
      question:
        'Berdasarkan bahan ajar konsep kalor dan azas Black: Pada sistem kalorimeter terisolasi ideal yang mencegah kebocoran energi termal ke lingkungan, bagaimanakah prinsip kekekalan energi kalor saat dua zat berbeda suhu dicampurkan?',
      options: [
        'Jumlah kalor yang dilepas oleh zat bersuhu lebih tinggi sama dengan jumlah kalor yang diserap zat bersuhu lebih rendah (Q_lepas = Q_terima)',
        'Suhu akhir campuran selalu sama dengan suhu zat yang memiliki massa lebih besar',
        'Kalor jenis kedua zat tersebut otomatis berubah menjadi identik',
        'Sebagian energi kalor akan hilang musnah menjadi gelombang suara',
      ],
      correctIndex: 0,
      hint: 'Gunakan prinsip kekekalan energi Azas Black: Q_lepas = Q_terima.',
      explanation:
        'Tepat sekali! Berdasarkan Azas Black, kalor yang dilepaskan oleh benda bersuhu tinggi secara matematis setara dengan kalor yang diserap oleh benda bersuhu lebih rendah tanpa adanya kehilangan energi ke lingkungan ideal.',
    };
  }, [mission?.subjectId, mission?.subjectName]);

  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showHint, setShowHint] = useState<boolean>(false);
  const [isFinished, setIsFinished] = useState<boolean>(false);
  const [isAnswerChecked, setIsAnswerChecked] = useState<boolean>(false);
  const [quizScore, setQuizScore] = useState<number>(0);
  const [showSuccessCard, setShowSuccessCard] = useState<boolean>(false);
  const [quizError, setQuizError] = useState<string | null>(null);

  const activeQuestion = defaultMiniQuiz;

  // Lanjut ke Misi Berikutnya (Manual saat murid menekan tombol)
  const handleProceedNext = () => {
    if (onNextMission) {
      onNextMission(2);
    } else if (onClose) {
      onClose();
    }
  };

  // Tombol Periksa Jawaban Benar / Salah dengan Audio Feedback
  const handlePeriksaJawaban = () => {
    if (selectedOption === null) {
      setQuizError('Silakan pilih salah satu opsi jawaban (A, B, C, atau D) terlebih dahulu!');
      return;
    }
    setQuizError(null);

    let note = catatanPenting.trim();
    if (!note) {
      note = 'Catatan pembelajaran: Konsep Azas Black, kapasitas kalor, dan interpretasi grafik regresi linear telah dipelajari dengan baik.';
      setCatatanPenting(note);
    }

    const isCorrect = selectedOption === activeQuestion.correctIndex;
    const finalScore = isCorrect ? 100 : 75;
    setQuizScore(finalScore);
    setIsAnswerChecked(true);
    setIsFinished(true);

    // Mainkan sound effect sesuai benar atau salah
    if (isCorrect) {
      soundEffects.playCorrect();
    } else {
      soundEffects.playIncorrect();
    }

    // 1. Simpan penyelesaian Misi 1
    storage.saveMisi1Notes(studentId, note, missionId);
    storage.completeMission(studentId, missionId, finalScore, mission?.xpReward || 100);

    // 2. Dispatch custom event agar progress di dashboard segera sinkron
    window.dispatchEvent(new CustomEvent('tisenang_missions_updated'));

    // 3. Evaluasi ALME jika kuis kurang tepat
    if (!isCorrect) {
      storage.saveAlmeRecommendation({
        id: `rec-alme-m1-${Date.now()}`,
        studentId: studentId,
        classId: mission?.classId || 'cls-xii-1',
        className: mission?.className || 'XII-1',
        missionId: missionId,
        type: 'Strengthening',
        title: 'Penguatan Konsep Regresi & Permodelan Kalor',
        message:
          'Hasil mini kuis Misi 1 menunjukkan Anda memerlukan penguatan pada interpretasi matematis gradien garis regresi sebelum melanjutkan ke Misi 2 (Selesaikan Masalah).',
        whyExplanation:
          'Sistem ALME mendeteksi perlunya penguatan pada pemahaman fisis kemiringan regresi linear.',
        recommendedCategory: 'pahami_konsep',
        status: 'PENDING',
        xpReward: 80,
        reason: 'Mini kuis Misi 1 terjawab kurang tepat. Rekomendasi modul remedial aktif.',
        createdAt: new Date().toISOString(),
      });
    }

    setShowSuccessCard(true);

    if (onCompleted) {
      onCompleted();
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-purple-700 rounded-3xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-xs font-bold uppercase tracking-wider mb-2">
              <BookOpen className="w-3.5 h-3.5" />
              Misi 1 • Pahami Konsep
            </div>
            <h1 className="text-2xl sm:text-3xl font-display font-extrabold tracking-tight">
              {mission?.title || 'Pahami Konsep Sains & Permodelan Matematis'}
            </h1>
            <p className="text-blue-100 text-xs sm:text-sm mt-1 max-w-xl">
              Pelajari bahan ajar PDF/Video dari guru, catat informasi penting, dan jawab 1 mini kuis AI untuk membuka Misi 2.
            </p>
          </div>

          <span className="px-3.5 py-1.5 rounded-full text-xs font-bold bg-white/20 backdrop-blur border border-white/30 text-white self-start sm:self-auto">
            +{mission?.xpReward || 100} XP Reward
          </span>
        </div>
      </div>

      {/* MODAL / CARD SUKSES: Misi 2 Terbuka */}
      {showSuccessCard && (
        <div className="p-6 bg-gradient-to-r from-emerald-600 to-teal-700 rounded-3xl text-white shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4 animate-in fade-in zoom-in-95">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-7 h-7 text-emerald-200" />
            </div>
            <div>
              <h3 className="text-lg font-bold">🎉 Selamat! Belajar Misi 1 Selesai!</h3>
              <p className="text-xs text-emerald-100 mt-0.5">
                Skor Mini Kuis: <strong>{quizScore}/100</strong>. Misi 2 (Selesaikan Masalah) kini telah terbuka untuk Anda!
              </p>
            </div>
          </div>
          <button
            id="btn-lanjut-misi-2-card"
            type="button"
            onClick={handleProceedNext}
            className="px-5 py-2.5 rounded-2xl bg-white text-emerald-800 hover:bg-emerald-50 font-bold text-xs shadow-md shrink-0 flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all"
          >
            <span>Lanjut ke Misi 2</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 1. BAHAN AJAR PDF / VIDEO PEMBELAJARAN DARI GURU */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-display font-bold text-slate-800 text-base">
                1. Bahan Ajar & Video Pembelajaran dari Guru
              </h2>
              <p className="text-xs text-slate-500">
                Baca dokumen bahan ajar PDF atau tonton video pembelajaran berikut secara seksama.
              </p>
            </div>
          </div>
        </div>

        {/* Media Resources dari Guru */}
        {mission?.mediaResources && mission.mediaResources.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            {mission.mediaResources.map((res, idx) => (
              <div
                key={idx}
                className="p-4 bg-gradient-to-br from-slate-50 to-blue-50/40 rounded-2xl border border-blue-100/80 flex items-start justify-between gap-3 shadow-2xs hover:border-blue-300 transition-all"
              >
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-xs">
                    {res.type === 'pdf' ? (
                      <FileText className="w-5 h-5" />
                    ) : res.type === 'video' ? (
                      <Video className="w-5 h-5" />
                    ) : (
                      <ExternalLink className="w-5 h-5" />
                    )}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 leading-snug">{res.title}</h4>
                    <span className="text-[10px] font-semibold text-blue-700 uppercase tracking-wide block mt-0.5">
                      {res.type === 'pdf'
                        ? '📄 Dokumen PDF Bahan Ajar'
                        : res.type === 'video'
                        ? '🎬 Video Pembelajaran'
                        : '🌐 Tautan Pembelajaran'}
                    </span>
                    {res.description && (
                      <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">{res.description}</p>
                    )}
                  </div>
                </div>

                <a
                  href={res.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1 shrink-0 shadow-2xs active:scale-95"
                >
                  <span>Buka</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-4 bg-blue-50/60 rounded-2xl border border-blue-100 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-800">
                  Modul Bahan Ajar PDF: Konsep Kalor & Regresi Linear Sains Fase F
                </h4>
                <p className="text-[11px] text-slate-500">
                  Membahas perpindahan kalor, pembacaan sensor digital, dan permodelan regresi linear.
                </p>
              </div>
            </div>
            <a
              href="https://drive.google.com/drive/folders/1hFWytE3lr96iGUmSeXS1mMmJQfcTUh6w?usp=sharing"
              target="_blank"
              rel="noopener noreferrer"
              className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1 shrink-0 shadow-xs"
            >
              <span>Lihat Dokumen</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        )}

        {/* Teks Modul Bacaan dari Guru jika tersedia */}
        {mission?.readingModuleText && (
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-700 whitespace-pre-line leading-relaxed">
            {mission.readingModuleText}
          </div>
        )}
      </div>

      {/* 2. MENULISKAN KEMBALI INFORMASI PENTING YANG DITEMUKAN */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center gap-2.5 border-b border-slate-100 pb-3">
          <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center">
            <PenTool className="w-4 h-4" />
          </div>
          <div>
            <h2 className="font-display font-bold text-slate-800 text-base">
              2. Tuliskan Kembali Informasi Penting dari Bahan Ajar
            </h2>
            <p className="text-xs text-slate-500">
              Tuliskan intisari konsep sains, rumus matematis, atau fakta penting yang Anda temukan dari bahan ajar.
            </p>
          </div>
        </div>

        <div>
          <textarea
            id="input-catatan-penting"
            rows={4}
            value={catatanPenting}
            onChange={(e) => setCatatanPenting(e.target.value)}
            placeholder="Contoh: Dari bahan ajar saya menemukan bahwa konsep materi ini menjelaskan hubungan fisis antar variabel... Catat poin penting sebelum menyelesaikan misi."
            className="w-full p-4 rounded-2xl border border-slate-200 text-xs sm:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-purple-400 focus:border-purple-400 leading-relaxed bg-slate-50/50"
          />
          <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
            <span>
              {catatanPenting.trim().length > 0 ? (
                <span className="text-emerald-600 font-bold flex items-center gap-1">
                  <Check className="w-3 h-3" /> Informasi penting telah dicatat ({catatanPenting.trim().split(/\s+/).length} kata)
                </span>
              ) : (
                'Catat minimal 1 poin inti sebelum mengklik Selesai Belajar'
              )}
            </span>
          </div>
        </div>
      </div>

      {/* 3. MINI KUIS SINGKAT 1 NOMOR DIBUAT OLEH AI (SESUAI MATA PELAJARAN & TP) */}
      <div className="bg-white rounded-3xl p-6 border border-indigo-200 shadow-xs space-y-4 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-indigo-100 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-indigo-600" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-display font-bold text-slate-900 text-base">
                  3. Mini Kuis Singkat AI (1 Nomor)
                </h2>
                <span className="px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-[10px] font-bold border border-indigo-200">
                  1 Soal Wajib • {mission?.subjectName || 'Mata Pelajaran'}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Kuis diselaraskan secara ketat dengan Mata Pelajaran & Tujuan Pembelajaran aktif tanpa mencampuradukkan materi lain.
              </p>
            </div>
          </div>
        </div>

        {/* Soal Mini Kuis AI */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-50/40 via-white to-purple-50/30 border border-indigo-100 space-y-4">
          <p className="text-xs sm:text-sm font-bold text-slate-800 leading-relaxed">
            {activeQuestion.question}
          </p>

          <div className="space-y-2">
            {activeQuestion.options.map((opt, idx) => {
              const isSelected = selectedOption === idx;
              let btnStyle = 'border-slate-200 bg-white hover:border-indigo-300 text-slate-700';

              if (isSelected) {
                if (isFinished) {
                  btnStyle =
                    idx === activeQuestion.correctIndex
                      ? 'border-emerald-500 bg-emerald-50 text-emerald-900 font-bold ring-2 ring-emerald-300'
                      : 'border-rose-500 bg-rose-50 text-rose-900 font-bold ring-2 ring-rose-300';
                } else {
                  btnStyle = 'border-indigo-600 bg-indigo-50 text-indigo-900 font-bold ring-2 ring-indigo-400';
                }
              } else if (isFinished && idx === activeQuestion.correctIndex) {
                btnStyle = 'border-emerald-500 bg-emerald-50 text-emerald-900 font-bold';
              }

              return (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    if (!isFinished) setSelectedOption(idx);
                  }}
                  className={`w-full text-left p-3 rounded-xl border text-xs sm:text-sm transition-all flex items-center gap-3 cursor-pointer ${btnStyle}`}
                >
                  <span className="w-6 h-6 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-xs shrink-0 text-slate-700">
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <span className="flex-1">{opt}</span>
                  {isFinished && idx === activeQuestion.correctIndex && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Tombol Periksa Jawaban & Status Validasi */}
          {quizError && (
            <div className="p-3 rounded-xl bg-amber-50 border border-amber-300 text-amber-900 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>{quizError}</span>
            </div>
          )}

          {!isAnswerChecked ? (
            <div className="pt-2">
              <button
                id="btn-periksa-jawaban-kuis"
                type="button"
                onClick={handlePeriksaJawaban}
                disabled={selectedOption === null}
                className={`w-full py-3 px-4 rounded-xl font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-98 ${
                  selectedOption !== null
                    ? 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-blue-500/20'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                <Check className="w-4 h-4" />
                <span>Periksa Jawaban Sekarang</span>
              </button>
              <p className="text-[11px] text-slate-400 text-center mt-1.5">
                {selectedOption !== null
                  ? 'Klik tombol di atas untuk memeriksa apakah jawabanmu Benar atau Salah'
                  : 'Pilih salah satu jawaban (A, B, C, atau D) di atas untuk memeriksa'}
              </p>
            </div>
          ) : (
            <div className="space-y-3 pt-1">
              {selectedOption === activeQuestion.correctIndex ? (
                <div className="p-4 rounded-2xl bg-emerald-50 border-2 border-emerald-500 text-emerald-950 space-y-1.5 animate-in fade-in zoom-in-95">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    <span className="font-extrabold text-sm text-emerald-900">
                      🎉 Jawaban Kamu BENAR! (Skor: 100/100)
                    </span>
                  </div>
                  <p className="text-xs text-emerald-700">
                    Pemahaman konsepmu sangat tepat! Anda siap melanjutkan ke Misi 2 (Selesaikan Masalah).
                  </p>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-rose-50 border-2 border-rose-400 text-rose-950 space-y-1.5 animate-in fade-in zoom-in-95">
                  <div className="flex items-center gap-2">
                    <XCircle className="w-5 h-5 text-rose-600 shrink-0" />
                    <span className="font-extrabold text-sm text-rose-900">
                      ❌ Jawaban Belum Tepat (Skor: 75/100)
                    </span>
                  </div>
                  <p className="text-xs text-rose-700 leading-relaxed">
                    Jawaban yang tepat adalah opsi <strong>{String.fromCharCode(65 + activeQuestion.correctIndex)}: {activeQuestion.options[activeQuestion.correctIndex]}</strong>. Pelajari pembahasan AI di bawah ini sebelum lanjut.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Hint & Explanation */}
          <div className="pt-2 flex items-center justify-between text-xs">
            <button
              type="button"
              onClick={() => setShowHint(!showHint)}
              className="text-indigo-600 hover:text-indigo-700 font-bold flex items-center gap-1 cursor-pointer"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>{showHint ? 'Sembunyikan Petunjuk' : 'Lihat Petunjuk AI'}</span>
            </button>
          </div>

          {showHint && (
            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
              <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <span>{activeQuestion.hint}</span>
            </div>
          )}

          {isFinished && (
            <div className="p-3.5 bg-indigo-50 rounded-xl border border-indigo-200 text-xs text-indigo-900 space-y-1 animate-in fade-in">
              <span className="font-bold block flex items-center gap-1.5 text-indigo-900">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                💡 Pembahasan Konsep Saintifik:
              </span>
              <p className="leading-relaxed text-slate-700">{activeQuestion.explanation}</p>
            </div>
          )}
        </div>
      </div>

      {/* 4. TOMBOL SELESAI BELAJAR -> BUKA MISI 2 */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="text-xs text-slate-600">
          <p className="font-bold text-slate-800">
            {isAnswerChecked ? 'Kuis Selesai Diperiksa!' : 'Langkah Wajib: Periksa Jawaban Kuis'}
          </p>
          <p className="text-slate-500 mt-0.5">
            {isAnswerChecked
              ? 'Jawaban telah tersimpan. Klik tombol di samping untuk melanjutkan ke Misi 2 (Selesaikan Masalah).'
              : 'Pilih jawaban dan tekan tombol "Periksa Jawaban" di atas untuk membuka akses ke Misi 2.'}
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          {isAnswerChecked ? (
            <button
              id="btn-lanjut-ke-misi-2"
              type="button"
              onClick={handleProceedNext}
              className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95"
            >
              <span>Lanjut ke Misi 2</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              id="btn-periksa-dulu-sebelum-m2"
              type="button"
              onClick={handlePeriksaJawaban}
              className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95"
            >
              <Check className="w-4 h-4" />
              <span>Periksa Jawaban Kuis Dulu</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
